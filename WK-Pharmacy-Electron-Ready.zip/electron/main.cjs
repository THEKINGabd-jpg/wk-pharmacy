const { app, BrowserWindow, dialog } = require('electron');
const { fork } = require('child_process');
const path = require('path');

let serverProcess;

function startServer() {
  const serverPath = path.join(app.getAppPath(), 'dist', 'server.cjs');
  serverProcess = fork(serverPath, [], {
    cwd: app.getAppPath(),
    env: { ...process.env, NODE_ENV: 'production' },
    stdio: 'ignore'
  });
}

async function createWindow() {
  const win = new BrowserWindow({
    width: 1440,
    height: 900,
    minWidth: 1100,
    minHeight: 700,
    show: false,
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false
    }
  });

  win.once('ready-to-show', () => win.show());

  let lastError;
  for (let i = 0; i < 30; i++) {
    try {
      await win.loadURL('http://127.0.0.1:3000');
      return;
    } catch (err) {
      lastError = err;
      await new Promise(r => setTimeout(r, 500));
    }
  }

  dialog.showErrorBox('WK Pharmacy', `تعذر تشغيل نظام الصيدلية.\n${lastError?.message || ''}`);
}

app.whenReady().then(async () => {
  startServer();
  await createWindow();

  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (serverProcess) serverProcess.kill();
  if (process.platform !== 'darwin') app.quit();
});

app.on('before-quit', () => {
  if (serverProcess) serverProcess.kill();
});
