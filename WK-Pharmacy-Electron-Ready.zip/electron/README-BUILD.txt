WK Pharmacy - Windows EXE

Build commands:
1. npm install
2. npm run electron:build

Installer output:
release/WK-Pharmacy-Setup-1.0.0.exe

Portable output:
release/WK-Pharmacy-Setup-1.0.0.exe (portable target may also be generated according to electron-builder configuration).

The application starts its bundled Express server automatically and opens the Vite/React application in Electron.
