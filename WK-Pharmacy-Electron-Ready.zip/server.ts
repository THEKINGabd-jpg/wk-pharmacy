import express from "express";
import path from "path";
import { createServer as createViteServer } from "vite";
import dotenv from "dotenv";
import { GoogleGenAI, Type } from "@google/genai";

dotenv.config();

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "25mb" }));

  // Initialize Gemini AI
  const apiKey = process.env.GEMINI_API_KEY;
  const ai = new GoogleGenAI({
    apiKey: apiKey || "",
    httpOptions: {
      headers: {
        "User-Agent": "aistudio-build",
      },
    },
  });

  // OCR Invoice Scanning API endpoint
  app.post("/api/ocr-invoice", async (req, res) => {
    try {
      const { imageBase64, mimeType = "image/jpeg" } = req.body;

      if (!imageBase64) {
        return res.status(400).json({ success: false, error: "Missing imageBase64 data" });
      }

      if (!apiKey) {
        return res.status(500).json({ success: false, error: "GEMINI_API_KEY environment variable is missing" });
      }

      // Clean base64 string if data URL prefix exists
      const cleanBase64 = imageBase64.replace(/^data:image\/\w+;base64,/, "");

      const prompt = `أنت خبير صيدلاني ومحاسبي متخصص في قراءة وتحليل فواتير المذاخر وشركات تزويد الأدوية (Pharmacy Distributor Invoices).
قم بتحليل صورة الفاتورة المرفقة بدقة عالية واستخراج كافة الأصناف والمواد الدوائية المذكورة فيها.

لكل صنف دوائي بالفاتورة، استخرج المكونات التالية:
1. tradeName: الاسم التجاري للدواء كما هو بالكرتون أو الفاتورة.
2. genericName: الاسم العلمي أو المادة الفعالة (أو تخمينه إن لم يكتب).
3. company: اسم الشركة المصنعة.
4. category: الفئة العلاجية (مسكنات, مضادات حيوية, فيتامينات, أدوية معدة, أدوية ضغط, أدوية سكر, الخ).
5. qtyMajor: عدد العلب/الكراتين بالفاتورة (مثلاً 5 علب).
6. unitsPerMajor: عدد الأشرطة أو الوحدات داخل العلبة الواحدة (الافتراضي 10 إذا لم يحدد).
7. qtyMinor: الأشرطة الفردية الإضافية إن وجدت.
8. costPriceMajor: سعر شراء العلبة/الكرتون الكلي المكتوب بالفاتورة.
9. costPriceMinor: سعر شراء الشريط/الوحدة الصغرى الواحدة (إذا لم يكتب مباشرة، نقسم سعر الكرتون على عدد الأشرطة).
10. priceMajor: سعر البيع المقترح للعلبة الواحدة للجمهور (عادة يضيف هامش ربح 20-30% فوق الكلفة).
11. priceMinor: سعر البيع المقترح للشريط/الوحدة الصغرى الواحدة للجمهور.
12. priceMajorMoh: سعر تسعيرة وزارة الصحة العراقية الرسمي المقترح للعلبة الكلية.
13. priceMinorMoh: سعر تسعيرة وزارة الصحة العراقية الرسمي المقترح للشريط/الوحدة الصغرى.
14. expiryDate: تاريخ انتهاء الصلاحية بصيغة YYYY-MM-DD (إذا كتب بالشهر والسنة مثل 06/2027 أرجعه بـ 2027-06-30، وإذا لم يكتب ضع تاريخاً مستقبلياً 2028-06-30).
15. barcode: رمز الباركود إن وجد مطبوعاً بالفاتورة.

كذلك استخرج معلومات الفاتورة العامة:
- supplierName: اسم المذخر أو الشركة الموردة بالفاتورة.
- invoiceNumber: رقم الفاتورة إن وجد.
- invoiceDate: تاريخ الفاتورة.

أرجع النتيجة بصيغة JSON حصرية ودقيقة.`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash",
        contents: [
          {
            inlineData: {
              data: cleanBase64,
              mimeType,
            },
          },
          {
            text: prompt,
          },
        ],
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              supplierName: { type: Type.STRING },
              invoiceNumber: { type: Type.STRING },
              invoiceDate: { type: Type.STRING },
              items: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    tradeName: { type: Type.STRING },
                    genericName: { type: Type.STRING },
                    company: { type: Type.STRING },
                    category: { type: Type.STRING },
                    qtyMajor: { type: Type.NUMBER },
                    unitsPerMajor: { type: Type.NUMBER },
                    qtyMinor: { type: Type.NUMBER },
                    costPriceMajor: { type: Type.NUMBER },
                    costPriceMinor: { type: Type.NUMBER },
                    priceMajor: { type: Type.NUMBER },
                    priceMinor: { type: Type.NUMBER },
                    priceMajorMoh: { type: Type.NUMBER },
                    priceMinorMoh: { type: Type.NUMBER },
                    expiryDate: { type: Type.STRING },
                    barcode: { type: Type.STRING },
                  },
                  required: ["tradeName", "costPriceMinor", "priceMinor"],
                },
              },
            },
            required: ["items"],
          },
        },
      });

      const resultText = response.text || "{}";
      const parsedData = JSON.parse(resultText);

      return res.json({ success: true, data: parsedData });
    } catch (err: any) {
      console.error("Error in OCR Invoice extraction:", err);
      return res.status(500).json({
        success: false,
        error: err.message || "Failed to process invoice image",
      });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(__dirname);
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Pharmacy full-stack server running on http://localhost:${PORT}`);
  });
}

startServer();
