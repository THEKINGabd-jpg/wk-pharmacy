import { Medicine, Transaction, AppSettings } from '../types';
import { translations } from '../translations';
import { BarChart3, FileSpreadsheet, FileDown, TrendingUp, DollarSign, Award, Target } from 'lucide-react';

interface ReportsViewProps {
  medicines: Medicine[];
  transactions: Transaction[];
  settings: AppSettings;
  lang: 'ar' | 'en';
}

export default function ReportsView({ medicines, transactions, settings, lang }: ReportsViewProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const currencySymbol = settings.currency === 'USD' ? '$' : settings.currency === 'EGP' ? 'ج.م' : settings.currency === 'SAR' ? 'ر.س' : 'د.ع';

  // Category shares statistics - editorial colors
  const categoryStats = [
    { label: lang === 'ar' ? 'مضادات حيوية' : 'Antibiotics', percentage: '35%', color: 'bg-neutral-950 dark:bg-neutral-200' },
    { label: lang === 'ar' ? 'فيتامينات' : 'Vitamins', percentage: '25%', color: 'bg-neutral-700 dark:bg-neutral-400' },
    { label: lang === 'ar' ? 'مسكنات' : 'Painkillers', percentage: '20%', color: 'bg-neutral-500 dark:bg-neutral-500' },
    { label: lang === 'ar' ? 'أدوية براد' : 'Cold Meds', percentage: '20%', color: 'bg-neutral-300 dark:bg-neutral-600' },
  ];

  // Best Selling medicines list
  const topSelling = [
    { name: 'بانادول إكسترا', sales: 142, revenue: 6390 },
    { name: 'فيتامين سي 1000 مجم', sales: 98, revenue: 11760 },
    { name: 'بروفين 400', sales: 74, revenue: 1369 },
  ];

  return (
    <div className="page-enter space-y-6 pb-10 font-sans" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      
      {/* Header section */}
      <section className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-850">
        <div className="flex flex-col gap-1 items-start text-right">
          <h2 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.reportsTitle}</h2>
          <p className="text-neutral-500 uppercase tracking-widest font-mono text-[9px] font-bold">{t.reportsComingSoon.slice(0, 70)}...</p>
        </div>
        <div className="flex gap-2">
          <button className="flex items-center gap-1.5 px-4 py-2 border border-neutral-950 dark:border-neutral-700 hover:bg-[#DEDCD7] dark:hover:bg-neutral-800 text-neutral-950 dark:text-neutral-200 bg-white dark:bg-neutral-950 rounded-none text-[10px] tracking-widest uppercase font-mono font-bold cursor-pointer transition-all">
            <FileSpreadsheet className="w-3.5 h-3.5 text-neutral-700 dark:text-neutral-400" />
            <span>Excel</span>
          </button>
          <button className="flex items-center gap-1.5 px-4 py-2 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none text-[10px] tracking-widest uppercase font-mono font-bold cursor-pointer transition-all border border-neutral-950 dark:border-neutral-700">
            <FileDown className="w-3.5 h-3.5" />
            <span>PDF</span>
          </button>
        </div>
      </section>

      {/* Beta Warning banner with nice graphics */}
      <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] border-l-4 border-l-neutral-950 dark:border-l-neutral-200 border-y border-r border-[#D4D1CC] dark:border-neutral-800 p-6 rounded-none flex flex-col md:flex-row items-center gap-4 relative overflow-hidden"
        style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
      >
        <div className="w-10 h-10 bg-neutral-950 dark:bg-neutral-800 text-white dark:text-neutral-200 rounded-none flex items-center justify-center shrink-0">
          <BarChart3 className="w-4 h-4" />
        </div>
        <p className="text-xs font-serif italic text-neutral-800 dark:text-neutral-300 leading-relaxed text-right flex-1"
          style={{ textAlign: isRtl ? 'right' : 'left' }}
        >
          {t.reportsComingSoon}
        </p>
      </div>

      {/* Interactive Mock Charts Bento Layout */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        {/* KPI: Sales Breakdown shares */}
        <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
          <h3 className="text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            {lang === 'ar' ? 'مبيعات الأقسام الطبية' : 'Sales per Category'}
          </h3>
          
          <div className="space-y-4 pt-2">
            {categoryStats.map((cat, idx) => (
              <div key={idx} className="space-y-1">
                <div className="flex justify-between text-xs font-bold" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                  <span className="text-neutral-800 dark:text-neutral-200 font-serif italic">{cat.label}</span>
                  <span className="text-neutral-500 font-mono text-[10px]">{cat.percentage}</span>
                </div>
                {/* Horizontal Progress bar - sharp corners */}
                <div className="w-full h-2 bg-neutral-100 dark:bg-neutral-800 rounded-none overflow-hidden border border-neutral-200 dark:border-neutral-750">
                  <div className={`h-full ${cat.color} rounded-none`} style={{ width: cat.percentage }}></div>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* KPI: Top Selling Medicines list */}
        <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
          <h3 className="text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            {lang === 'ar' ? 'الأكثر مبيعاً هذا الشهر' : 'Best Sellers This Month'}
          </h3>

          <div className="divide-y divide-[#D4D1CC] dark:divide-neutral-850 text-xs font-medium pt-2">
            {topSelling.map((med, idx) => (
              <div key={idx} className="py-3 flex justify-between items-center" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                <div className="flex items-center gap-3" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                  <span className="w-5 h-5 rounded-none bg-neutral-950 dark:bg-neutral-800 text-white font-mono font-bold flex items-center justify-center text-[10px]">
                    {idx + 1}
                  </span>
                  <span className="font-serif italic font-bold text-neutral-800 dark:text-neutral-200">{med.name}</span>
                </div>
                <div className="text-right font-mono flex flex-col" style={{ alignItems: isRtl ? 'flex-start' : 'flex-end' }}>
                  <span className="font-bold text-neutral-950 dark:text-white">{med.sales} {lang === 'ar' ? 'علبة' : 'packs'}</span>
                  <span className="text-[9px] font-bold text-neutral-450 mt-0.5">{med.revenue} {currencySymbol}</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* KPI: Target Progress Circle */}
        <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col justify-between">
          <h3 className="text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            {lang === 'ar' ? 'الهدف المالي السنوي' : 'Annual Financial Target'}
          </h3>

          <div className="flex flex-col items-center justify-center py-4 relative">
            {/* Circle SVG */}
            <svg className="w-32 h-32 transform -rotate-90">
              <circle cx="64" cy="64" r="54" className="stroke-neutral-100 dark:stroke-neutral-800 stroke-[8] fill-none" />
              <circle cx="64" cy="64" r="54" className="stroke-neutral-950 dark:stroke-white stroke-[8] fill-none" strokeDasharray="339" strokeDashoffset="84" strokeLinecap="square" />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-lg font-black text-neutral-950 dark:text-white font-mono">75%</span>
              <span className="text-[9px] text-neutral-500 uppercase font-mono font-bold tracking-widest mt-0.5">{lang === 'ar' ? 'مكتمل' : 'Achieved'}</span>
            </div>
          </div>

          <div className="flex justify-between items-center text-xs font-bold border-t border-[#D4D1CC] dark:border-neutral-800 pt-3"
            style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
          >
            <span className="text-neutral-500 font-serif italic">{lang === 'ar' ? 'الهدف: 500,000' : 'Target: 500k'}</span>
            <span className="text-neutral-950 dark:text-white font-mono">{375000} {currencySymbol}</span>
          </div>
        </div>

      </div>

    </div>
  );
}
