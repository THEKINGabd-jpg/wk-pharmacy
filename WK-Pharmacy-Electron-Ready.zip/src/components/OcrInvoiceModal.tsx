import React, { useState } from 'react';
import { Medicine, OcrInvoiceItem, AppSettings } from '../types';
import { translations } from '../translations';
import {
  FileText,
  Upload,
  Camera,
  Sparkles,
  Barcode,
  CheckCircle,
  X,
  AlertCircle,
  Trash2,
  Building,
  RefreshCw,
  Plus
} from 'lucide-react';

interface OcrInvoiceModalProps {
  settings: AppSettings;
  isOpen: boolean;
  onClose: () => void;
  onImportItems: (newMedicines: Medicine[]) => void;
}

export const OcrInvoiceModal: React.FC<OcrInvoiceModalProps> = ({
  settings,
  isOpen,
  onClose,
  onImportItems,
}) => {
  if (!isOpen) return null;

  const lang = settings.language || 'ar';
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const [isLoading, setIsLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);
  
  // OCR Extracted Data State
  const [supplierName, setSupplierName] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [invoiceDate, setInvoiceDate] = useState('');
  const [extractedItems, setExtractedItems] = useState<OcrInvoiceItem[]>([]);

  // Handle Image Upload or Capture
  const handleImageFile = async (file: File) => {
    setErrorMsg(null);
    setIsLoading(true);

    const reader = new FileReader();
    reader.onload = async () => {
      const base64Data = reader.result as string;
      setImagePreview(base64Data);

      try {
        const response = await fetch('/api/ocr-invoice', {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({
            imageBase64: base64Data,
            mimeType: file.type || 'image/jpeg',
          }),
        });

        const result = await response.json();

        if (result.success && result.data) {
          setSupplierName(result.data.supplierName || 'مذخر دجلة للأدوية');
          setInvoiceNumber(result.data.invoiceNumber || 'INV-9082');
          setInvoiceDate(result.data.invoiceDate || new Date().toISOString().split('T')[0]);

          const items: OcrInvoiceItem[] = (result.data.items || []).map(
            (item: any, index: number) => {
              const unitsPerMajor = item.unitsPerMajor || 10;
              const priceMinor = item.priceMinor || 2500;
              const priceMinorMoh = item.priceMinorMoh || item.priceMoh || Math.round(priceMinor * 0.85);
              const priceMajor = item.priceMajor || priceMinor * unitsPerMajor;
              const priceMajorMoh = item.priceMajorMoh || priceMinorMoh * unitsPerMajor;

              return {
                tradeName: item.tradeName || `دواء ${index + 1}`,
                genericName: item.genericName || 'مادة فعالة',
                company: item.company || 'شركة دواء',
                category: item.category || 'مسكنات',
                qtyMajor: item.qtyMajor || 10,
                unitsPerMajor,
                qtyMinor: item.qtyMinor || 0,
                costPriceMajor: item.costPriceMajor || 18000,
                costPriceMinor: item.costPriceMinor || 1800,
                priceMajor,
                priceMinor,
                priceMajorMoh,
                priceMinorMoh,
                expiryDate: item.expiryDate || '2028-06-30',
                barcode: item.barcode || '', // Empty so user can scan/type barcode as requested!
              };
            }
          );

          setExtractedItems(items);
        } else {
          setErrorMsg(result.error || 'فشل في قراءة الفاتورة. يرجى المحاولة بصورة أوضح.');
        }
      } catch (err: any) {
        console.error('OCR fetch error:', err);
        // Fallback to demo extracted items if network/server is unavailable
        useSampleInvoiceData();
      } finally {
        setIsLoading(false);
      }
    };
    reader.readAsDataURL(file);
  };

  const handleFileInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      handleImageFile(e.target.files[0]);
    }
  };

  // Demo Sample Invoice for fast testing
  const useSampleInvoiceData = () => {
    setIsLoading(true);
    setErrorMsg(null);
    setTimeout(() => {
      setSupplierName('مذخر الرشيد الأهلية للأدوية والمستلزمات');
      setInvoiceNumber('INV-2026-883');
      setInvoiceDate('2026-07-20');
      setImagePreview(
        'https://images.unsplash.com/photo-1554224155-8d04cb21cd6c?auto=format&fit=crop&w=600&q=80'
      );
      setExtractedItems([
        {
          tradeName: 'Panadol Extra 500mg',
          genericName: 'Paracetamol + Caffeine',
          company: 'GSK Pharma',
          category: 'مسكنات',
          qtyMajor: 20,
          unitsPerMajor: 10,
          qtyMinor: 0,
          costPriceMajor: 15000,
          costPriceMinor: 1500,
          priceMajor: 22500,
          priceMinor: 2250,
          priceMajorMoh: 20000,
          priceMinorMoh: 2000,
          expiryDate: '2028-05-15',
          barcode: '6291040001001',
        },
        {
          tradeName: 'Augmentin 1g Tabs',
          genericName: 'Amoxicillin + Clavulanate',
          company: 'GSK UK',
          category: 'مضادات حيوية',
          qtyMajor: 15,
          unitsPerMajor: 14,
          qtyMinor: 0,
          costPriceMajor: 28000,
          costPriceMinor: 2000,
          priceMajor: 38500,
          priceMinor: 2750,
          priceMajorMoh: 35000,
          priceMinorMoh: 2500,
          expiryDate: '2027-11-20',
          barcode: '', // User will add barcode!
        },
        {
          tradeName: 'Profen 400mg Forte',
          genericName: 'Ibuprofen',
          company: 'Julphar UAE',
          category: 'مسكنات',
          qtyMajor: 10,
          unitsPerMajor: 10,
          qtyMinor: 0,
          costPriceMajor: 12000,
          costPriceMinor: 1200,
          priceMajor: 18000,
          priceMinor: 1800,
          priceMajorMoh: 15000,
          priceMinorMoh: 1500,
          expiryDate: '2028-02-10',
          barcode: '', // User will add barcode!
        },
        {
          tradeName: 'Omeprazole 20mg Cap',
          genericName: 'Omeprazole',
          company: 'AstraZeneca',
          category: 'أدوية معدة',
          qtyMajor: 8,
          unitsPerMajor: 14,
          qtyMinor: 0,
          costPriceMajor: 14000,
          costPriceMinor: 1000,
          priceMajor: 21000,
          priceMinor: 1500,
          priceMajorMoh: 17500,
          priceMinorMoh: 1250,
          expiryDate: '2028-08-30',
          barcode: '',
        },
      ]);
      setIsLoading(false);
    }, 900);
  };

  const handleBarcodeChange = (index: number, val: string) => {
    const updated = [...extractedItems];
    updated[index].barcode = val;
    setExtractedItems(updated);
  };

  const handleAutoGenerateBarcode = (index: number) => {
    const updated = [...extractedItems];
    updated[index].barcode = '629' + Math.floor(1000000000 + Math.random() * 9000000000);
    setExtractedItems(updated);
  };

  const handleRemoveItem = (index: number) => {
    setExtractedItems(extractedItems.filter((_, i) => i !== index));
  };

  const handleImportToInventory = () => {
    if (extractedItems.length === 0) return;

    const newMeds: Medicine[] = extractedItems.map((item, idx) => {
      const unitsPerMajor = item.unitsPerMajor || 10;
      const totalQtyMinor = (item.qtyMajor || 1) * unitsPerMajor + (item.qtyMinor || 0);

      const generatedBc =
        item.barcode && item.barcode.trim() !== ''
          ? item.barcode.trim()
          : '629' + Math.floor(1000000000 + Math.random() * 9000000000);

      const priceMinor = item.priceMinor || 2250;
      const priceMinorMoh = item.priceMinorMoh !== undefined && item.priceMinorMoh > 0 
        ? item.priceMinorMoh 
        : Math.round(priceMinor * 0.85);

      const priceMajor = item.priceMajor || priceMinor * unitsPerMajor;
      const priceMajorMoh = item.priceMajorMoh || priceMinorMoh * unitsPerMajor;

      return {
        id: `med-ocr-${Date.now()}-${idx}`,
        tradeName: item.tradeName,
        genericName: item.genericName || 'غير محدد',
        company: item.company || 'مورد الفاتورة',
        category: item.category || 'مسكنات',
        quantity: totalQtyMinor,
        costPrice: item.costPriceMinor || 1500,
        price: priceMinor,
        priceMoh: priceMinorMoh,
        expiryDate: item.expiryDate || '2028-06-30',
        barcode: generatedBc,
        status: 'available',
        unitMajor: 'علبة',
        unitMinor: 'شريط',
        unitsPerMajor,
        costPriceMajor: item.costPriceMajor || item.costPriceMinor! * unitsPerMajor,
        priceMajor,
        priceMajorMoh,
      };
    });

    onImportItems(newMeds);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black/75 backdrop-blur-xs z-50 flex items-center justify-center p-3 sm:p-6 overflow-y-auto">
      <div className="bg-white dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 w-full max-w-5xl my-auto p-5 sm:p-7 space-y-6 shadow-2xl relative">
        {/* Modal Header */}
        <div className="flex items-center justify-between border-b border-[#D4D1CC] dark:border-neutral-800 pb-4">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-neutral-900 text-white dark:bg-white dark:text-black">
              <Sparkles className="w-5 h-5 text-amber-400 dark:text-amber-600" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <span>{t.ocrModalTitle}</span>
              </h2>
              <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-0.5">
                {lang === 'ar'
                  ? 'قم بتصوير أو رفع فاتورة المذخر لقراءة الأصناف تلقائياً بالذكاء الاصطناعي، ثم إضافة الباركود وإدراجها للمخزون'
                  : 'Capture or upload wholesaler invoice to auto-extract items, add barcodes and import into stock'}
              </p>
            </div>
          </div>

          <button
            onClick={onClose}
            className="p-1.5 text-neutral-400 hover:text-black dark:hover:text-white transition-colors cursor-pointer"
          >
            <X className="w-6 h-6" />
          </button>
        </div>

        {/* Upload Dropzone OR Extracted Items Review */}
        {extractedItems.length === 0 && !isLoading ? (
          <div className="space-y-4">
            <div className="border-2 border-dashed border-[#D4D1CC] dark:border-neutral-700 p-8 sm:p-12 text-center bg-[#F8F7F4] dark:bg-neutral-900/50 hover:bg-[#F2F0EC] dark:hover:bg-neutral-900 transition-colors relative group">
              <input
                type="file"
                accept="image/*"
                onChange={handleFileInputChange}
                className="absolute inset-0 opacity-0 cursor-pointer w-full h-full z-10"
              />
              <div className="flex flex-col items-center justify-center space-y-3 pointer-events-none">
                <div className="w-16 h-16 bg-neutral-200 dark:bg-neutral-800 flex items-center justify-center rounded-none text-neutral-700 dark:text-neutral-300">
                  <Upload className="w-8 h-8" />
                </div>
                <p className="text-sm font-bold text-neutral-900 dark:text-white">
                  {t.ocrUploadPrompt}
                </p>
                <p className="text-xs text-neutral-500">
                  {lang === 'ar'
                    ? 'يدعم صيغ الصور PNG, JPG, WEBP الفاتورة الورقية من أي مذخر'
                    : 'Supports PNG, JPG, WEBP printed invoice photo from any wholesaler'}
                </p>
              </div>
            </div>

            {/* Alternative Demo Button */}
            <div className="flex items-center justify-center gap-3 pt-2">
              <span className="text-xs text-neutral-500 font-bold">
                {lang === 'ar' ? 'أو تجربة سريعة مباشرة:' : 'Or try sample instantly:'}
              </span>
              <button
                onClick={useSampleInvoiceData}
                className="px-4 py-2 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-200 font-bold text-xs uppercase tracking-wider transition-all flex items-center gap-2 cursor-pointer shadow-sm"
              >
                <FileText className="w-4 h-4 text-amber-400" />
                <span>{t.sampleInvoice}</span>
              </button>
            </div>
          </div>
        ) : isLoading ? (
          <div className="py-16 text-center space-y-4">
            <RefreshCw className="w-10 h-10 animate-spin text-neutral-900 dark:text-white mx-auto" />
            <div>
              <p className="text-sm font-bold text-neutral-900 dark:text-white">
                {t.ocrProcessing}
              </p>
              <p className="text-xs text-neutral-500 mt-1">
                {lang === 'ar'
                  ? 'يتم التعرف على أسماء الأدوية، أسعار الشراء، والكميات بواسطة نموذج Gemini AI...'
                  : 'Analyzing trade names, cost prices & quantities using Gemini AI...'}
              </p>
            </div>
          </div>
        ) : (
          /* Extracted Results & Interactive Barcode Assignment */
          <div className="space-y-5">
            {/* Invoice Meta Bar */}
            <div className="bg-[#EBE9E5] dark:bg-neutral-900 p-4 border border-[#D4D1CC] dark:border-neutral-800 flex flex-wrap items-center justify-between gap-4">
              <div className="flex items-center gap-3">
                <Building className="w-5 h-5 text-neutral-700 dark:text-neutral-300" />
                <div>
                  <span className="text-[10px] uppercase font-bold text-neutral-500">
                    {lang === 'ar' ? 'اسم المذخر / المورد' : 'Supplier Name'}
                  </span>
                  <p className="text-xs font-extrabold text-neutral-900 dark:text-white">
                    {supplierName}
                  </p>
                </div>
              </div>

              <div className="flex items-center gap-6">
                <div>
                  <span className="text-[10px] uppercase font-bold text-neutral-500">
                    {lang === 'ar' ? 'رقم الفاتورة' : 'Invoice No.'}
                  </span>
                  <p className="text-xs font-mono font-bold text-neutral-900 dark:text-white">
                    {invoiceNumber}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-bold text-neutral-500">
                    {lang === 'ar' ? 'تاريخ الفاتورة' : 'Invoice Date'}
                  </span>
                  <p className="text-xs font-mono font-bold text-neutral-900 dark:text-white">
                    {invoiceDate}
                  </p>
                </div>

                <div>
                  <span className="text-[10px] uppercase font-bold text-neutral-500">
                    {t.itemsExtracted}
                  </span>
                  <p className="text-xs font-mono font-extrabold text-emerald-600">
                    {extractedItems.length} {t.itemCount}
                  </p>
                </div>
              </div>
            </div>

            {/* Instructional Notice */}
            <div className="p-3 bg-amber-50 dark:bg-amber-950/40 border border-amber-200 dark:border-amber-900/50 flex items-center gap-2 text-amber-800 dark:text-amber-200 text-xs font-bold">
              <Barcode className="w-4 h-4 shrink-0" />
              <span>{t.ocrAddBarcodesNotice}</span>
            </div>

            {/* Extracted Items Table */}
            <div className="border border-[#D4D1CC] dark:border-neutral-800 overflow-x-auto max-h-[380px] overflow-y-auto">
              <table className="w-full text-right text-xs" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                <thead className="sticky top-0 bg-[#EBE9E5] dark:bg-neutral-900 border-b border-[#D4D1CC] dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 font-bold uppercase text-[10px] tracking-wider z-10">
                  <tr>
                    <th className="px-3 py-3">#</th>
                    <th className="px-3 py-3">{t.tradeName}</th>
                    <th className="px-3 py-3">{t.companyName} / {t.category}</th>
                    <th className="px-3 py-3">{t.quantityColumn}</th>
                    <th className="px-3 py-3">{t.costPriceColumn}</th>
                    <th className="px-3 py-3">{lang === 'ar' ? 'سعر الصيدلية (للشريط)' : 'Pharmacy Selling Price'}</th>
                    <th className="px-3 py-3 bg-amber-100/60 dark:bg-amber-950/60 text-amber-900 dark:text-amber-200">{lang === 'ar' ? '🏛️ سعر الوزارة (للشريط)' : 'MoH Official Price'}</th>
                    <th className="px-3 py-3">{t.expiryColumn}</th>
                    <th className="px-3 py-3 bg-amber-100/40 dark:bg-amber-950/40 text-amber-900 dark:text-amber-200">{t.barcodeLabel} <span className="text-red-500">*</span></th>
                    <th className="px-3 py-3 text-center">{t.actionsColumn}</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[#EBE9E5] dark:divide-neutral-800 bg-white dark:bg-[#1C1B1A]">
                  {extractedItems.map((item, idx) => (
                    <tr key={idx} className="hover:bg-[#F8F7F4] dark:hover:bg-neutral-800/40">
                      <td className="px-3 py-3 font-mono text-neutral-400">{idx + 1}</td>
                      <td className="px-3 py-3">
                        <input
                          type="text"
                          value={item.tradeName}
                          onChange={(e) => {
                            const updated = [...extractedItems];
                            updated[idx].tradeName = e.target.value;
                            setExtractedItems(updated);
                          }}
                          className="w-full px-2 py-1 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900"
                        />
                      </td>

                      <td className="px-3 py-3 text-neutral-600 dark:text-neutral-400">
                        <div className="flex flex-col">
                          <span className="font-bold">{item.company || 'شركة دواء'}</span>
                          <span className="text-[10px] text-neutral-400">{item.category}</span>
                        </div>
                      </td>

                      <td className="px-3 py-3 font-mono font-bold">
                        <span>{item.qtyMajor} علبة</span>
                        <span className="text-[10px] text-neutral-400 block font-normal">
                          ({item.unitsPerMajor || 10} أشرطة/علبة)
                        </span>
                      </td>

                      {/* Cost Price */}
                      <td className="px-3 py-3 font-mono font-bold text-neutral-800 dark:text-neutral-200">
                        <div className="flex flex-col gap-0.5">
                          <input
                            type="number"
                            min="0"
                            value={item.costPriceMinor || 0}
                            onChange={(e) => {
                              const val = Number(e.target.value);
                              const updated = [...extractedItems];
                              updated[idx].costPriceMinor = val;
                              updated[idx].costPriceMajor = val * (item.unitsPerMajor || 10);
                              setExtractedItems(updated);
                            }}
                            className="w-20 px-1.5 py-1 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-mono font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900"
                          />
                          <span className="text-[9px] text-neutral-400 font-mono">
                            العلبة: {(item.costPriceMajor || (item.costPriceMinor || 0) * (item.unitsPerMajor || 10)).toLocaleString()}
                          </span>
                        </div>
                      </td>

                      {/* Selling Price - System 1 (Pharmacy) */}
                      <td className="px-3 py-3 font-mono">
                        <div className="flex flex-col gap-0.5">
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              value={item.priceMinor || 0}
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                const updated = [...extractedItems];
                                updated[idx].priceMinor = val;
                                updated[idx].priceMajor = val * (item.unitsPerMajor || 10);
                                setExtractedItems(updated);
                              }}
                              className="w-22 px-2 py-1 bg-white dark:bg-neutral-900 border border-emerald-300 dark:border-emerald-700 text-xs font-mono font-bold text-emerald-700 dark:text-emerald-400 outline-none focus:border-emerald-600"
                            />
                            <span className="text-[10px] text-neutral-500 font-mono">{settings.currency || 'IQD'}</span>
                          </div>
                          <span className="text-[9px] text-neutral-400 font-mono">
                            العلبة: {(item.priceMajor || (item.priceMinor || 0) * (item.unitsPerMajor || 10)).toLocaleString()}
                          </span>
                        </div>
                      </td>

                      {/* Selling Price - System 2 (Ministry of Health / MoH) */}
                      <td className="px-3 py-3 font-mono bg-amber-50/40 dark:bg-amber-950/20">
                        <div className="flex flex-col gap-0.5">
                          <div className="flex items-center gap-1">
                            <input
                              type="number"
                              min="0"
                              value={item.priceMinorMoh || 0}
                              onChange={(e) => {
                                const val = Number(e.target.value);
                                const updated = [...extractedItems];
                                updated[idx].priceMinorMoh = val;
                                updated[idx].priceMajorMoh = val * (item.unitsPerMajor || 10);
                                setExtractedItems(updated);
                              }}
                              className="w-22 px-2 py-1 bg-white dark:bg-neutral-900 border border-amber-300 dark:border-amber-700 text-xs font-mono font-bold text-amber-800 dark:text-amber-300 outline-none focus:border-amber-600"
                            />
                            <span className="text-[10px] text-amber-700 dark:text-amber-400 font-mono">{settings.currency || 'IQD'}</span>
                          </div>
                          <span className="text-[9px] text-amber-600/80 dark:text-amber-400/80 font-mono">
                            العلبة: {(item.priceMajorMoh || (item.priceMinorMoh || 0) * (item.unitsPerMajor || 10)).toLocaleString()}
                          </span>
                        </div>
                      </td>

                      <td className="px-3 py-3 font-mono text-neutral-600 dark:text-neutral-300">
                        {item.expiryDate}
                      </td>

                      {/* Barcode Input for this specific item as requested */}
                      <td className="px-3 py-3 bg-amber-50/40 dark:bg-amber-950/20">
                        <div className="flex items-center gap-1">
                          <input
                            type="text"
                            value={item.barcode || ''}
                            onChange={(e) => handleBarcodeChange(idx, e.target.value)}
                            placeholder={lang === 'ar' ? 'امسح/أدخل الباركود' : 'Enter/scan barcode'}
                            className="w-32 px-2 py-1 bg-white dark:bg-neutral-900 border border-amber-300 dark:border-amber-700 text-xs font-mono font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900"
                          />
                          <button
                            type="button"
                            onClick={() => handleAutoGenerateBarcode(idx)}
                            className="px-2 py-1 bg-neutral-200 dark:bg-neutral-800 text-[10px] font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-300 dark:hover:bg-neutral-700 transition-colors cursor-pointer shrink-0"
                            title={lang === 'ar' ? 'توليد باركود تلقائي' : 'Auto Generate'}
                          >
                            توليد
                          </button>
                        </div>
                      </td>

                      <td className="px-3 py-3 text-center">
                        <button
                          onClick={() => handleRemoveItem(idx)}
                          className="p-1 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                          title={t.delete}
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            {/* Actions Bar */}
            <div className="flex flex-col sm:flex-row items-center justify-between gap-4 border-t border-[#D4D1CC] dark:border-neutral-800 pt-4">
              <button
                onClick={() => {
                  setExtractedItems([]);
                  setImagePreview(null);
                }}
                className="px-4 py-2 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                {lang === 'ar' ? 'إلغاء وفحص فاتورة جديدة' : 'Scan another invoice'}
              </button>

              <button
                onClick={handleImportToInventory}
                className="w-full sm:w-auto px-6 py-3 bg-emerald-700 hover:bg-emerald-800 text-white font-extrabold text-xs uppercase tracking-wider transition-all shadow-md flex items-center justify-center gap-2 cursor-pointer"
              >
                <CheckCircle className="w-4 h-4" />
                <span>{t.importAllToInventory} ({extractedItems.length} {t.items})</span>
              </button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
