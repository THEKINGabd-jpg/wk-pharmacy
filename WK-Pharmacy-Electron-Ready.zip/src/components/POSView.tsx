import React, { useState, useEffect, useRef, useCallback } from 'react';
import { Medicine, Transaction, AppSettings, Customer, TransactionItem, ShortageItem, PricingMode } from '../types';
import { translations } from '../translations';
import { Search, Camera, CreditCard, Printer, Trash2, Plus, Minus, Sparkles, FileText, CheckCircle, User, Edit2, ShoppingBag, X, ClipboardList } from 'lucide-react';

interface POSViewProps {
  medicines: Medicine[];
  customers: Customer[];
  settings: AppSettings;
  lang: 'ar' | 'en';
  onAddTransaction: (tx: Transaction) => void;
  onUpdateInventory: (medId: string, qtyDelta: number) => void;
  onAddShortage?: (shortageData: Omit<ShortageItem, 'id' | 'createdAt'>) => void;
  onAddCustomer?: (customer: Customer) => void;
}

interface CartItem {
  medicine: Medicine;
  quantity: number;
  soldAs: 'major' | 'minor';
}

export default function POSView({ medicines, customers, settings, lang, onAddTransaction, onUpdateInventory, onAddShortage, onAddCustomer }: POSViewProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const currencySymbol = settings.currency === 'USD' ? '$' : settings.currency === 'EGP' ? 'ج.م' : settings.currency === 'SAR' ? 'ر.س' : 'د.ع';

  // State managers
  const [cart, setCart] = useState<CartItem[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');

  // Dual Pricing System Mode ('pharmacy' = Pharmacy Price, 'moh' = Iraqi Ministry of Health Price)
  const [pricingMode, setPricingMode] = useState<PricingMode>('pharmacy');

  // Helper to compute price based on active pricing mode
  const getMedicinePrice = useCallback((med: Medicine, soldAs: 'major' | 'minor', mode: PricingMode) => {
    const unitsPerMajor = med.unitsPerMajor || 10;
    if (mode === 'moh') {
      if (soldAs === 'major') {
        return med.priceMajorMoh !== undefined && med.priceMajorMoh > 0 
          ? med.priceMajorMoh 
          : (med.priceMoh !== undefined && med.priceMoh > 0 ? med.priceMoh * unitsPerMajor : (med.priceMajor || med.price * unitsPerMajor));
      } else {
        return med.priceMoh !== undefined && med.priceMoh > 0 ? med.priceMoh : med.price;
      }
    } else {
      if (soldAs === 'major') {
        return med.priceMajor || med.price * unitsPerMajor;
      } else {
        return med.price;
      }
    }
  }, []);
  
  // Default selected customer is Cash customer
  const defaultCashCustomer = customers.find(c => c.code === '0000' || c.type === 'نقدي') || 
    { id: 'cust-4', name: 'عميل نقدي', type: 'نقدي', code: '0000', isVip: false, discountRate: 0 };
  const [selectedCustomer, setSelectedCustomer] = useState<Customer>(defaultCashCustomer);
  const [invoiceNumber, setInvoiceNumber] = useState('INV-8842');

  // New VIP Customer Creation state inside modal
  const [isAddingNewCustomer, setIsAddingNewCustomer] = useState(false);
  const [newCustName, setNewCustName] = useState('');
  const [newCustCode, setNewCustCode] = useState('');

  // Interactive camera simulation state
  const [isScannerOpen, setIsScannerOpen] = useState(false);
  const [isAnalyzingPrescription, setIsAnalyzingPrescription] = useState(false);
  
  // Modals and toasts
  const [showToast, setShowToast] = useState<{ visible: boolean; message: string; type: 'success' | 'info' }>({ visible: false, message: '', type: 'success' });
  const [checkoutReceipt, setCheckoutReceipt] = useState<Transaction | null>(null);
  const [isCustomerModalOpen, setIsCustomerModalOpen] = useState(false);

  // Barcode specific state and ref
  const [barcodeQuery, setBarcodeQuery] = useState('');
  const barcodeInputRef = useRef<HTMLInputElement>(null);

  // Auto-focus barcode input for fast scans
  useEffect(() => {
    if (barcodeInputRef.current) {
      barcodeInputRef.current.focus();
    }
  }, []);

  // Generate randomized invoice number
  const regenerateInvoice = () => {
    const num = Math.floor(1000 + Math.random() * 9000);
    setInvoiceNumber(`INV-${num}`);
  };

  useEffect(() => {
    regenerateInvoice();
  }, []);

  // Display floating toast
  const triggerToast = (message: string, type: 'success' | 'info' = 'success') => {
    setShowToast({ visible: true, message, type });
  };

  // Add item to Shortages
  const handleAddToShortages = (medName: string, category?: string, supplierName?: string) => {
    if (onAddShortage) {
      onAddShortage({
        itemName: medName,
        category: category || 'عام',
        requestedQty: 1,
        unit: 'علبة',
        priority: 'high',
        status: 'pending',
        supplierName: supplierName || 'غير محدد',
        notes: lang === 'ar' ? 'تمت الإضافة من شاشة الكاشير أثناء البيع' : 'Added from POS cashier'
      });
      triggerToast(
        lang === 'ar' 
          ? `تمت إضافة "${medName}" إلى قائمة النقوصات!` 
          : `Added "${medName}" to shortages list!`, 
        'success'
      );
    }
  };

  useEffect(() => {
    if (showToast.visible) {
      const timer = setTimeout(() => {
        setShowToast(prev => ({ ...prev, visible: false }));
      }, 3000);
      return () => clearTimeout(timer);
    }
  }, [showToast.visible]);

  // Keyboard Shortcuts Simulator
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'F1') {
        e.preventDefault();
        handleCheckout('cash');
      } else if (e.key === 'F2') {
        e.preventDefault();
        handleCheckout('card');
      } else if (e.key === 'F4') {
        e.preventDefault();
        const searchInput = document.getElementById('med-search-input');
        if (searchInput) searchInput.focus();
      } else if (e.key === 'F8' || (e.altKey && e.key.toLowerCase() === 'p')) {
        e.preventDefault();
        setPricingMode(prev => {
          const next = prev === 'pharmacy' ? 'moh' : 'pharmacy';
          triggerToast(
            next === 'moh' ? t.pricingSwitchedToMoh : t.pricingSwitchedToPharmacy,
            'info'
          );
          return next;
        });
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [cart, selectedCustomer, t]);

  // Handle barcode scanner simulation
  const handleToggleScanner = () => {
    if (!isScannerOpen) {
      setIsScannerOpen(true);
      // Simulate successful scan after 2.5 seconds
      setTimeout(() => {
        const scannerItems = medicines.filter(m => m.status === 'available');
        if (scannerItems.length > 0) {
          const randomMed = scannerItems[Math.floor(Math.random() * scannerItems.length)];
          handleAddToCart(randomMed);
          triggerToast(t.scanSuccessToast.replace('{medName}', randomMed.tradeName), 'success');
        } else {
          triggerToast(t.scanFailedToast, 'info');
        }
        setIsScannerOpen(false);
      }, 2500);
    } else {
      setIsScannerOpen(false);
    }
  };

  // Handle Prescription AI Upload simulation
  const handleAnalyzePrescription = () => {
    setIsAnalyzingPrescription(true);
    triggerToast(t.prescriptionAnalyzing, 'info');

    setTimeout(() => {
      // Simulate identifying and adding 3 appropriate clinical medicines to the cart
      const pool = medicines.filter(m => ['med-1', 'med-2', 'med-5', 'med-7'].includes(m.id));
      pool.forEach(med => {
        handleAddToCart(med);
      });
      setIsAnalyzingPrescription(false);
      triggerToast(t.prescriptionSuccess.replace('{count}', pool.length.toString()), 'success');
    }, 2800);
  };

  // Add medicine to cart list
  const handleAddToCart = (medicine: Medicine, soldAs: 'major' | 'minor' = 'minor') => {
    if (medicine.quantity <= 0) {
      triggerToast(lang === 'ar' ? 'عذراً، هذا الدواء غير متوفر في المخزون!' : 'Sorry, this medicine is out of stock!', 'info');
      return;
    }

    setCart(prevCart => {
      const existing = prevCart.find(item => item.medicine.id === medicine.id && item.soldAs === soldAs);
      const unitsPerMajor = medicine.unitsPerMajor || 10;
      const stepQty = soldAs === 'major' ? unitsPerMajor : 1;

      // Calculate total quantity of this medicine already in cart (major + minor combined)
      const totalInCartMinor = prevCart
        .filter(item => item.medicine.id === medicine.id)
        .reduce((sum, item) => sum + (item.soldAs === 'major' ? item.quantity * unitsPerMajor : item.quantity), 0);

      if (totalInCartMinor + stepQty > medicine.quantity) {
        triggerToast(lang === 'ar' ? 'عذراً، تم الوصول للحد الأقصى للكمية المتوفرة!' : 'Sorry, maximum available quantity reached!', 'info');
        return prevCart;
      }

      if (existing) {
        return prevCart.map(item => 
          (item.medicine.id === medicine.id && item.soldAs === soldAs)
            ? { ...item, quantity: item.quantity + 1 }
            : item
        );
      } else {
        return [...prevCart, { medicine, quantity: 1, soldAs }];
      }
    });
    triggerToast(t.addedToCart, 'success');
  };

  const handleBarcodeChange = (value: string) => {
    setBarcodeQuery(value);
    const cleanValue = value.trim();
    if (cleanValue.length >= 2) {
      const foundMed = medicines.find(m => m.barcode === cleanValue);
      if (foundMed) {
        if (foundMed.quantity <= 0) {
          triggerToast(
            lang === 'ar' 
              ? `عذراً، ${foundMed.tradeName} غير متوفر في المخزن!` 
              : `Sorry, ${foundMed.tradeName} is out of stock!`, 
            'info'
          );
        } else {
          handleAddToCart(foundMed);
          triggerToast(
            t.barcodeAddedToCart.replace('{name}', foundMed.tradeName), 
            'success'
          );
        }
        setBarcodeQuery(''); // Clear immediately for next scan
      }
    }
  };

  const handleBarcodeSubmit = (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    const barcode = barcodeQuery.trim();
    if (!barcode) return;

    const foundMed = medicines.find(m => m.barcode === barcode || m.id === barcode);
    if (foundMed) {
      if (foundMed.quantity <= 0) {
        triggerToast(
          lang === 'ar' 
            ? `عذراً، ${foundMed.tradeName} غير متوفر في المخزن!` 
            : `Sorry, ${foundMed.tradeName} is out of stock!`, 
          'info'
        );
      } else {
        handleAddToCart(foundMed);
        triggerToast(
          t.barcodeAddedToCart.replace('{name}', foundMed.tradeName), 
          'success'
        );
      }
    } else {
      triggerToast(t.barcodeNotFound, 'info');
    }
    setBarcodeQuery(''); // Clear immediately for next scan
  };

  // Adjust item quantities
  const handleUpdateQuantity = (medicineId: string, soldAs: 'major' | 'minor', newQty: number, maxQtyMinor: number) => {
    if (newQty <= 0) {
      handleRemoveFromCart(medicineId, soldAs);
      return;
    }
    const item = cart.find(i => i.medicine.id === medicineId && i.soldAs === soldAs);
    if (!item) return;

    // Calculate needed minor units
    const unitsPerMajor = item.medicine.unitsPerMajor || 10;
    const neededMinor = soldAs === 'major' ? newQty * unitsPerMajor : newQty;

    // Check total minor units needed for other cart items of the same medicine
    const otherItemsMinor = cart
      .filter(i => i.medicine.id === medicineId && i.soldAs !== soldAs)
      .reduce((sum, i) => sum + (i.soldAs === 'major' ? i.quantity * (i.medicine.unitsPerMajor || 10) : i.quantity), 0);

    if (neededMinor + otherItemsMinor > maxQtyMinor) {
      triggerToast(lang === 'ar' ? 'عذراً، تم الوصول للحد الأقصى للمخزون المتوفر!' : 'Maximum available stock exceeded!', 'info');
      return;
    }

    setCart(prev => prev.map(i => 
      (i.medicine.id === medicineId && i.soldAs === soldAs) ? { ...i, quantity: newQty } : i
    ));
  };

  const handleRemoveFromCart = (medicineId: string, soldAs: 'major' | 'minor') => {
    setCart(prev => prev.filter(item => !(item.medicine.id === medicineId && item.soldAs === soldAs)));
  };

  const handleToggleSoldAs = (medicineId: string, currentSoldAs: 'major' | 'minor', newSoldAs: 'major' | 'minor') => {
    setCart(prev => prev.map(item => {
      if (item.medicine.id === medicineId && item.soldAs === currentSoldAs) {
        const unitsPerMajor = item.medicine.unitsPerMajor || 10;
        let newQty = item.quantity;
        if (currentSoldAs === 'major' && newSoldAs === 'minor') {
          newQty = item.quantity * unitsPerMajor;
        } else if (currentSoldAs === 'minor' && newSoldAs === 'major') {
          newQty = Math.max(1, Math.floor(item.quantity / unitsPerMajor));
        }
        return {
          ...item,
          soldAs: newSoldAs,
          quantity: newQty
        };
      }
      return item;
    }));
  };

  // Check if selected customer is VIP / Special Customer (not a cash customer)
  const isVipCustomer = Boolean(
    selectedCustomer &&
    selectedCustomer.code !== '0000' &&
    selectedCustomer.type !== 'نقدي' &&
    selectedCustomer.type !== 'عميل نقدي' &&
    (selectedCustomer.isVip || selectedCustomer.type === 'عميل مميز' || selectedCustomer.type === 'عميل مسجل' || selectedCustomer.code !== '0000')
  );

  // Subtotal & Billing Mathematics
  const subtotal = cart.reduce((acc, curr) => {
    const price = getMedicinePrice(curr.medicine, curr.soldAs, pricingMode);
    return acc + (price * curr.quantity);
  }, 0);

  // VIP Customer Discount applies ONLY when a VIP customer is selected
  const discountAmount = (cart.length > 0 && isVipCustomer)
    ? (selectedCustomer.discountRate && selectedCustomer.discountRate > 0
        ? (subtotal * selectedCustomer.discountRate / 100)
        : 5.00)
    : 0.00;

  const taxAmount = (subtotal * settings.taxRate) / 100;
  const grandTotal = Math.max(0, subtotal + taxAmount - discountAmount);

  // Complete checkout
  const handleCheckout = (paymentMethod: 'cash' | 'card' | 'deferred') => {
    if (cart.length === 0) {
      triggerToast(t.cartEmpty, 'info');
      return;
    }

    // Build the completed transaction object
    const itemsList: TransactionItem[] = cart.map(item => {
      const price = getMedicinePrice(item.medicine, item.soldAs, pricingMode);
      const defaultMajorLabel = lang === 'ar' ? 'علبة' : 'box';
      const defaultMinorLabel = lang === 'ar' ? 'شريط' : 'strip';

      return {
        medicineId: item.medicine.id,
        tradeName: item.medicine.tradeName,
        price,
        quantity: item.quantity,
        soldAs: item.soldAs,
        unitName: item.soldAs === 'major' ? (item.medicine.unitMajor || defaultMajorLabel) : (item.medicine.unitMinor || defaultMinorLabel)
      };
    });

    const now = new Date();
    const formattedDate = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, '0')}-${String(now.getDate()).padStart(2, '0')} ${String(now.getHours()).padStart(2, '0')}:${String(now.getMinutes()).padStart(2, '0')}`;

    const newTx: Transaction = {
      id: `new-${Date.now()}`,
      invoiceNumber: invoiceNumber.replace('INV-', ''),
      customerName: selectedCustomer.name,
      customerCode: selectedCustomer.code,
      date: formattedDate,
      itemsCount: cart.reduce((acc, curr) => acc + curr.quantity, 0),
      subtotal,
      discountAmount,
      total: grandTotal,
      status: 'completed',
      paymentMethod,
      pricingMode,
      items: itemsList
    };

    // 1. Save Transaction to local history
    onAddTransaction(newTx);

    // 2. Adjust inventories dynamically
    cart.forEach(item => {
      const unitsPerMajor = item.medicine.unitsPerMajor || 10;
      const qtyToSubtract = item.soldAs === 'major' ? item.quantity * unitsPerMajor : item.quantity;
      onUpdateInventory(item.medicine.id, -qtyToSubtract);
    });

    // 3. Show thermal paper receipt modal
    setCheckoutReceipt(newTx);

    // 4. Reset Cart State
    setCart([]);
    regenerateInvoice();
    triggerToast(t.checkoutSuccess, 'success');
  };

  // Filter Catalog
  const filteredMedicines = medicines.filter(med => {
    const matchesSearch = med.tradeName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          med.genericName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          med.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    if (selectedCategory === 'all') return matchesSearch;
    if (selectedCategory === 'best') return matchesSearch && ['med-1', 'med-2', 'med-3'].includes(med.id);
    if (selectedCategory === 'cold') return matchesSearch && med.category === 'أدوية براد';
    if (selectedCategory === 'pain') return matchesSearch && med.category === 'مسكنات';
    
    return matchesSearch;
  });

  return (
    <div className="page-enter grid grid-cols-1 lg:grid-cols-12 gap-6 pb-10 items-start" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      
      {/* Toast Floating alert notification */}
      {showToast.visible && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100]">
          <div className="bg-neutral-950 text-white px-6 py-4 rounded-none flex items-center gap-3 border border-neutral-750 font-serif italic text-xs">
            <span className="w-1.5 h-1.5 bg-white animate-ping"></span>
            <span>{showToast.message}</span>
          </div>
        </div>
      )}

      {/* LEFT COLUMN: Receipt, Shopping Cart, Totals (Width: 400px - 450px) */}
      <section className="lg:col-span-5 xl:col-span-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col max-h-[85vh] sticky top-6">
        
        {/* Invoice List Header with Secret Discrete Mode Toggle */}
        <div className="p-4 bg-[#DEDCD7]/40 dark:bg-neutral-800/40 flex justify-between items-center border-b border-[#D4D1CC] dark:border-neutral-800 select-none"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="flex items-center gap-2">
            <span className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white">{t.currentInvoice}</span>
            {/* Subtle stealth mode dot indicator - only visible to knowing operator */}
            <button
              type="button"
              onClick={() => {
                setPricingMode(prev => {
                  const next = prev === 'pharmacy' ? 'moh' : 'pharmacy';
                  triggerToast(next === 'moh' ? 'وضع التسعيرة 2' : 'وضع التسعيرة 1', 'info');
                  return next;
                });
              }}
              title="تغيير النمط"
              className="w-2 h-2 rounded-full cursor-pointer transition-all hover:scale-150"
              style={{ backgroundColor: pricingMode === 'moh' ? '#eab308' : 'transparent' }}
            />
          </div>

          <span 
            onClick={() => {
              setPricingMode(prev => {
                const next = prev === 'pharmacy' ? 'moh' : 'pharmacy';
                triggerToast(next === 'moh' ? 'وضع التسعيرة 2' : 'وضع التسعيرة 1', 'info');
                return next;
              });
            }}
            title="النمط المالي (F8)"
            className="bg-neutral-900 dark:bg-white text-white dark:text-black px-3 py-1 rounded-none text-[10px] font-mono font-bold tracking-widest cursor-pointer hover:opacity-80 transition-all select-none"
          >
            {invoiceNumber}
          </span>
        </div>

        {/* Dynamic Shopping Cart List */}
        <div className="flex-grow overflow-y-auto p-4 space-y-3 no-scrollbar min-h-[300px]">
          {cart.length === 0 ? (
            <div className="flex flex-col items-center justify-center h-full text-center text-neutral-400 dark:text-neutral-500 py-12">
              <ShoppingBag className="w-10 h-10 stroke-1 mb-2 opacity-60" />
              <p className="text-[11px] font-serif italic px-6 leading-relaxed">{t.cartEmpty}</p>
            </div>
          ) : (
            cart.map((item) => {
              const itemPrice = getMedicinePrice(item.medicine, item.soldAs, pricingMode);
              const itemTotal = itemPrice * item.quantity;
              const hasSplitUnits = !!(item.medicine.unitsPerMajor && item.medicine.unitsPerMajor > 1);

              return (
                <div 
                  key={`${item.medicine.id}-${item.soldAs}`} 
                  className="flex flex-col sm:flex-row sm:items-center justify-between p-3 bg-[#DEDCD7]/30 dark:bg-neutral-800/45 border border-[#D4D1CC] dark:border-neutral-800 rounded-none transition-all group gap-2"
                  style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                >
                  <div className="flex flex-col items-start text-right flex-1"
                    style={{ textAlign: isRtl ? 'right' : 'left', alignItems: isRtl ? 'flex-start' : 'flex-end' }}
                  >
                    <div className="flex items-center gap-1.5 flex-wrap">
                      <span className="font-serif italic font-bold text-neutral-900 dark:text-neutral-100 text-xs">{item.medicine.tradeName}</span>
                      {pricingMode === 'moh' && (
                        <span className="px-1 py-0.2 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 text-[8px] font-mono font-bold border border-amber-200 dark:border-amber-800">
                          🏛️ {isRtl ? 'تسعيرة الوزارة' : 'MoH'}
                        </span>
                      )}
                    </div>
                    <span className="text-[10px] font-mono text-neutral-500 mt-0.5">
                      {itemPrice.toFixed(2)} {currencySymbol} × {item.quantity}
                    </span>

                    {/* Split Unit Selector Switch */}
                    {hasSplitUnits && (
                      <div className="flex gap-1 mt-1.5 border border-[#D4D1CC]/60 dark:border-neutral-700/60 p-0.5 bg-white/50 dark:bg-neutral-900/40 text-[9px] font-bold">
                        <button
                          onClick={() => handleToggleSoldAs(item.medicine.id, item.soldAs, 'major')}
                          className={`px-1.5 py-0.5 rounded-none cursor-pointer transition-all ${
                            item.soldAs === 'major'
                              ? 'bg-neutral-950 text-white dark:bg-white dark:text-black font-extrabold'
                              : 'text-neutral-500 hover:bg-[#DEDCD7]/50 dark:hover:bg-neutral-800'
                          }`}
                        >
                          {item.medicine.unitMajor || (lang === 'ar' ? 'علبة' : 'box')}
                        </button>
                        <button
                          onClick={() => handleToggleSoldAs(item.medicine.id, item.soldAs, 'minor')}
                          className={`px-1.5 py-0.5 rounded-none cursor-pointer transition-all ${
                            item.soldAs === 'minor'
                              ? 'bg-neutral-950 text-white dark:bg-white dark:text-black font-extrabold'
                              : 'text-neutral-500 hover:bg-[#DEDCD7]/50 dark:hover:bg-neutral-800'
                          }`}
                        >
                          {item.medicine.unitMinor || (lang === 'ar' ? 'شريط' : 'strip')}
                        </button>
                      </div>
                    )}
                  </div>

                  <div className="flex items-center gap-4 justify-between sm:justify-end w-full sm:w-auto font-mono" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                    {/* Quantity adjustment buttons */}
                    <div className="flex items-center gap-1 bg-[#EBE9E5] dark:bg-neutral-950 border border-[#D4D1CC] dark:border-neutral-800 rounded-none p-0.5">
                      <button 
                        onClick={() => handleUpdateQuantity(item.medicine.id, item.soldAs, item.quantity - 1, item.medicine.quantity)}
                        className="w-5 h-5 rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-850 flex items-center justify-center text-neutral-600 dark:text-neutral-400 cursor-pointer text-xs"
                      >
                        <Minus className="w-3 h-3" />
                      </button>
                      <span className="w-5 text-center text-xs font-bold font-mono">{item.quantity}</span>
                      <button 
                        onClick={() => handleUpdateQuantity(item.medicine.id, item.soldAs, item.quantity + 1, item.medicine.quantity)}
                        className="w-5 h-5 rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-850 flex items-center justify-center text-neutral-600 dark:text-neutral-400 cursor-pointer text-xs"
                      >
                        <Plus className="w-3 h-3" />
                      </button>
                    </div>

                    {/* Pricing Total */}
                    <span className="font-bold text-neutral-900 dark:text-white text-xs font-mono tracking-tight min-w-[70px] text-left sm:text-right" style={{ textAlign: isRtl ? 'left' : 'right' }}>
                      {itemTotal.toFixed(2)} {currencySymbol}
                    </span>

                    {/* Add to Shortages button */}
                    <button 
                      onClick={() => handleAddToShortages(item.medicine.tradeName, item.medicine.category, item.medicine.company)}
                      className="text-amber-800 dark:text-amber-400 hover:text-amber-950 dark:hover:text-amber-300 p-1 hover:bg-amber-100 dark:hover:bg-amber-950/40 rounded-none cursor-pointer transition-colors"
                      title={lang === 'ar' ? 'إضافة إلى قائمة النقوصات' : 'Add to Shortages'}
                    >
                      <ClipboardList className="w-3.5 h-3.5" />
                    </button>

                    {/* Delete Trigger */}
                    <button 
                      onClick={() => handleRemoveFromCart(item.medicine.id, item.soldAs)}
                      className="text-red-600 hover:text-red-700 p-1 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-none cursor-pointer transition-colors"
                      title={lang === 'ar' ? 'حذف من السلة' : 'Remove from Cart'}
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                </div>
              );
            })
          )}
        </div>

        {/* Customer Quick Profile widget */}
        <div className="px-4 py-3 bg-[#DEDCD7]/40 dark:bg-neutral-800/40 border-t border-[#D4D1CC] dark:border-neutral-800 flex items-center gap-3"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className={`w-8 h-8 rounded-none flex items-center justify-center font-bold text-xs ${
            isVipCustomer ? 'bg-amber-500 text-black' : 'bg-neutral-900 dark:bg-neutral-800 text-white'
          }`}>
            <User className="w-3.5 h-3.5" />
          </div>
          <div className="flex-1 text-right flex flex-col overflow-hidden"
            style={{ textAlign: isRtl ? 'right' : 'left', alignItems: isRtl ? 'flex-start' : 'flex-end' }}
          >
            <div className="flex items-center gap-1.5 max-w-full">
              <span className="font-serif italic font-bold text-xs text-neutral-900 dark:text-neutral-200 truncate">
                {selectedCustomer.name}
              </span>
              {isVipCustomer && (
                <span className="px-1.5 py-0.5 bg-amber-100 dark:bg-amber-950/80 text-amber-900 dark:text-amber-300 text-[9px] font-bold uppercase tracking-wider font-mono shrink-0">
                  ✨ {isRtl ? 'عميل مميز' : 'VIP'}
                </span>
              )}
            </div>
            <span className="text-[10px] text-neutral-500 font-mono mt-0.5">
              {isVipCustomer 
                ? (isRtl ? `ينطبق خصم عميل مميز (-${discountAmount.toFixed(2)} ${currencySymbol})` : `VIP Discount Applied (-${discountAmount.toFixed(2)} ${currencySymbol})`)
                : (isRtl ? 'عميل نقدي - بدون خصم' : 'Cash Customer - No Discount')
              }
            </span>
          </div>
          <button 
            onClick={() => setIsCustomerModalOpen(true)}
            className="p-1.5 hover:bg-neutral-300 dark:hover:bg-neutral-700 rounded-none text-neutral-500 hover:text-neutral-900 dark:hover:text-white cursor-pointer transition-all border border-transparent hover:border-[#D4D1CC]"
            title={isRtl ? 'تغيير العميل' : 'Change Customer'}
          >
            <Edit2 className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Receipt Billing Maths Summary */}
        <div className="p-4 bg-[#DEDCD7] dark:bg-neutral-900 border-t border-[#D4D1CC] dark:border-neutral-800 space-y-3 rounded-none">
          <div className="space-y-1.5 text-xs text-neutral-600 dark:text-neutral-400">
            <div className="flex justify-between" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              <span>{t.subtotal}</span>
              <span className="font-mono font-bold text-neutral-900 dark:text-white">{subtotal.toFixed(2)} {currencySymbol}</span>
            </div>
            <div className="flex justify-between" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              <span>{t.vatTax.replace('{rate}', settings.taxRate.toString())}</span>
              <span className="font-mono font-bold text-neutral-900 dark:text-white">{taxAmount.toFixed(2)} {currencySymbol}</span>
            </div>
            {cart.length > 0 && discountAmount > 0 && (
              <div className="flex justify-between text-emerald-800 dark:text-emerald-400 font-serif italic" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                <span className="flex items-center gap-1">
                  <Sparkles className="w-3.5 h-3.5 text-amber-500 inline" />
                  {t.loyaltyDiscount} ({selectedCustomer.name})
                </span>
                <span className="font-mono font-bold">-{discountAmount.toFixed(2)} {currencySymbol}</span>
              </div>
            )}
            <div className="flex justify-between font-bold text-base text-neutral-900 dark:text-white pt-2 border-t border-[#D4D1CC] dark:border-neutral-800"
              style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
            >
              <span className="font-serif italic">{t.total}</span>
              <span className="font-mono">{grandTotal.toFixed(2)} {currencySymbol}</span>
            </div>
          </div>

          {/* Checkout triggers F1/F2/F3 */}
          <div className="grid grid-cols-3 gap-2 pt-2">
            <button 
              onClick={() => handleCheckout('cash')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none cursor-pointer transition-all border border-neutral-900 dark:border-neutral-700"
            >
              <svg className="w-4 h-4 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
                <rect x="2" y="5" width="20" height="14" rx="0"/>
                <line x1="2" y1="10" x2="22" y2="10"/>
                <circle cx="6" cy="14" r="1"/>
                <circle cx="10" cy="14" r="1"/>
              </svg>
              <span className="text-[10px] font-bold tracking-widest uppercase">{t.payCash}</span>
            </button>
            <button 
              onClick={() => handleCheckout('card')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none cursor-pointer transition-all border border-neutral-900 dark:border-neutral-700"
            >
              <CreditCard className="w-4 h-4" />
              <span className="text-[10px] font-bold tracking-widest uppercase">{t.payCard}</span>
            </button>
            <button 
              onClick={() => triggerToast(t.printingReceipt, 'info')}
              className="flex flex-col items-center justify-center gap-1.5 py-3 px-1 border border-neutral-900 dark:border-neutral-700 text-neutral-900 dark:text-white bg-[#EBE9E5] dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 rounded-none cursor-pointer transition-all"
            >
              <Printer className="w-4 h-4" />
              <span className="text-[10px] font-bold tracking-widest uppercase">{t.print}</span>
            </button>
          </div>
        </div>
      </section>

      {/* RIGHT COLUMN: Search, Cam simulation, Quick access, Product catalogs */}
      <section className="lg:col-span-7 xl:col-span-8 flex flex-col gap-4 overflow-hidden">
        
        {/* Dual Pricing System Switcher Bar */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 p-3.5 flex flex-col sm:flex-row items-center justify-between gap-3"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="flex items-center gap-2.5">
            <span className={`w-3 h-3 rounded-full shrink-0 ${pricingMode === 'moh' ? 'bg-amber-500 animate-pulse' : 'bg-emerald-500'}`}></span>
            <div className="flex flex-col text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
              <span className="font-serif italic font-bold text-xs text-neutral-900 dark:text-white flex items-center gap-1.5">
                {t.pricingSystem}
              </span>
              <span className="text-[10px] text-neutral-500 dark:text-neutral-400 font-mono font-medium">
                {pricingMode === 'moh' ? `🏛️ ${t.iraqiMohPricing}` : `💊 ${t.pharmacyPricing}`}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <div className="flex border border-neutral-900/50 dark:border-neutral-700 p-0.5 bg-white/70 dark:bg-neutral-900 w-full sm:w-auto">
              <button
                type="button"
                onClick={() => {
                  setPricingMode('pharmacy');
                  triggerToast(t.pricingSwitchedToPharmacy, 'info');
                }}
                className={`px-3 py-1.5 text-xs font-bold font-serif italic transition-all cursor-pointer flex-1 sm:flex-none flex items-center justify-center gap-1.5 ${
                  pricingMode === 'pharmacy'
                    ? 'bg-neutral-950 text-white dark:bg-white dark:text-black shadow-sm font-extrabold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                <span>💊</span>
                <span>{t.pharmacyPricing}</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPricingMode('moh');
                  triggerToast(t.pricingSwitchedToMoh, 'info');
                }}
                className={`px-3 py-1.5 text-xs font-bold font-serif italic transition-all cursor-pointer flex-1 sm:flex-none flex items-center justify-center gap-1.5 ${
                  pricingMode === 'moh'
                    ? 'bg-amber-600 text-white dark:bg-amber-500 dark:text-black shadow-sm font-extrabold'
                    : 'text-neutral-600 dark:text-neutral-400 hover:text-neutral-900 dark:hover:text-white'
                }`}
              >
                <span>🏛️</span>
                <span>{t.iraqiMohPricing}</span>
              </button>
            </div>

            {/* Keyboard Shortcut Badge */}
            <span 
              className="px-2.5 py-1.5 bg-neutral-200 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 text-[10px] font-mono font-bold text-neutral-800 dark:text-neutral-200 shrink-0 hidden md:inline-block cursor-help"
              title={t.togglePricingShortcut}
            >
              [F8 / Alt+P]
            </span>
          </div>
        </div>
        
        {/* Search & Barcode Dual Gateways Row */}
        <div className="grid grid-cols-1 md:grid-cols-12 gap-4">
          {/* Text/Search Query bar */}
          <div className="md:col-span-7 relative">
            <Search className="absolute right-4 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input 
              id="med-search-input"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pr-12 pl-4 py-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 rounded-none outline-none transition-all font-serif italic text-neutral-900 dark:text-neutral-100 text-sm"
              placeholder={t.searchPlaceholder}
              type="text"
            />
            <div className="absolute left-4 top-1/2 -translate-y-1/2 flex gap-2">
              <button 
                onClick={handleToggleScanner}
                className={`p-2 rounded-none transition-all flex items-center justify-center cursor-pointer border ${
                  isScannerOpen 
                    ? 'bg-red-900 text-white animate-pulse border-red-800' 
                    : 'bg-[#DEDCD7] hover:bg-[#D4D1CC] dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-neutral-300 border-[#D4D1CC] dark:border-neutral-700'
                }`}
                title={t.openCamera}
              >
                <Camera className="w-4 h-4" />
              </button>
            </div>
          </div>

          {/* Active Barcode Reader Field (Auto-Add & Auto-Clear) */}
          <div className="md:col-span-5 relative">
            <form onSubmit={handleBarcodeSubmit} className="relative w-full">
              <span className="absolute right-4 top-1/2 -translate-y-1/2 flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-red-600 animate-pulse"></span>
                <svg className="w-4 h-4 text-neutral-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                  <path d="M3 5h2v14H3zm4 0h1v14H7zm3 0h3v14h-3zm5 0h1v14h-1zm3 0h3v14h-3z" />
                </svg>
              </span>
              <input 
                ref={barcodeInputRef}
                id="barcode-scanner-input"
                value={barcodeQuery}
                onChange={(e) => handleBarcodeChange(e.target.value)}
                className="w-full pr-14 pl-4 py-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] border border-red-900/45 dark:border-red-500/30 focus:border-red-600 dark:focus:border-red-500 rounded-none outline-none transition-all font-mono text-neutral-900 dark:text-neutral-100 text-sm placeholder:text-neutral-450 dark:placeholder:text-neutral-500"
                placeholder={t.barcodeInputPlaceholder}
                type="text"
                autoComplete="off"
              />
            </form>
          </div>
        </div>

        {/* Camera Scanner Simulated screen overlay */}
        {isScannerOpen && (
          <div className="relative rounded-none overflow-hidden bg-black aspect-[21/9] flex flex-col items-center justify-center border border-[#D4D1CC] dark:border-neutral-850">
            {/* Pharmacy scanner medical clinical background overlay */}
            <div className="absolute inset-0 w-full h-full bg-cover bg-center opacity-65"
              style={{ backgroundImage: `url('https://lh3.googleusercontent.com/aida-public/AB6AXuCttzPQSWAV2ljG7nQrtwaF1cl6sy-ktq8cnBMfhZnO--kOCFmIrdxOmcOM1n8EIMTF_FFyzg4fu0Nj1YD8nUEyUn0da8hqZgoBWqSd_qvb5ZYpPPmPQk9iCoTJUFkQF8jS-G5vbZR3ZILHgameYkLWksztRjL5enl5moCP9-Cq1jMOCR5gbYdYC_tHySXOEEv2Lcub2LAP90FepuWEF8HJCGX71j84_KfqUIBW5NB0_KNj1BtJ1aoc68CmHJOP1efVXhX2ugb6lA')` }}
            ></div>
            <div className="relative z-10 w-48 h-28 border-2 border-neutral-900 dark:border-white rounded-none relative overflow-hidden flex items-center justify-center bg-black/30 backdrop-blur-[1px]">
              {/* Laser beam laser overlay */}
              <div className="scanner-line absolute left-0 right-0 h-0.5 bg-neutral-900 dark:bg-white shadow-none"></div>
            </div>
            <div className="absolute bottom-4 left-1/2 -translate-x-1/2 bg-black/70 backdrop-blur-md px-4 py-2 rounded-none text-white text-[10px] font-bold tracking-widest uppercase flex items-center gap-2 border border-neutral-800">
              <span className="w-1.5 h-1.5 rounded-full bg-white animate-ping"></span>
              {t.scanningBarcode}
            </div>
          </div>
        )}

        {/* Digital Prescription AI Area */}
        <div 
          onClick={handleAnalyzePrescription}
          className={`p-4 border border-dashed border-neutral-900/40 dark:border-white/30 bg-[#DEDCD7]/30 dark:bg-neutral-800/10 rounded-none flex items-center gap-4 hover:border-neutral-900 dark:hover:border-white transition-colors cursor-pointer group select-none ${
            isAnalyzingPrescription ? 'opacity-80 pointer-events-none' : ''
          }`}
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="w-10 h-10 bg-neutral-900 dark:bg-white text-white dark:text-black rounded-none flex items-center justify-center shrink-0">
            <Sparkles className="w-4 h-4" />
          </div>
          <div className="text-right flex flex-col items-start"
            style={{ textAlign: isRtl ? 'right' : 'left', alignItems: isRtl ? 'flex-start' : 'flex-end' }}
          >
            <h4 className="font-serif italic font-bold text-neutral-950 dark:text-white text-sm flex items-center gap-1">
              {t.scanPrescription}
            </h4>
            <p className="text-[10px] text-neutral-500 dark:text-neutral-400 mt-1 uppercase tracking-wide leading-normal font-bold">{t.prescriptionDesc}</p>
          </div>
        </div>

        {/* Quick Access filters */}
        <div className="flex items-center justify-between mt-2" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
          <h3 className="text-xs font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-1.5">
            <span className="w-1 h-3.5 bg-neutral-900 dark:bg-white"></span>
            {t.quickAccess}
          </h3>
          <div className="flex gap-2 overflow-x-auto no-scrollbar py-1">
            {[
              { id: 'all', label: t.allMeds },
              { id: 'best', label: t.bestSellers },
              { id: 'cold', label: t.coldMeds },
              { id: 'pain', label: t.painkillers }
            ].map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-3 py-1.5 rounded-none text-[10px] uppercase tracking-widest font-bold transition-all border shrink-0 cursor-pointer ${
                  selectedCategory === cat.id 
                    ? 'bg-neutral-900 border-neutral-900 text-white dark:bg-white dark:text-black dark:border-white' 
                    : 'bg-[#EBE9E5] dark:bg-neutral-900 border-[#D4D1CC] dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 hover:bg-[#DEDCD7] dark:hover:bg-neutral-800'
                }`}
              >
                {cat.label}
              </button>
            ))}
          </div>
        </div>

        {/* Product Grid Catalog (Bento) */}
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4 overflow-y-auto max-h-[50vh] pr-1 pb-10 no-scrollbar">
          {filteredMedicines.map((med) => {
            const isLowStock = med.quantity < 20 && med.status !== 'expired';
            const isOutOfStock = med.quantity <= 0;
            const isExpired = med.status === 'expired';

            return (
              <div 
                key={med.id} 
                className={`bg-[#EBE9E5] dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 p-4 rounded-none hover:border-neutral-950 dark:hover:border-white transition-all cursor-pointer group flex flex-col items-center text-center gap-3 relative ${
                  isOutOfStock ? 'opacity-60' : ''
                }`}
                onClick={() => handleAddToCart(med)}
              >
                {/* Warning flags */}
                {isLowStock && (
                  <span className="absolute top-2 right-2 bg-amber-100 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 text-[9px] px-2 py-0.5 rounded-none font-bold border border-amber-200 dark:border-amber-900">
                    {t.lowStockBadge}
                  </span>
                )}
                {isExpired && (
                  <span className="absolute top-2 right-2 bg-red-100 dark:bg-red-950/40 text-red-900 dark:text-red-300 text-[9px] px-2 py-0.5 rounded-none font-bold border border-red-200 dark:border-red-900">
                    {t.expired}
                  </span>
                )}

                {/* Image */}
                <div className="w-16 h-16 rounded-none overflow-hidden bg-[#DEDCD7] dark:bg-neutral-800 flex items-center justify-center border border-[#D4D1CC] dark:border-neutral-700">
                  {med.image ? (
                    <img 
                      className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-300" 
                      alt={med.tradeName} 
                      src={med.image} 
                      referrerPolicy="no-referrer"
                    />
                  ) : (
                    <FileText className="w-6 h-6 text-neutral-400 dark:text-neutral-500 stroke-1" />
                  )}
                </div>

                {/* Details */}
                <div className="flex flex-col items-center overflow-hidden w-full">
                  <span className="font-serif italic font-bold text-neutral-900 dark:text-neutral-100 text-xs truncate w-full">{med.tradeName}</span>
                  <span className="text-[10px] text-neutral-500 dark:text-neutral-400 truncate w-full mt-0.5">{med.genericName}</span>
                  <div className="flex flex-col items-center mt-2">
                    <span className="text-neutral-950 dark:text-white font-extrabold text-xs font-mono">
                      {getMedicinePrice(med, 'minor', pricingMode).toFixed(2)} {currencySymbol}
                    </span>
                    {pricingMode === 'moh' && (
                      <span className="mt-0.5 px-1 py-0.2 bg-amber-100 dark:bg-amber-950/60 text-amber-900 dark:text-amber-300 text-[8px] font-mono font-bold border border-amber-200 dark:border-amber-800">
                        🏛️ {isRtl ? 'تسعيرة الوزارة' : 'MoH Price'}
                      </span>
                    )}
                  </div>
                </div>

                {/* Add button trigger & Shortages button */}
                <div className="w-full flex gap-1 mt-1">
                  <button 
                    disabled={isOutOfStock}
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToCart(med);
                    }}
                    className="flex-1 py-2 bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-800 dark:text-neutral-300 text-[9px] uppercase tracking-widest font-bold rounded-none transition-all group-hover:bg-neutral-950 group-hover:text-white dark:group-hover:bg-white dark:group-hover:text-black cursor-pointer disabled:cursor-not-allowed"
                  >
                    {isOutOfStock ? t.outOfStock : t.addToCart}
                  </button>
                  <button
                    type="button"
                    onClick={(e) => {
                      e.stopPropagation();
                      handleAddToShortages(med.tradeName, med.category, med.company);
                    }}
                    className="px-2 py-2 bg-[#DEDCD7] dark:bg-neutral-800 hover:bg-amber-800 hover:text-white dark:hover:bg-amber-600 text-amber-900 dark:text-amber-300 rounded-none transition-colors cursor-pointer"
                    title={lang === 'ar' ? 'إضافة الدواء إلى قائمة النقوصات' : 'Add to Shortages'}
                  >
                    <ClipboardList className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </section>

      {/* MODAL 1: THERMAL PAPER RECEIPT COMPLETED VOUCHER */}
      {checkoutReceipt && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-sm w-full border border-neutral-900 dark:border-neutral-800 shadow-none relative flex flex-col gap-4">
            
            {/* Header close trigger */}
            <button 
              onClick={() => setCheckoutReceipt(null)}
              className="absolute top-4 right-4 text-neutral-500 hover:text-neutral-950 dark:hover:text-white p-1 rounded-none cursor-pointer"
            >
              <X className="w-4 h-4" />
            </button>

            {/* Content Receipt Frame */}
            <div className="text-center flex flex-col items-center">
              <div className="w-10 h-10 rounded-none bg-neutral-950 dark:bg-white text-white dark:text-black flex items-center justify-center mb-2">
                <CheckCircle className="w-5 h-5" />
              </div>
              <h3 className="font-serif italic font-bold text-sm text-neutral-900 dark:text-white">{t.checkoutSuccess}</h3>
              <p className="text-[10px] text-neutral-500 uppercase tracking-widest font-bold mt-1">{t.printingReceipt}</p>
            </div>

            {/* Physical Receipt details thermal mockup */}
            <div className="bg-white dark:bg-neutral-900 p-4 rounded-none border border-[#D4D1CC] dark:border-neutral-850 text-xs font-mono text-neutral-800 dark:text-neutral-200 space-y-4">
              <div className="text-center space-y-0.5 border-b border-dashed border-neutral-300 dark:border-neutral-700 pb-3">
                <h4 className="font-serif italic font-bold text-sm text-neutral-900 dark:text-white">{settings.pharmacyName}</h4>
                <p className="text-[10px] text-neutral-500">TEL: {settings.phone}</p>
                <p className="text-[10px] text-neutral-500">{checkoutReceipt.date}</p>
                <p className="text-[10px] text-neutral-900 dark:text-white font-bold">INV: #{checkoutReceipt.invoiceNumber}</p>
                <div className="mt-1 inline-block px-2 py-0.5 text-[9px] font-sans font-bold bg-neutral-100 dark:bg-neutral-800 text-neutral-800 dark:text-neutral-200 border border-neutral-200 dark:border-neutral-700">
                  {checkoutReceipt.pricingMode === 'moh' ? `🏛️ ${t.iraqiMohPricing}` : `💊 ${t.pharmacyPricing}`}
                </div>
              </div>

              {/* Items listing */}
              <div className="space-y-2 border-b border-dashed border-neutral-300 dark:border-neutral-700 pb-3">
                {checkoutReceipt.items.map((item, index) => (
                  <div key={index} className="flex justify-between items-center text-xs">
                    <span className="truncate max-w-[170px]">{item.tradeName} (x{item.quantity} {item.unitName || ''})</span>
                    <div className="flex items-center gap-1.5 shrink-0">
                      <span>{(item.price * item.quantity).toFixed(2)} {currencySymbol}</span>
                      <button
                        type="button"
                        onClick={() => handleAddToShortages(item.tradeName)}
                        className="text-amber-800 hover:text-amber-950 dark:text-amber-400 dark:hover:text-amber-200 p-1 hover:bg-amber-100 dark:hover:bg-amber-950/40 rounded-none cursor-pointer"
                        title={lang === 'ar' ? 'إضافة إلى النقوصات' : 'Add to Shortages'}
                      >
                        <ClipboardList className="w-3.5 h-3.5" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>

              {/* Add all receipt items to Shortages button */}
              <button 
                type="button"
                onClick={() => {
                  checkoutReceipt.items.forEach(item => {
                    handleAddToShortages(item.tradeName);
                  });
                }}
                className="w-full py-2 bg-amber-900/10 dark:bg-amber-950/40 text-amber-900 dark:text-amber-300 border border-amber-800/30 hover:bg-amber-900/20 font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-1.5 cursor-pointer transition-all"
              >
                <ClipboardList className="w-3.5 h-3.5" />
                <span>{lang === 'ar' ? 'إضافة جميع مواد الفاتورة إلى النقوصات' : 'Add All Receipt Items to Shortages'}</span>
              </button>

              {/* Receipt mathematics */}
              <div className="space-y-1">
                <div className="flex justify-between text-[10px]">
                  <span>{t.subtotal}</span>
                  <span>{(checkoutReceipt.total * 100 / (100 + settings.taxRate)).toFixed(2)} {currencySymbol}</span>
                </div>
                <div className="flex justify-between text-[10px]">
                  <span>TAX ({settings.taxRate}%)</span>
                  <span>{(checkoutReceipt.total * settings.taxRate / (100 + settings.taxRate)).toFixed(2)} {currencySymbol}</span>
                </div>
                {checkoutReceipt.discountAmount && checkoutReceipt.discountAmount > 0 ? (
                  <div className="flex justify-between text-[10px] text-emerald-700 dark:text-emerald-400 font-bold">
                    <span>DISCOUNT ({checkoutReceipt.customerName})</span>
                    <span>-{checkoutReceipt.discountAmount.toFixed(2)} {currencySymbol}</span>
                  </div>
                ) : null}
                <div className="flex justify-between font-bold text-sm text-neutral-900 dark:text-white pt-2 border-t border-dashed border-neutral-300 dark:border-neutral-700">
                  <span>TOTAL PAID</span>
                  <span>{checkoutReceipt.total.toFixed(2)} {currencySymbol}</span>
                </div>
              </div>

              <div className="text-center pt-2 text-[9px] text-neutral-400">
                <p>--- THANK YOU ---</p>
                <p>Pharmacist Admin: Dr. Walid</p>
              </div>
            </div>

            {/* Print and dismiss */}
            <div className="flex gap-2">
              <button 
                onClick={() => setCheckoutReceipt(null)}
                className="flex-1 py-2.5 bg-neutral-950 dark:bg-white text-white dark:text-black font-bold text-xs uppercase tracking-widest rounded-none cursor-pointer transition-all border border-neutral-950 dark:border-neutral-700"
              >
                OK
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: CUSTOMER SELECTION LIST */}
      {isCustomerModalOpen && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-md w-full border border-neutral-900 dark:border-neutral-800 shadow-2xl relative flex flex-col gap-4">
            
            <div className="flex justify-between items-center border-b border-[#D4D1CC] dark:border-neutral-800 pb-3" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              <div className="flex items-center gap-2">
                <User className="w-4 h-4 text-amber-600" />
                <h3 className="font-serif italic font-bold text-neutral-900 dark:text-white text-sm">{t.selectCustomer}</h3>
              </div>
              <button 
                onClick={() => {
                  setIsCustomerModalOpen(false);
                  setIsAddingNewCustomer(false);
                }} 
                className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white p-1 cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {!isAddingNewCustomer ? (
              <>
                {/* Customers selection list */}
                <div className="space-y-2 max-h-64 overflow-y-auto no-scrollbar">
                  {customers.map((cust) => {
                    const isCustVip = cust.code !== '0000' && cust.type !== 'نقدي' && cust.type !== 'عميل نقدي';
                    const isSelected = selectedCustomer.id === cust.id;

                    return (
                      <div 
                        key={cust.id}
                        onClick={() => {
                          setSelectedCustomer(cust);
                          setIsCustomerModalOpen(false);
                          triggerToast(
                            lang === 'ar' 
                              ? `تم اختيار العميل: ${cust.name}${isCustVip ? ' (ينطبق خصم عميل مميز ✨)' : ''}` 
                              : `Selected Customer: ${cust.name}`, 
                            'success'
                          );
                        }}
                        className={`p-3 rounded-none border flex items-center justify-between cursor-pointer transition-all ${
                          isSelected 
                            ? 'bg-neutral-950 text-white border-neutral-950 dark:bg-white dark:text-black dark:border-white font-bold font-serif italic' 
                            : 'bg-white border-[#D4D1CC] hover:bg-neutral-100 dark:bg-neutral-900 dark:border-neutral-800 hover:dark:bg-neutral-800 text-neutral-800 dark:text-neutral-300'
                        }`}
                        style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                      >
                        <div className="flex flex-col text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                          <div className="flex items-center gap-2">
                            <span className="text-xs font-bold">{cust.name}</span>
                            {isCustVip && (
                              <span className={`px-1.5 py-0.5 text-[9px] font-mono font-bold uppercase tracking-wider ${
                                isSelected ? 'bg-amber-400 text-black' : 'bg-amber-100 text-amber-900 dark:bg-amber-950 dark:text-amber-300'
                              }`}>
                                ✨ {isRtl ? 'عميل مميز' : 'VIP'}
                              </span>
                            )}
                          </div>
                          <span className={`text-[10px] font-mono mt-0.5 ${isSelected ? 'opacity-80' : 'text-neutral-500'}`}>
                            {isCustVip 
                              ? (isRtl ? `كود #${cust.code} - خصم مميز ينطبق` : `Code #${cust.code} - VIP Discount Eligible`)
                              : (isRtl ? 'نقدي (بدون خصم)' : 'Cash (No Discount)')
                            }
                          </span>
                        </div>

                        <span className="text-xs font-mono font-bold">
                          {cust.code === '0000' ? t.cashCustomer : `#${cust.code}`}
                        </span>
                      </div>
                    );
                  })}
                </div>

                {/* Button to add new VIP customer */}
                {onAddCustomer && (
                  <button
                    onClick={() => setIsAddingNewCustomer(true)}
                    className="w-full py-2.5 bg-amber-500 hover:bg-amber-600 text-neutral-950 font-bold text-xs uppercase tracking-wider rounded-none cursor-pointer transition-all flex items-center justify-center gap-2"
                  >
                    <Plus className="w-4 h-4" />
                    <span>{isRtl ? 'إضافة عميل مميز جديد ✨' : 'Add New VIP Customer ✨'}</span>
                  </button>
                )}
              </>
            ) : (
              /* Inline Form to Add New VIP Customer */
              <div className="space-y-4">
                <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-xs text-amber-900 dark:text-amber-300">
                  <p className="font-bold flex items-center gap-1.5">
                    <Sparkles className="w-4 h-4 text-amber-600" />
                    {isRtl ? 'تسجيل عميل مميز للاستفادة من الخصم' : 'Register New VIP Customer'}
                  </p>
                  <p className="text-[11px] mt-1 opacity-90">
                    {isRtl 
                      ? 'العملاء المميزون يستفيدون تلقائياً من خصم عميل مميز عند تحديدهم في الفاتورة.' 
                      : 'VIP customers automatically receive loyalty discount upon selection.'
                    }
                  </p>
                </div>

                <div className="space-y-3">
                  <div>
                    <label className="block text-xs font-bold text-neutral-800 dark:text-neutral-200 mb-1">
                      {isRtl ? 'اسم العميل المميز' : 'Customer Name'}
                    </label>
                    <input 
                      type="text"
                      value={newCustName}
                      onChange={(e) => setNewCustName(e.target.value)}
                      placeholder={isRtl ? 'مثال: أسامة علي' : 'e.g. Osama Ali'}
                      className="w-full p-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 text-xs text-neutral-900 dark:text-white rounded-none focus:outline-none focus:border-neutral-950"
                    />
                  </div>

                  <div>
                    <label className="block text-xs font-bold text-neutral-800 dark:text-neutral-200 mb-1">
                      {isRtl ? 'كود العميل المميز' : 'Customer Code'}
                    </label>
                    <input 
                      type="text"
                      value={newCustCode}
                      onChange={(e) => setNewCustCode(e.target.value)}
                      placeholder={isRtl ? 'مثال: 9021' : 'e.g. 9021'}
                      className="w-full p-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 text-xs text-neutral-900 dark:text-white rounded-none focus:outline-none focus:border-neutral-950 font-mono"
                    />
                  </div>
                </div>

                <div className="flex gap-2 pt-2">
                  <button
                    onClick={() => {
                      if (!newCustName.trim()) return;
                      const code = newCustCode.trim() || Math.floor(1000 + Math.random() * 9000).toString();
                      const created: Customer = {
                        id: `cust-${Date.now()}`,
                        name: newCustName.trim(),
                        type: 'عميل مميز',
                        code,
                        isVip: true,
                        discountRate: 5
                      };
                      if (onAddCustomer) {
                        onAddCustomer(created);
                      }
                      setSelectedCustomer(created);
                      setIsAddingNewCustomer(false);
                      setIsCustomerModalOpen(false);
                      setNewCustName('');
                      setNewCustCode('');
                      triggerToast(
                        isRtl 
                          ? `تم إضافة العميل المميز ${created.name} وتطبيقه على الفاتورة ✨` 
                          : `Added VIP Customer ${created.name}`, 
                        'success'
                      );
                    }}
                    className="flex-1 py-2.5 bg-neutral-950 dark:bg-white text-white dark:text-black font-bold text-xs uppercase tracking-wider rounded-none cursor-pointer"
                  >
                    {isRtl ? 'حفظ وتطبيق الخصم' : 'Save & Select'}
                  </button>
                  <button
                    onClick={() => setIsAddingNewCustomer(false)}
                    className="px-4 py-2.5 bg-neutral-200 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-300 font-bold text-xs rounded-none cursor-pointer"
                  >
                    {isRtl ? 'إلغاء' : 'Cancel'}
                  </button>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
