import React, { useState } from 'react';
import { AppSettings, PharmacyUser } from '../types';
import { translations } from '../translations';
import { 
  Save, HelpCircle, UserPlus, Info, Upload, Moon, Sun, Languages, 
  DollarSign, Database, Check, ShieldAlert, X, Cloud, CloudOff, 
  Download, Monitor, LogIn, LogOut, RefreshCw 
} from 'lucide-react';

interface SettingsViewProps {
  settings: AppSettings;
  lang: 'ar' | 'en';
  onUpdateSettings: (settings: AppSettings) => void;
  // Firebase Auth & Sync Props
  currentUser: any;
  onLoginWithGoogle: () => Promise<void>;
  onLogout: () => Promise<void>;
  onPushLocalToCloud: () => Promise<void>;
  isSyncing: boolean;
  // PWA & Desktop shortcuts
  deferredPrompt: any;
  onInstallPWA: () => void;
}

export default function SettingsView({ 
  settings, 
  lang, 
  onUpdateSettings,
  currentUser,
  onLoginWithGoogle,
  onLogout,
  onPushLocalToCloud,
  isSyncing,
  deferredPrompt,
  onInstallPWA
}: SettingsViewProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  // Local Form state pre-loaded
  const [pharmacyName, setPharmacyName] = useState(settings.pharmacyName);
  const [address, setAddress] = useState(settings.address);
  const [phone, setPhone] = useState(settings.phone);
  const [email, setEmail] = useState(settings.email);
  const [logo, setLogo] = useState(settings.logo);
  const [isDarkMode, setIsDarkMode] = useState(settings.isDarkMode);
  const [selectedLang, setSelectedLang] = useState<'ar' | 'en'>(settings.language);
  const [currency, setCurrency] = useState<'IQD' | 'SAR' | 'USD' | 'EGP'>(settings.currency);
  const [taxRate, setTaxRate] = useState(settings.taxRate);
  const [usersList, setUsersList] = useState<PharmacyUser[]>(settings.users);
  const [theme, setTheme] = useState<'vintage' | 'modern' | 'indigo' | 'emerald'>(settings.theme || 'vintage');

  // New User dialog state
  const [isAddUserOpen, setIsAddUserOpen] = useState(false);
  const [newUserName, setNewUserName] = useState('');
  const [newUserEmail, setNewUserEmail] = useState('');
  const [newUserRole, setNewUserRole] = useState<'pharmacist' | 'cashier'>('pharmacist');

  // Success trigger state
  const [showToast, setShowToast] = useState<{ visible: boolean; message: string }>({ visible: false, message: '' });

  const triggerToast = (message: string) => {
    setShowToast({ visible: true, message });
    setTimeout(() => {
      setShowToast({ visible: false, message: '' });
    }, 3000);
  };

  const downloadUrlShortcut = () => {
    const urlContent = `[InternetShortcut]\r\nURL=${window.location.origin}\r\nIconIndex=0\r\n`;
    const blob = new Blob([urlContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'صيدلية وليد خالد عبد.url';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    triggerToast(lang === 'ar' ? 'تم تحميل ملف الاختصار!' : 'Shortcut file downloaded!');
  };

  const downloadBatInstaller = () => {
    const batContent = `@echo off\r\n` +
      `chcp 65001 > nul\r\n` +
      `echo ===================================================\r\n` +
      `echo           تثبيت تطبيق صيدلية وليد خالد عبد على سطح المكتب     \r\n` +
      `echo           Installing WK Pharmacy Desktop Shortcut      \r\n` +
      `echo ===================================================\r\n` +
      `echo.\r\n` +
      `set SHORTCUT_PATH="%USERPROFILE%\\Desktop\\صيدلية وليد خالد عبد.url"\r\n` +
      `echo [InternetShortcut] > %SHORTCUT_PATH%\r\n` +
      `echo URL=${window.location.origin} >> %SHORTCUT_PATH%\r\n` +
      `echo IconIndex=0 >> %SHORTCUT_PATH%\r\n` +
      `echo.\r\n` +
      `echo [✓] تم التثبيت بنجاح! ستجد أيقونة الاختصار الآن على سطح المكتب.\r\n` +
      `echo [✓] Done! You will find the shortcut icon on your Desktop.\r\n` +
      `echo.\r\n` +
      `pause\r\n`;
    
    const blob = new Blob([batContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'صيدلية_وليد_خالد_عبد_سطح_المكتب.bat';
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    triggerToast(lang === 'ar' ? 'تم تحميل ملف التثبيت لويندوز!' : 'Windows installer downloaded!');
  };

  const handleForceUpdate = async () => {
    try {
      triggerToast(t.forceUpdateSuccess);
      if ('serviceWorker' in navigator) {
        const registrations = await navigator.serviceWorker.getRegistrations();
        for (const registration of registrations) {
          await registration.unregister();
        }
      }
      if ('caches' in window) {
        const keys = await caches.keys();
        await Promise.all(keys.map(key => caches.delete(key)));
      }
      setTimeout(() => {
        window.location.reload();
      }, 1000);
    } catch (err) {
      window.location.reload();
    }
  };

  // Handle Settings Submit
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    const updatedSettings: AppSettings = {
      pharmacyName,
      address,
      phone,
      email,
      logo,
      isDarkMode,
      language: selectedLang,
      currency,
      taxRate,
      users: usersList,
      theme
    };

    onUpdateSettings(updatedSettings);
    triggerToast(t.settingsSaved);
  };

  // Add simulated user
  const handleAddUser = (e: React.FormEvent) => {
    e.preventDefault();
    const newUser: PharmacyUser = {
      id: `user-${Date.now()}`,
      name: newUserName,
      email: newUserEmail,
      role: newUserRole,
      status: 'active',
      lastSeen: 'الآن'
    };
    const updatedUsers = [...usersList, newUser];
    setUsersList(updatedUsers);
    
    // Also update settings globally
    onUpdateSettings({
      ...settings,
      users: updatedUsers
    });

    setIsAddUserOpen(false);
    setNewUserName('');
    setNewUserEmail('');
    triggerToast(lang === 'ar' ? 'تمت إضافة المستخدم الجديد بنجاح!' : 'New user added successfully!');
  };

  // Handle download of data backup
  const handleDataBackup = () => {
    try {
      const dataStr = "data:text/json;charset=utf-8," + encodeURIComponent(
        JSON.stringify({
          settings,
          timestamp: new Date().toISOString()
        }, null, 2)
      );
      const downloadAnchor = document.createElement('a');
      downloadAnchor.setAttribute("href", dataStr);
      downloadAnchor.setAttribute("download", `wk_pharmacy_backup_${new Date().toISOString().slice(0, 10)}.json`);
      document.body.appendChild(downloadAnchor);
      downloadAnchor.click();
      downloadAnchor.remove();
      triggerToast(t.backupSuccess);
    } catch (e) {
      triggerToast(lang === 'ar' ? 'حدث خطأ أثناء عمل النسخة الاحتياطية' : 'Error generating backup file');
    }
  };

  return (
    <div className="page-enter space-y-6 pb-10" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      
      {/* Toast Alert */}
      {showToast.visible && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 z-[100] transform transition-all duration-300 scale-100 opacity-100">
          <div className="bg-neutral-950 text-white px-6 py-4 rounded-none flex items-center gap-3 shadow-none border border-neutral-800">
            <Check className="w-4 h-4 text-white" />
            <span className="font-mono text-xs font-bold uppercase tracking-widest">{showToast.message}</span>
          </div>
        </div>
      )}

      {/* Header section */}
      <section className="flex flex-col gap-1 text-right bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-850" style={{ textAlign: isRtl ? 'right' : 'left' }}>
        <h2 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.settingsTitle}</h2>
        <p className="text-neutral-500 uppercase tracking-widest font-mono text-[9px] font-bold">{t.settingsDesc}</p>
      </section>

      {/* Main Form container */}
      <form onSubmit={handleFormSubmit} className="space-y-6">
        
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          
          {/* Section 1: Pharmacy Identity Info */}
          <div className="lg:col-span-2 space-y-6">
            
            {/* Identity Card */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
              <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-2 mb-4"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                {t.pharmacyIdentity}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.pharmacyNameInput}</label>
                  <input 
                    required
                    value={pharmacyName}
                    onChange={(e) => setPharmacyName(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                    type="text"
                  />
                </div>
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.phoneInput}</label>
                  <input 
                    required
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                    type="text"
                  />
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.addressInput}</label>
                  <input 
                    required
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                    type="text"
                  />
                </div>
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.emailInput}</label>
                  <input 
                    required
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                    type="email"
                  />
                </div>
              </div>

              {/* Logo Drag-and-drop / selector */}
              <div className="pt-2 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-2">{t.changeLogoText}</label>
                <div className="flex flex-wrap items-center gap-4" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                  <div className="w-16 h-16 rounded-none bg-white dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-1 flex items-center justify-center shrink-0">
                    <img 
                      className="w-full h-full object-contain" 
                      alt="Pharmacy Logo Preview" 
                      src={logo || '/pharmacy_logo.jpg'} 
                      referrerPolicy="no-referrer"
                    />
                  </div>
                  <label className="flex-1 min-w-[180px] border border-dashed border-[#D4D1CC] dark:border-neutral-700 hover:border-neutral-900 dark:hover:border-white p-3.5 rounded-none flex items-center justify-center gap-2 bg-neutral-50 dark:bg-neutral-800/40 text-[10px] tracking-widest uppercase font-mono text-neutral-500 font-bold cursor-pointer transition-colors">
                    <Upload className="w-4 h-4 text-neutral-500" />
                    <span>{t.uploadLogo}</span>
                    <input 
                      type="file" 
                      accept="image/*" 
                      className="hidden" 
                      onChange={(e) => {
                        if (e.target.files && e.target.files[0]) {
                          const reader = new FileReader();
                          reader.onload = (evt) => {
                            if (evt.target?.result) {
                              setLogo(evt.target.result as string);
                              triggerToast(lang === 'ar' ? 'تم رفع الشعار بنجاح! اضغط حفظ التغييرات' : 'New logo selected! Click Save');
                            }
                          };
                          reader.readAsDataURL(e.target.files[0]);
                        }
                      }}
                    />
                  </label>
                  <button
                    type="button"
                    onClick={() => {
                      setLogo('/pharmacy_logo.jpg');
                      triggerToast(lang === 'ar' ? 'تم تطبيق الشعار الرسمي للصيدلية!' : 'Official logo set!');
                    }}
                    className="px-3 py-3 border border-[#D4D1CC] dark:border-neutral-700 text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                  >
                    {lang === 'ar' ? 'الشعار الرسمي' : 'Official Logo'}
                  </button>
                </div>
              </div>
            </div>

            {/* Financial Settings Card */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
              <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-2 mb-4"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                {t.financialSettings}
              </h3>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.baseCurrency}</label>
                  <select 
                    value={currency}
                    onChange={(e) => setCurrency(e.target.value as any)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-850 dark:text-white cursor-pointer"
                  >
                    <option value="EGP">EGP - ج.م (Egyptian Pound)</option>
                    <option value="SAR">SAR - ر.س (Saudi Riyal)</option>
                    <option value="USD">USD - $ (US Dollar)</option>
                    <option value="IQD">IQD - د.ع (Iraqi Dinar)</option>
                  </select>
                </div>
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.vatTaxPercent}</label>
                  <input 
                    required
                    min="0"
                    max="100"
                    value={taxRate}
                    onChange={(e) => setTaxRate(Number(e.target.value))}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-800 dark:text-white"
                    type="number"
                  />
                </div>
              </div>

              <div className="p-4 bg-neutral-50 dark:bg-neutral-850/50 border border-[#D4D1CC] dark:border-neutral-800 rounded-none flex items-start gap-3 text-xs text-neutral-500 leading-relaxed"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse', textAlign: isRtl ? 'right' : 'left' }}
              >
                <Info className="w-5 h-5 text-neutral-850 dark:text-neutral-300 shrink-0 mt-0.5" />
                <p className="font-serif italic font-medium">{t.financialDesc}</p>
              </div>
            </div>

          </div>

          {/* Section 2: Sidebar Settings (Localization / Backup / Users) */}
          <div className="space-y-6">
            
            {/* Interface customizer Card */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
              <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-2 mb-4"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                {t.uiCustomization}
              </h3>

              {/* Language toggler */}
              <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.systemLanguage}</label>
                <div className="grid grid-cols-2 gap-2 bg-[#EBE9E5] dark:bg-neutral-850 p-1 rounded-none border border-[#D4D1CC] dark:border-neutral-750">
                  <button 
                    type="button"
                    onClick={() => setSelectedLang('ar')}
                    className={`py-2 rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer ${
                      selectedLang === 'ar' 
                        ? 'bg-neutral-950 text-white' 
                        : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                    }`}
                  >
                    العربية
                  </button>
                  <button 
                    type="button"
                    onClick={() => setSelectedLang('en')}
                    className={`py-2 rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer ${
                      selectedLang === 'en' 
                        ? 'bg-neutral-950 text-white' 
                        : 'text-neutral-500 hover:text-neutral-900 dark:hover:text-white'
                    }`}
                  >
                    English
                  </button>
                </div>
              </div>

              {/* Night Mode Customizer */}
              <div className="flex items-center justify-between pt-2"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <p className="text-xs font-serif italic font-bold text-neutral-900 dark:text-neutral-200">{t.darkMode}</p>
                  <p className="text-[10px] text-neutral-450 mt-0.5">{t.darkModeDesc}</p>
                </div>
                <button 
                  type="button"
                  onClick={() => setIsDarkMode(!isDarkMode)}
                  className={`px-3 py-1.5 rounded-none border text-[10px] tracking-widest uppercase font-mono font-bold cursor-pointer transition-colors ${
                    isDarkMode 
                      ? 'bg-neutral-950 text-white border-neutral-950' 
                      : 'bg-white text-neutral-800 border-neutral-300 dark:bg-neutral-950 dark:text-neutral-200'
                  }`}
                >
                  {isDarkMode ? t.darkMode : 'LIGHT MODE'}
                </button>
              </div>

              {/* Theme Customizer Option */}
              <div className="pt-2 text-right border-t border-[#D4D1CC] dark:border-neutral-800" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-2">{t.themeLabel}</label>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                  <button 
                    type="button"
                    onClick={() => setTheme('vintage')}
                    className={`px-3 py-2.5 rounded-none border text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer text-center ${
                      theme === 'vintage'
                        ? 'bg-neutral-950 text-white border-neutral-950 dark:bg-white dark:text-neutral-950 dark:border-white'
                        : 'bg-white text-neutral-800 border-neutral-300 hover:bg-neutral-50 dark:bg-neutral-950 dark:text-neutral-200 dark:border-neutral-750 dark:hover:bg-neutral-850'
                    }`}
                  >
                    {t.themeVintage}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setTheme('modern')}
                    className={`px-3 py-2.5 rounded-none border text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer text-center ${
                      theme === 'modern'
                        ? 'bg-neutral-950 text-white border-neutral-950 dark:bg-white dark:text-neutral-950 dark:border-white'
                        : 'bg-white text-neutral-800 border-neutral-300 hover:bg-neutral-50 dark:bg-neutral-950 dark:text-neutral-200 dark:border-neutral-750 dark:hover:bg-neutral-850'
                    }`}
                  >
                    {t.themeModern}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setTheme('indigo')}
                    className={`px-3 py-2.5 rounded-none border text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer text-center ${
                      theme === 'indigo'
                        ? 'bg-neutral-950 text-white border-neutral-950 dark:bg-white dark:text-neutral-950 dark:border-white'
                        : 'bg-white text-neutral-800 border-neutral-300 hover:bg-neutral-50 dark:bg-neutral-950 dark:text-neutral-200 dark:border-neutral-750 dark:hover:bg-neutral-850'
                    }`}
                  >
                    {t.themeIndigo}
                  </button>
                  <button 
                    type="button"
                    onClick={() => setTheme('emerald')}
                    className={`px-3 py-2.5 rounded-none border text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer text-center ${
                      theme === 'emerald'
                        ? 'bg-neutral-950 text-white border-neutral-950 dark:bg-white dark:text-neutral-950 dark:border-white'
                        : 'bg-white text-neutral-800 border-neutral-300 hover:bg-neutral-50 dark:bg-neutral-950 dark:text-neutral-200 dark:border-neutral-750 dark:hover:bg-neutral-850'
                    }`}
                  >
                    {t.themeEmerald}
                  </button>
                </div>
              </div>
            </div>

            {/* Cloud Database (Firebase) Card */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
              <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-2 mb-4"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                <Cloud className="w-4 h-4 text-teal-600" />
                <span>{t.cloudDatabase}</span>
              </h3>
              <p className="text-[10px] text-neutral-500 leading-normal">{t.cloudDatabaseDesc}</p>

              {/* Status Badge */}
              <div className="flex items-center gap-2 p-2.5 bg-neutral-50 dark:bg-neutral-950/50 border border-neutral-200 dark:border-neutral-850"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                {currentUser ? (
                  <>
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 animate-pulse shrink-0"></span>
                    <span className="text-[10px] font-mono font-bold text-emerald-600 dark:text-emerald-400">
                      {t.cloudStatusConnected}
                    </span>
                  </>
                ) : (
                  <>
                    <span className="w-2.5 h-2.5 rounded-full bg-amber-500 shrink-0"></span>
                    <span className="text-[10px] font-mono font-bold text-neutral-500">
                      {t.cloudStatusOffline}
                    </span>
                  </>
                )}
              </div>

              {currentUser && (
                <div className="text-[10px] font-mono text-neutral-500 flex flex-col gap-1 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
                  <div className="flex justify-between" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                    <span className="font-bold">{isRtl ? 'المستخدم النشط:' : 'Active User:'}</span>
                    <span className="italic">{currentUser.email}</span>
                  </div>
                </div>
              )}

              <div className="space-y-2">
                {!currentUser ? (
                  <button 
                    type="button"
                    onClick={onLoginWithGoogle}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer border border-neutral-950"
                    style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                  >
                    <LogIn className="w-4 h-4" />
                    <span>{t.googleLogin}</span>
                  </button>
                ) : (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    <button 
                      type="button"
                      onClick={onPushLocalToCloud}
                      disabled={isSyncing}
                      className="flex items-center justify-center gap-2 py-3 bg-teal-600 hover:bg-teal-700 dark:bg-teal-600 dark:hover:bg-teal-500 text-white rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer border border-teal-600 disabled:opacity-50"
                      style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                    >
                      <RefreshCw className={`w-4 h-4 ${isSyncing ? 'animate-spin' : ''}`} />
                      <span>{isRtl ? 'رفع البيانات المحلية للسحاب' : 'Push Local Data to Cloud'}</span>
                    </button>
                    <button 
                      type="button"
                      onClick={onLogout}
                      className="flex items-center justify-center gap-2 py-3 bg-red-600 hover:bg-red-700 text-white rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer border border-red-650"
                      style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                    >
                      <LogOut className="w-4 h-4" />
                      <span>{t.googleLogout}</span>
                    </button>
                  </div>
                )}
              </div>
            </div>

            {/* Desktop Installation Card */}
            <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
              <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-2 mb-4"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                <Monitor className="w-4 h-4 text-teal-600" />
                <span>{t.desktopInstallTitle}</span>
              </h3>
              <p className="text-[10px] text-neutral-500 leading-normal">{t.desktopInstallDesc}</p>

              <div className="flex flex-col gap-2">
                {/* Native PWA Prompt Button */}
                {deferredPrompt && (
                  <button 
                    type="button"
                    onClick={onInstallPWA}
                    className="w-full flex items-center justify-center gap-2 py-3 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer border border-neutral-950"
                    style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                  >
                    <Monitor className="w-4 h-4 text-teal-500" />
                    <span>{t.pwaInstallBtn}</span>
                  </button>
                )}

                {/* Instant Download .url Shortcut */}
                <button 
                  type="button"
                  onClick={downloadUrlShortcut}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-white dark:bg-neutral-950 border border-neutral-950 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-850 rounded-none text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-900 dark:text-white transition-all cursor-pointer"
                  style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                >
                  <Download className="w-4 h-4 text-neutral-500" />
                  <span>{t.downloadShortcut}</span>
                </button>

                {/* Windows bat installer */}
                <button 
                  type="button"
                  onClick={downloadBatInstaller}
                  className="w-full flex items-center justify-center gap-2 py-3 bg-white dark:bg-neutral-950 border border-neutral-950 dark:border-neutral-700 hover:bg-neutral-50 dark:hover:bg-neutral-850 rounded-none text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-900 dark:text-white transition-all cursor-pointer"
                  style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                >
                  <Monitor className="w-4 h-4 text-neutral-500" />
                  <span>{t.downloadWindowsInstaller}</span>
                </button>

                {/* Force Update Button */}
                <div className="pt-2 mt-1 border-t border-dashed border-[#D4D1CC] dark:border-neutral-800 space-y-1.5">
                  <p className="text-[10px] text-neutral-500 leading-normal">
                    {t.forceUpdateDesc}
                  </p>
                  <button
                    type="button"
                    onClick={handleForceUpdate}
                    className="w-full flex items-center justify-center gap-2 py-2.5 bg-amber-700 hover:bg-amber-800 dark:bg-amber-600 dark:hover:bg-amber-700 text-white rounded-none text-[10px] tracking-widest uppercase font-mono font-bold transition-all cursor-pointer shadow-xs"
                    style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                  >
                    <RefreshCw className="w-3.5 h-3.5" />
                    <span>{t.forceUpdateBtn}</span>
                  </button>
                </div>
              </div>
            </div>

          </div>

        </div>

        {/* User management block (Wide) */}
        <div className="bg-white dark:bg-neutral-900 p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 space-y-4">
          <div className="flex justify-between items-center" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <h3 className="text-sm font-serif italic font-bold text-neutral-900 dark:text-white flex items-center gap-2 border-b border-[#D4D1CC] dark:border-neutral-800 pb-1"
              style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
            >
              {t.userManagement}
            </h3>
            <button 
              type="button"
              onClick={() => setIsAddUserOpen(true)}
              className="flex items-center gap-1.5 px-4 py-2 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black text-[10px] tracking-widest uppercase font-mono font-bold rounded-none cursor-pointer border border-neutral-950 dark:border-neutral-700"
              style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
            >
              <UserPlus className="w-3.5 h-3.5" />
              <span>{t.addUser}</span>
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-right border-collapse" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
              <thead>
                <tr className="bg-[#DEDCD7] dark:bg-neutral-800/80 text-neutral-800 dark:text-neutral-200 font-bold text-[10px] uppercase tracking-widest font-mono border-b border-[#D4D1CC] dark:border-neutral-800">
                  <th className={`px-6 py-3 ${isRtl ? 'text-right' : 'text-left'}`}>{t.userTableHead}</th>
                  <th className={`px-6 py-3 ${isRtl ? 'text-right' : 'text-left'}`}>{t.roleTableHead}</th>
                  <th className={`px-6 py-3 ${isRtl ? 'text-right' : 'text-left'}`}>{t.lastSeenTableHead}</th>
                  <th className={`px-6 py-3 ${isRtl ? 'text-right' : 'text-left'}`}>{t.statusTableHead}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D4D1CC] dark:divide-neutral-850 text-xs font-medium text-neutral-800 dark:text-neutral-305">
                {usersList.map((usr) => (
                  <tr key={usr.id} className="hover:bg-[#DEDCD7]/20 dark:hover:bg-neutral-800/20 transition-colors">
                    <td className={`px-6 py-3 font-bold text-neutral-900 dark:text-white ${isRtl ? 'text-right' : 'text-left'}`}>
                      <div className="flex items-center gap-2.5" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                        <div className="w-7 h-7 rounded-none bg-neutral-100 dark:bg-neutral-850 border border-[#D4D1CC] overflow-hidden shrink-0 flex items-center justify-center">
                          {usr.avatar ? (
                            <img className="w-full h-full object-cover" alt={usr.name} src={usr.avatar} referrerPolicy="no-referrer" />
                          ) : (
                            <span className="font-bold text-[10px] text-neutral-950 dark:text-white">{usr.name.charAt(0)}</span>
                          )}
                        </div>
                        <div className="flex flex-col text-right" style={{ alignItems: isRtl ? 'flex-start' : 'flex-end' }}>
                          <span className="font-serif italic leading-none">{usr.name}</span>
                          <span className="text-[9px] text-neutral-500 font-mono mt-0.5">{usr.email}</span>
                        </div>
                      </div>
                    </td>
                    <td className={`px-6 py-3 font-serif italic ${isRtl ? 'text-right' : 'text-left'}`}>
                      {usr.role === 'admin' ? t.adminRole : usr.role === 'pharmacist' ? t.pharmacistRole : t.cashierRole}
                    </td>
                    <td className={`px-6 py-3 font-mono text-neutral-500 ${isRtl ? 'text-right' : 'text-left'}`}>
                      {usr.lastSeen}
                    </td>
                    <td className={`px-6 py-3 ${isRtl ? 'text-right' : 'text-left'}`}>
                      <span className="inline-flex items-center px-2 py-0.5 rounded-none text-[9px] font-mono uppercase tracking-widest font-bold border border-neutral-900 text-neutral-900 dark:border-white dark:text-white">
                        {t.activeStatus}
                      </span>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Global Save triggers */}
        <div className="flex justify-end gap-3 pt-4 border-t border-[#D4D1CC] dark:border-neutral-800"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <button 
            type="submit"
            className="px-8 py-3 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black font-bold text-[11px] tracking-widest uppercase rounded-none cursor-pointer border border-neutral-950 dark:border-neutral-700"
          >
            {t.saveSettings}
          </button>
        </div>

      </form>

      {/* DIALOG POPUP: ADD USER FORM */}
      {isAddUserOpen && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-sm w-full border border-neutral-900 dark:border-neutral-850 shadow-none relative flex flex-col gap-4">
            
            <div className="flex justify-between items-center border-b border-[#D4D1CC] pb-2" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              <h3 className="font-serif italic font-bold text-neutral-900 dark:text-white text-sm">{t.addUser}</h3>
              <button onClick={() => setIsAddUserOpen(false)} className="text-neutral-500 hover:text-neutral-900 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            <form onSubmit={handleAddUser} className="space-y-4 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
              <div>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">اسم الموظف</label>
                <input 
                  required
                  value={newUserName}
                  onChange={(e) => setNewUserName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                  type="text"
                />
              </div>

              <div>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">البريد الإلكتروني</label>
                <input 
                  required
                  value={newUserEmail}
                  onChange={(e) => setNewUserEmail(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                  type="email"
                />
              </div>

              <div>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.roleTableHead}</label>
                <select 
                  value={newUserRole}
                  onChange={(e) => setNewUserRole(e.target.value as any)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-850 dark:text-white cursor-pointer"
                >
                  <option value="pharmacist">{t.pharmacistRole}</option>
                  <option value="cashier">{t.cashierRole}</option>
                </select>
              </div>

              <div className="flex gap-2 pt-2">
                <button 
                  type="submit"
                  className="flex-grow py-2.5 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black font-bold text-[10px] tracking-widest uppercase rounded-none cursor-pointer border border-neutral-950 dark:border-neutral-750"
                >
                  {t.save}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsAddUserOpen(false)}
                  className="px-6 py-2.5 border border-neutral-900 dark:border-neutral-700 text-neutral-900 dark:text-white bg-transparent font-bold text-[10px] tracking-widest uppercase rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>

          </div>
        </div>
      )}

    </div>
  );
}
