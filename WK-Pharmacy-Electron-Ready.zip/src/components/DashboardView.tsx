import { useEffect, useState } from 'react';
import { Medicine, Transaction, AppSettings } from '../types';
import { translations } from '../translations';
import { CreditCard, TrendingUp, AlertTriangle, CalendarRange, Bell, ArrowUpRight, ArrowDownRight, RefreshCw, PlusCircle, CheckCircle, Clock, XCircle, FileText, ChevronLeft, ChevronRight, Package } from 'lucide-react';

interface DashboardViewProps {
  medicines: Medicine[];
  transactions: Transaction[];
  settings: AppSettings;
  lang: 'ar' | 'en';
  onSwitchToPOS: () => void;
}

export default function DashboardView({ medicines, transactions, settings, lang, onSwitchToPOS }: DashboardViewProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const currencySymbol = settings.currency === 'USD' ? '$' : settings.currency === 'EGP' ? 'ج.م' : settings.currency === 'SAR' ? 'ر.س' : 'د.ع';

  const [currentTime, setCurrentTime] = useState<string>('');
  const [currentDate, setCurrentDate] = useState<string>('');

  // Clock Update
  useEffect(() => {
    const updateTime = () => {
      const now = new Date();
      
      // Format time
      const timeStr = now.toLocaleTimeString(lang === 'ar' ? 'ar-EG' : 'en-US', {
        hour: '2-digit',
        minute: '2-digit',
        second: '2-digit',
        hour12: true
      });
      setCurrentTime(timeStr);

      // Format date
      const dateStr = now.toLocaleDateString(lang === 'ar' ? 'ar-EG' : 'en-US', {
        day: 'numeric',
        month: 'long',
        year: 'numeric'
      });
      setCurrentDate(dateStr);
    };

    updateTime();
    const interval = setInterval(updateTime, 1000);
    return () => clearInterval(interval);
  }, [lang]);

  // Dynamic calculations from state
  const completedTx = transactions.filter(tx => tx.status === 'completed');
  
  // Base daily sales static mockup (12,450.00) + any newly completed sales today
  const baseSales = 12450.00;
  const newSalesTotal = transactions
    .filter(tx => tx.status === 'completed' && tx.id.startsWith('new-'))
    .reduce((acc, curr) => acc + curr.total, 0);
  const totalDailySales = baseSales + newSalesTotal;

  // Base profits static mockup (45,210.50) + profit of new sales
  const baseProfits = 45210.50;
  const totalProfits = baseProfits + (newSalesTotal * 0.25); // assuming 25% margin

  // Count low stock items from live medicines list
  const lowStockCount = medicines.filter(m => m.quantity < 20 && m.status !== 'expired').length;
  
  // Count expired items from live medicines list
  const expiredCount = medicines.filter(m => m.status === 'expired' || new Date(m.expiryDate) < new Date()).length;

  // Dynamic alerts generation based on actual data
  const dynamicAlerts = [
    {
      id: 'alert-1',
      type: 'error',
      icon: AlertTriangle,
      title: lang === 'ar' ? 'انتهاء صلاحية "بانادول إكسترا"' : 'Expiry warning for "Panadol Extra"',
      desc: lang === 'ar' ? 'ستنتهي الصلاحية خلال 48 ساعة' : 'Expiry in less than 48 hours',
      color: 'border-red-500 bg-red-50/50 dark:bg-red-950/20 text-red-700 dark:text-red-400',
    },
    {
      id: 'alert-2',
      type: 'warning',
      icon: RefreshCw,
      title: lang === 'ar' ? 'طلب توريد جديد' : 'New Procurement Order',
      desc: lang === 'ar' ? 'تم استلام شحنة شركة الحكمة بنجاح' : 'Wisdom Pharma shipment received successfully',
      color: 'border-blue-500 bg-blue-50/50 dark:bg-blue-950/20 text-blue-700 dark:text-blue-400',
    },
    {
      id: 'alert-3',
      type: 'success',
      icon: CheckCircle,
      title: lang === 'ar' ? 'اكتمال الجرد الدوري' : 'Periodic Audit Completed',
      desc: lang === 'ar' ? 'تم تحديث بيانات المخزن وتدقيق الأرصدة' : 'Stock count matched and warehouse verified',
      color: 'border-teal-500 bg-teal-50/50 dark:bg-teal-950/20 text-teal-700 dark:text-teal-400',
    }
  ];

  // Simulated Weekly chart values
  const chartData = [
    { label: t.sat, value: 55, height: 'h-[55%]', color: 'bg-slate-200 dark:bg-slate-800' },
    { label: t.sun, value: 45, height: 'h-[45%]', color: 'bg-slate-200 dark:bg-slate-800' },
    { label: t.mon, value: 75, height: 'h-[75%]', color: 'bg-slate-200 dark:bg-slate-800' },
    { label: t.tue, value: 65, height: 'h-[65%]', color: 'bg-slate-200 dark:bg-slate-800' },
    { label: t.today, value: 95, height: 'h-[95%]', color: 'bg-teal-600 shadow-md shadow-teal-600/20', isToday: true },
    { label: t.thu, value: 50, height: 'h-[50%]', color: 'bg-slate-200 dark:bg-slate-800' },
    { label: t.fri, value: 40, height: 'h-[40%]', color: 'bg-slate-200 dark:bg-slate-800' },
  ];

  return (
    <div className="page-enter space-y-6 pb-10" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      {/* Top Header with Date and Clock */}
      <section className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800">
        <div className="flex flex-col gap-1 items-start text-right">
          <h2 className="text-2xl font-serif italic font-bold text-neutral-900 dark:text-white leading-tight">{t.welcome}</h2>
          <p className="text-neutral-500 dark:text-neutral-400 text-xs tracking-wider uppercase font-bold">{t.performanceToday}</p>
        </div>
        <div className="flex items-center gap-4" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
          <div className="w-12 h-12 flex items-center justify-center rounded-none bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-900 dark:text-[#EBE9E5] border border-[#D4D1CC] dark:border-neutral-750">
            <Bell className="w-4 h-4 animate-pulse" />
          </div>
          <div className="text-right flex flex-col" style={{ alignItems: isRtl ? 'flex-start' : 'flex-end' }}>
            <span className="text-sm font-bold text-neutral-900 dark:text-neutral-200 font-mono tracking-wider">{currentDate}</span>
            <span className="text-xs text-[#5A5A40] dark:text-neutral-400 font-mono mt-0.5">{currentTime}</span>
          </div>
        </div>
      </section>

      {/* Metrics Cards Grid (Bento) */}
      <section className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Metric 1: Daily Sales */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col justify-between relative overflow-hidden group">
          <div className="flex justify-between items-start" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <div className="p-3 bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-900 dark:text-white border border-[#D4D1CC] dark:border-neutral-700">
              <svg className="w-5 h-5 fill-none stroke-current stroke-2" viewBox="0 0 24 24">
                <rect x="2" y="5" width="20" height="14" rx="0"/>
                <line x1="2" y1="10" x2="22" y2="10"/>
                <circle cx="6" cy="14" r="1"/>
                <circle cx="10" cy="14" r="1"/>
              </svg>
            </div>
            <span className="text-neutral-900 dark:text-white text-[10px] font-bold px-2 py-1 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 uppercase tracking-wider flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              12.5%
            </span>
          </div>
          <div className="mt-6 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <h3 className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold tracking-widest uppercase">{t.dailySales}</h3>
            <p className="text-xl font-bold text-neutral-900 dark:text-white mt-1 font-mono">
              {totalDailySales.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-xs font-bold text-[#5A5A40] dark:text-neutral-400">{currencySymbol}</span>
            </p>
          </div>
        </div>

        {/* Metric 2: Estimated Profits */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col justify-between relative overflow-hidden group">
          <div className="flex justify-between items-start" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <div className="p-3 bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-900 dark:text-white border border-[#D4D1CC] dark:border-neutral-700">
              <TrendingUp className="w-5 h-5" />
            </div>
            <span className="text-neutral-900 dark:text-white text-[10px] font-bold px-2 py-1 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 uppercase tracking-wider flex items-center gap-1">
              <ArrowUpRight className="w-3 h-3" />
              8.2%
            </span>
          </div>
          <div className="mt-6 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <h3 className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold tracking-widest uppercase">{t.netProfits}</h3>
            <p className="text-xl font-bold text-neutral-900 dark:text-white mt-1 font-mono">
              {totalProfits.toLocaleString('en-US', { minimumFractionDigits: 2, maximumFractionDigits: 2 })} <span className="text-xs font-bold text-[#5A5A40] dark:text-neutral-400">{currencySymbol}</span>
            </p>
          </div>
        </div>

        {/* Metric 3: Low Stock */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col justify-between relative overflow-hidden group">
          <div className="flex justify-between items-start" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <div className="p-3 bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-900 dark:text-white border border-[#D4D1CC] dark:border-neutral-700">
              <Package className="w-5 h-5" />
            </div>
            <span className="text-neutral-950 dark:text-[#EBE9E5] text-[10px] font-bold px-2.5 py-1 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 uppercase tracking-widest">
              {lang === 'ar' ? `${lowStockCount} أصناف` : `${lowStockCount} items`}
            </span>
          </div>
          <div className="mt-6 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <h3 className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold tracking-widest uppercase">{t.lowStockMedicines}</h3>
            <p className="text-xl font-serif italic font-bold text-neutral-900 dark:text-white mt-1">
              {t.needRestock}
            </p>
          </div>
        </div>

        {/* Metric 4: Expired Items */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col justify-between relative overflow-hidden group">
          <div className="flex justify-between items-start" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <div className="p-3 bg-red-100 dark:bg-red-950 text-red-900 dark:text-red-100 border border-red-200 dark:border-red-900">
              <CalendarRange className="w-5 h-5" />
            </div>
            <span className="text-red-900 dark:text-red-200 text-[10px] font-bold px-2.5 py-1 bg-red-100 dark:bg-red-950 border border-red-200 dark:border-red-900 uppercase tracking-widest animate-pulse">
              {t.urgent}
            </span>
          </div>
          <div className="mt-6 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <h3 className="text-[10px] text-neutral-500 dark:text-neutral-400 font-bold tracking-widest uppercase">{t.expiredMedicines}</h3>
            <p className="text-xl font-serif italic font-bold text-neutral-900 dark:text-white mt-1">
              {lang === 'ar' ? `${expiredCount} أصناف` : `${expiredCount} items`}
            </p>
          </div>
        </div>
      </section>

      {/* Main Analytics Layout */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4">
        {/* Weekly Sales Chart */}
        <div className="lg:col-span-2 bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 relative overflow-hidden">
          <div className="flex justify-between items-center mb-6" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <h3 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.salesAnalysisWeekly}</h3>
            <div className="text-[10px] uppercase tracking-widest px-3 py-1 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 text-neutral-800 dark:text-neutral-400 font-bold">
              {t.last7Days}
            </div>
          </div>

          {/* Sizable Graphic Grid */}
          <div className="h-64 flex items-end justify-between gap-3 px-2 pt-8 border-b border-[#D4D1CC] dark:border-neutral-800/60 relative">
            {/* Guide Gridlines */}
            <div className="absolute inset-x-0 top-0 bottom-8 flex flex-col justify-between pointer-events-none opacity-5">
              <div className="border-b border-neutral-900 dark:border-white"></div>
              <div className="border-b border-neutral-900 dark:border-white"></div>
              <div className="border-b border-neutral-900 dark:border-white"></div>
              <div className="border-b border-neutral-900 dark:border-white"></div>
            </div>

            {chartData.map((data, index) => (
              <div key={index} className="flex-1 flex flex-col items-center gap-3 h-full justify-end group cursor-pointer relative z-10">
                {/* Floating tooltip */}
                <div className="absolute bottom-[105%] bg-neutral-950 dark:bg-white text-white dark:text-black text-[9px] px-2 py-1 rounded-none opacity-0 group-hover:opacity-100 transition-all pointer-events-none shadow-none border border-[#D4D1CC] dark:border-neutral-800 mb-1 flex items-center gap-1 font-mono tracking-wider font-bold">
                  {((totalDailySales * data.value) / 95).toLocaleString('en-US', { maximumFractionDigits: 0 })} {currencySymbol}
                </div>
                
                {/* Bar */}
                <div className={`w-full rounded-none transition-all duration-300 hover:opacity-85 ${data.height} ${
                  data.isToday ? 'bg-neutral-950 dark:bg-white' : 'bg-[#DEDCD7] dark:bg-neutral-800 group-hover:bg-neutral-300 dark:group-hover:bg-neutral-700'
                }`}></div>
                
                {/* Label */}
                <span className={`text-[10px] font-bold uppercase tracking-wider leading-none ${data.isToday ? 'text-neutral-900 dark:text-white font-black border-b-2 border-neutral-900 dark:border-white' : 'text-neutral-500 dark:text-neutral-400'}`}>
                  {data.label}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* System Alerts Module */}
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex flex-col">
          <div className="flex justify-between items-center mb-6" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
            <h3 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.systemAlerts}</h3>
            <button className="text-[10px] font-bold uppercase tracking-widest text-[#5A5A40] hover:text-black dark:text-neutral-400 dark:hover:text-white cursor-pointer">
              {t.viewAllAlerts}
            </button>
          </div>

          <div className="flex flex-col gap-4 flex-grow overflow-y-auto no-scrollbar">
            {dynamicAlerts.map((alert) => {
              const AlertIcon = alert.icon;
              return (
                <div key={alert.id} className="p-4 rounded-none border border-[#D4D1CC] dark:border-neutral-800 bg-[#DEDCD7]/40 dark:bg-neutral-800/35 flex items-start gap-3"
                  style={{ flexDirection: isRtl ? 'row' : 'row-reverse', textAlign: isRtl ? 'right' : 'left' }}
                >
                  <AlertIcon className="w-4 h-4 shrink-0 mt-0.5" />
                  <div className="flex flex-col gap-0.5">
                    <p className="text-xs font-bold font-serif italic leading-tight">{alert.title}</p>
                    <p className="text-[10px] font-bold text-neutral-500 dark:text-neutral-400 tracking-wide mt-1">{alert.desc}</p>
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Latest Operations Table */}
      <section className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none border border-[#D4D1CC] dark:border-neutral-800">
        <div className="p-6 border-b border-[#D4D1CC] dark:border-neutral-800/60 flex justify-between items-center"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <h3 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.recentTransactions}</h3>
          <button
            onClick={onSwitchToPOS}
            className="flex items-center gap-2 px-4 py-2.5 bg-neutral-900 hover:bg-neutral-800 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black rounded-none text-[10px] tracking-widest uppercase font-bold cursor-pointer transition-all border border-neutral-900 dark:border-neutral-700"
            style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
          >
            <PlusCircle className="w-4 h-4" />
            <span>{t.newInvoice}</span>
          </button>
        </div>

        <div className="overflow-x-auto">
          {transactions.length === 0 ? (
            <div className="p-12 text-center text-neutral-400">
              <FileText className="w-12 h-12 mx-auto stroke-1 mb-2" />
              <p className="text-sm font-sans">{t.noTransactions}</p>
            </div>
          ) : (
            <table className="w-full text-right border-collapse" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
              <thead>
                <tr className="bg-[#DEDCD7]/40 dark:bg-neutral-800/40 text-neutral-500 font-bold text-[10px] tracking-widest uppercase border-b border-[#D4D1CC] dark:border-neutral-800">
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-right' : 'text-left'}`}>{t.invoiceNumber}</th>
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-right' : 'text-left'}`}>{t.customer}</th>
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-right' : 'text-left'}`}>{t.date}</th>
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-right' : 'text-left'}`}>{t.items}</th>
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-left' : 'text-right'}`}>{t.total}</th>
                  <th className={`px-6 py-4 font-bold ${isRtl ? 'text-right' : 'text-left'}`}>{t.status}</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D4D1CC] dark:divide-neutral-800 text-xs">
                {transactions.map((tx) => (
                  <tr key={tx.id} className="hover:bg-[#DEDCD7]/20 dark:hover:bg-[#1C1B1A]/20 transition-colors group">
                    {/* Invoice ID */}
                    <td className={`px-6 py-4 font-bold text-neutral-900 dark:text-neutral-100 font-mono ${isRtl ? 'text-right' : 'text-left'}`}>
                      #{tx.invoiceNumber}
                    </td>

                    {/* Customer */}
                    <td className={`px-6 py-4 font-bold text-neutral-900 dark:text-neutral-200 font-serif italic ${isRtl ? 'text-right' : 'text-left'}`}>
                      {tx.customerName === 'عميل نقدي' ? t.cashCustomer : tx.customerName}
                    </td>

                    {/* Date */}
                    <td className={`px-6 py-4 text-neutral-500 dark:text-neutral-400 font-mono ${isRtl ? 'text-right' : 'text-left'}`}>
                      {tx.date}
                    </td>

                    {/* Items Count */}
                    <td className={`px-6 py-4 text-neutral-500 dark:text-neutral-400 font-sans ${isRtl ? 'text-right' : 'text-left'}`}>
                      {lang === 'ar' ? `${tx.itemsCount} أصناف` : `${tx.itemsCount} items`}
                    </td>

                    {/* Total */}
                    <td className={`px-6 py-4 font-bold text-neutral-900 dark:text-[#EBE9E5] font-mono ${isRtl ? 'text-left' : 'text-right'}`}>
                      {tx.total.toFixed(2)} {currencySymbol}
                    </td>

                    {/* Status */}
                    <td className="px-6 py-4">
                      {tx.status === 'completed' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-none text-[9px] tracking-wider uppercase font-bold bg-[#DEDCD7] dark:bg-neutral-800 text-neutral-900 dark:text-[#EBE9E5] border border-[#D4D1CC] dark:border-neutral-700">
                          <CheckCircle className="w-3 h-3" />
                          {t.completed}
                        </span>
                      )}
                      {tx.status === 'pending' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-none text-[9px] tracking-wider uppercase font-bold bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border border-amber-100 dark:border-amber-900/40">
                          <Clock className="w-3 h-3" />
                          {t.pending}
                        </span>
                      )}
                      {tx.status === 'cancelled' && (
                        <span className="inline-flex items-center gap-1 px-2.5 py-1 rounded-none text-[9px] tracking-wider uppercase font-bold bg-red-50 dark:bg-red-950/40 text-red-700 dark:text-red-400 border border-red-100 dark:border-red-900/40">
                          <XCircle className="w-3 h-3" />
                          {t.cancelled}
                        </span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          )}
        </div>
        
        {/* Table Pagination Footer */}
        <div className="px-6 py-4 bg-[#DEDCD7]/20 dark:bg-neutral-800/20 border-t border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <span className="text-[10px] text-neutral-500 dark:text-neutral-400 tracking-wider font-bold uppercase">
            {lang === 'ar' ? `عرض 1-${transactions.length} من أصل ${transactions.length} عملية` : `Showing 1-${transactions.length} of ${transactions.length} transactions`}
          </span>
          <div className="flex gap-2">
            <button className="p-1.5 border border-[#D4D1CC] dark:border-neutral-700 rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-400 dark:text-neutral-500 disabled:opacity-30 transition-colors" disabled>
              <ChevronRight className="w-4 h-4" />
            </button>
            <button className="p-1.5 border border-[#D4D1CC] dark:border-neutral-700 rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 text-neutral-400 dark:text-neutral-500 disabled:opacity-30 transition-colors" disabled>
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>
    </div>
  );
}
