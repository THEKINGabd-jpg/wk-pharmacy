import { useEffect, useRef } from 'react';
import JsBarcode from 'jsbarcode';

interface BarcodeProps {
  value: string;
  format?: string;
  width?: number;
  height?: number;
  displayValue?: boolean;
  fontSize?: number;
  margin?: number;
  background?: string;
  lineColor?: string;
  className?: string;
}

export function Barcode({
  value,
  format = 'CODE128',
  width = 1.8,
  height = 55,
  displayValue = true,
  fontSize = 12,
  margin = 8,
  background = '#ffffff',
  lineColor = '#000000',
  className = ''
}: BarcodeProps) {
  const svgRef = useRef<SVGSVGElement>(null);

  useEffect(() => {
    if (svgRef.current && value) {
      try {
        // Clean value for CODE128 if needed or use CODE128 standard
        JsBarcode(svgRef.current, value, {
          format: format || 'CODE128',
          width,
          height,
          displayValue,
          fontSize,
          margin,
          background,
          lineColor,
          font: 'monospace',
          textMargin: 3
        });
      } catch (err) {
        console.warn('JsBarcode rendering fallback to CODE128:', err);
        try {
          // Fallback if specific format fails
          JsBarcode(svgRef.current, value, {
            format: 'CODE128',
            width: 1.5,
            height: 45,
            displayValue: true,
            fontSize: 11,
            margin: 5,
            background,
            lineColor
          });
        } catch (e) {
          console.error('Failed to generate barcode:', e);
        }
      }
    }
  }, [value, format, width, height, displayValue, fontSize, margin, background, lineColor]);

  return <svg ref={svgRef} className={`max-w-full ${className}`} />;
}
