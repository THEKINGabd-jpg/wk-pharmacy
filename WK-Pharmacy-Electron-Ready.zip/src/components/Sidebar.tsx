import { LayoutDashboard, Receipt, Package, Truck, BarChart3, Settings, LogOut, ChevronLeft, ChevronRight, ClipboardList, Laptop } from 'lucide-react';
import { AppSettings } from '../types';
import { translations } from '../translations';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  settings: AppSettings;
  lang: 'ar' | 'en';
  onOpenDesktopModal?: () => void;
}

export default function Sidebar({ activeTab, setActiveTab, settings, lang, onOpenDesktopModal }: SidebarProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';

  const menuItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'cashier', label: t.cashier, icon: Receipt },
    { id: 'inventory', label: t.inventory, icon: Package },
    { id: 'shortages', label: t.shortages || 'النقوصات والنواقص', icon: ClipboardList },
    { id: 'suppliers', label: t.suppliers || 'الموردين والمذاخر', icon: Truck },
    { id: 'reports', label: t.reports, icon: BarChart3 },
    { id: 'settings', label: t.settings, icon: Settings },
  ];

  return (
    <aside className="hidden lg:flex flex-col h-screen fixed top-0 w-[280px] bg-[#EBE9E5] dark:bg-[#1C1B1A] border-[#D4D1CC] dark:border-neutral-800 p-6 gap-2 z-50 border-l"
      style={{
        right: isRtl ? 0 : 'auto',
        left: isRtl ? 'auto' : 0,
        borderLeftWidth: isRtl ? '1px' : '0px',
        borderRightWidth: isRtl ? '0px' : '1px'
      }}
    >
      {/* Brand Identity */}
      <div className="px-2 py-5 flex items-center gap-3 border-b border-[#D4D1CC] dark:border-neutral-800 mb-6">
        <div className="w-11 h-11 bg-white dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 flex items-center justify-center shrink-0 p-0.5 overflow-hidden">
          {settings.logo ? (
            <img 
              src={settings.logo} 
              alt={settings.pharmacyName} 
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          ) : (
            <svg className="w-6 h-6 fill-current text-neutral-900 dark:text-white" viewBox="0 0 24 24">
              <path d="M19 10.5h-5.5V5c0-.83-.67-1.5-1.5-1.5s-1.5.67-1.5 1.5v5.5H5c-.83 0-1.5.67-1.5 1.5s.67 1.5 1.5 1.5h5.5V19c0 .83.67 1.5 1.5 1.5s1.5-.67 1.5-1.5v-5.5H19c.83 0 1.5-.67 1.5-1.5s-.67-1.5-1.5-1.5z"/>
            </svg>
          )}
        </div>
        <div className="flex flex-col">
          <h1 className="text-sm font-bold text-neutral-900 dark:text-white tracking-tight leading-snug">{settings.pharmacyName}</h1>
          <span className="text-[9px] text-[#5A5A40] dark:text-neutral-400 font-bold tracking-[0.15em] mt-0.5 uppercase">{t.clinicalSlogan}</span>
        </div>
      </div>

      {/* Navigation Links */}
      <nav className="flex flex-col gap-1.5 flex-grow">
        {menuItems.map((item) => {
          const IconComponent = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3.5 transition-all duration-200 cursor-pointer text-right group uppercase tracking-widest text-[10px] ${
                isActive
                  ? 'bg-neutral-900 dark:bg-white text-white dark:text-black font-bold'
                  : 'text-neutral-600 dark:text-neutral-400 hover:bg-[#DEDCD7] dark:hover:bg-neutral-800/60 hover:text-neutral-900 dark:hover:text-white'
              }`}
              style={{
                flexDirection: isRtl ? 'row' : 'row-reverse',
                justifyContent: isRtl ? 'flex-start' : 'flex-end',
              }}
            >
              <IconComponent className="w-4 h-4 shrink-0" />
              <span className="font-sans font-bold truncate">{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Desktop App Installation Button */}
      {onOpenDesktopModal && (
        <button
          onClick={onOpenDesktopModal}
          className="w-full py-2.5 px-3 bg-teal-800/10 dark:bg-teal-950/40 hover:bg-teal-800/20 text-teal-900 dark:text-teal-300 border border-teal-800/30 font-bold text-[10px] uppercase tracking-wider flex items-center justify-center gap-2 cursor-pointer transition-all my-1"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <Laptop className="w-3.5 h-3.5" />
          <span className="truncate">{isRtl ? 'تثبيت كـ تطبيق سطح المكتب' : 'Install Desktop App'}</span>
        </button>
      )}

      {/* User Profile Component */}
      <div className="mt-auto border-t border-[#D4D1CC] dark:border-neutral-800 pt-5">
        <div className="flex items-center gap-3 p-2 bg-[#DEDCD7]/40 dark:bg-neutral-800/30 rounded-none mb-3"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <img
            className="w-10 h-10 rounded-none object-cover border border-[#D4D1CC] dark:border-neutral-800"
            alt="Walid Khaled Abdo Profile"
            src="https://lh3.googleusercontent.com/aida-public/AB6AXuDN2i3Jc93gM-mxQ5FsUGzdH6ki2uDIvR7w3eNOfyZXPuKCGMqeapi-SMFafwyuqAJGeOHw_jXpdkfqMOKGRDQ7CNY84h3Zzrm5oSAc5Ge0Sjbt8woFqseHm-yVJmK_KsejV8YDqZM9iA7yOwcU6aUmlXOEut5RW9CGrwKAZUP_jP5V_AURJpo3OHMOzDdv7GHI5DD_6FEAjl44OIlxHCuH6tbBCNNUG2mB8Iyak-HAPavrvI8aKLe3y43nw6BJ3-YKlpLcxhMYPA"
            referrerPolicy="no-referrer"
          />
          <div className="overflow-hidden flex flex-col items-start text-right flex-1"
            style={{ textAlign: isRtl ? 'right' : 'left', alignItems: isRtl ? 'flex-start' : 'flex-end' }}
          >
            <p className="text-xs font-bold text-neutral-900 dark:text-neutral-200 truncate leading-tight w-full font-sans">د. وليد خالد</p>
            <span className="text-[9px] text-[#5A5A40] dark:text-neutral-400 font-bold uppercase tracking-widest mt-1">{t.adminRole}</span>
          </div>
          <button className="text-neutral-400 hover:text-black dark:hover:text-white p-1.5 transition-colors cursor-pointer">
            <LogOut className="w-4 h-4" />
          </button>
        </div>

        <div className="flex items-center justify-between px-1 text-[9px] text-neutral-400 font-mono tracking-widest uppercase">
          <span>{t.version}</span>
          <span>WK-PHARM</span>
        </div>
      </div>
    </aside>
  );
}
