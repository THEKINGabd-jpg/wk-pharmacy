import React, { useState } from 'react';
import { Medicine, AppSettings } from '../types';
import { translations } from '../translations';
import { Search, Plus, Filter, RotateCcw, Edit, Trash2, CalendarRange, Package, AlertTriangle, AlertCircle, X, ChevronRight, ChevronLeft, Barcode as BarcodeIcon, Printer, Sparkles } from 'lucide-react';
import { Barcode } from './Barcode';
import { OcrInvoiceModal } from './OcrInvoiceModal';

interface InventoryViewProps {
  medicines: Medicine[];
  settings: AppSettings;
  lang: 'ar' | 'en';
  onAddMedicine: (med: Medicine) => void;
  onUpdateMedicine: (med: Medicine) => void;
  onDeleteMedicine: (id: string) => void;
}

export default function InventoryView({ medicines, settings, lang, onAddMedicine, onUpdateMedicine, onDeleteMedicine }: InventoryViewProps) {
  const t = translations[lang];
  const isRtl = lang === 'ar';
  const currencySymbol = settings.currency === 'USD' ? '$' : settings.currency === 'EGP' ? 'ج.م' : settings.currency === 'SAR' ? 'ر.س' : 'د.ع';

  // Filters State
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [selectedStatus, setSelectedStatus] = useState('all');

  // Dialog / Modal Form state
  const [isFormOpen, setIsFormOpen] = useState(false);
  const [editingMedicine, setEditingMedicine] = useState<Medicine | null>(null);
  const [formTradeName, setFormTradeName] = useState('');
  const [formGenericName, setFormGenericName] = useState('');
  const [formCompany, setFormCompany] = useState('');
  const [formCategory, setFormCategory] = useState('مسكنات');
  const [formQuantity, setFormQuantity] = useState(100);
  const [formCostPrice, setFormCostPrice] = useState(18.00);
  const [formPrice, setFormPrice] = useState(25.00);
  const [formExpiryDate, setFormExpiryDate] = useState('2026-06-30');
  const [formBarcode, setFormBarcode] = useState('');

  // Unit System & Dual Pricing States
  const [formUseUnits, setFormUseUnits] = useState(false);
  const [formUnitMajor, setFormUnitMajor] = useState('علبة');
  const [formUnitMinor, setFormUnitMinor] = useState('شريط');
  const [formUnitsPerMajor, setFormUnitsPerMajor] = useState(10);
  const [formCostPriceMajor, setFormCostPriceMajor] = useState(180.00);
  const [formPriceMajor, setFormPriceMajor] = useState(250.00);
  const [formPriceMajorMoh, setFormPriceMajorMoh] = useState(220.00);
  const [formPriceMoh, setFormPriceMoh] = useState(22.00);
  const [formQtyMajor, setFormQtyMajor] = useState(10);
  const [formQtyMinor, setFormQtyMinor] = useState(0);

  // Pagination State
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 5;

  // Delete Confirmation State
  const [deletingId, setDeletingId] = useState<string | null>(null);

  // QR Code Generation State
  const [qrCodeMedicine, setQrCodeMedicine] = useState<Medicine | null>(null);

  // OCR Invoice Scanning State
  const [isOcrModalOpen, setIsOcrModalOpen] = useState(false);

  // Categories list
  const categories = ['مسكنات', 'مضادات حيوية', 'فيتامينات', 'أدوية براد', 'مستلزمات طبية', 'أدوية الضغط', 'أدوية السكري'];

  // Reset filter triggers
  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('all');
    setSelectedStatus('all');
    setCurrentPage(1);
  };

  // Open modal for Adding
  const handleOpenAddForm = () => {
    setEditingMedicine(null);
    setFormTradeName('');
    setFormGenericName('');
    setFormCompany('');
    setFormCategory('مسكنات');
    setFormQuantity(100);
    setFormCostPrice(1.80);
    setFormPrice(2.50);
    setFormPriceMoh(2.00);
    setFormExpiryDate('2026-06-30');
    setFormBarcode('');
    setFormUseUnits(false);
    setFormUnitMajor('علبة');
    setFormUnitMinor('شريط');
    setFormUnitsPerMajor(10);
    setFormCostPriceMajor(18.00);
    setFormPriceMajor(25.00);
    setFormPriceMajorMoh(20.00);
    setFormQtyMajor(10);
    setFormQtyMinor(0);
    setIsFormOpen(true);
  };

  // Open modal for Editing
  const handleOpenEditForm = (med: Medicine) => {
    setEditingMedicine(med);
    setFormTradeName(med.tradeName);
    setFormGenericName(med.genericName);
    setFormCompany(med.company);
    setFormCategory(med.category);
    setFormQuantity(med.quantity);
    
    const cost = med.costPrice !== undefined ? med.costPrice : Number((med.price * 0.75).toFixed(2));
    setFormCostPrice(cost);
    setFormPrice(med.price);
    setFormPriceMoh(med.priceMoh !== undefined ? med.priceMoh : Number((med.price * 0.85).toFixed(2)));
    setFormExpiryDate(med.expiryDate);
    setFormBarcode(med.barcode || '');

    const hasUnits = !!(med.unitsPerMajor && med.unitsPerMajor > 1);
    setFormUseUnits(hasUnits);
    setFormUnitMajor(med.unitMajor || 'علبة');
    setFormUnitMinor(med.unitMinor || 'شريط');
    const upm = med.unitsPerMajor || 10;
    setFormUnitsPerMajor(upm);
    
    const costMajor = med.costPriceMajor !== undefined ? med.costPriceMajor : Number((cost * upm).toFixed(2));
    setFormCostPriceMajor(costMajor);
    setFormPriceMajor(med.priceMajor || Number((med.price * upm).toFixed(2)));
    setFormPriceMajorMoh(med.priceMajorMoh || Number(((med.priceMoh || med.price * 0.85) * upm).toFixed(2)));
    setFormQtyMajor(hasUnits ? Math.floor(med.quantity / upm) : Math.floor(med.quantity / 10));
    setFormQtyMinor(hasUnits ? med.quantity % upm : med.quantity % 10);
    setIsFormOpen(true);
  };

  // Handle Form Submit (Add or Edit)
  const handleFormSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    const computedQty = formUseUnits 
      ? (Number(formQtyMajor) * Number(formUnitsPerMajor) + Number(formQtyMinor))
      : Number(formQuantity);

    // Determine Status
    let status: 'available' | 'low' | 'expired' | 'out_of_stock' = 'available';
    if (computedQty <= 0) {
      status = 'out_of_stock';
    } else if (computedQty < 20) {
      status = 'low';
    } else if (new Date(formExpiryDate) < new Date()) {
      status = 'expired';
    }

    const medData: Medicine = {
      id: editingMedicine ? editingMedicine.id : `med-${Date.now()}`,
      tradeName: formTradeName,
      genericName: formGenericName,
      company: formCompany,
      category: formCategory,
      quantity: computedQty,
      costPrice: Number(formCostPrice),
      price: Number(formPrice),
      priceMoh: Number(formPriceMoh),
      expiryDate: formExpiryDate,
      barcode: formBarcode.trim() || undefined,
      status,
      // Unit-specific details
      unitMajor: formUseUnits ? formUnitMajor : undefined,
      unitMinor: formUnitMinor || 'وحدة',
      unitsPerMajor: formUseUnits ? Number(formUnitsPerMajor) : undefined,
      costPriceMajor: formUseUnits ? Number(formCostPriceMajor) : undefined,
      priceMajor: formUseUnits ? Number(formPriceMajor) : undefined,
      priceMajorMoh: formUseUnits ? Number(formPriceMajorMoh) : undefined
    };

    if (editingMedicine) {
      onUpdateMedicine(medData);
    } else {
      onAddMedicine(medData);
    }

    setIsFormOpen(false);
  };

  // Handle delete execution
  const handleDeleteConfirm = () => {
    if (deletingId) {
      onDeleteMedicine(deletingId);
      setDeletingId(null);
      // Reset pagination if page becomes empty
      const totalFiltered = filteredMedicines.length - 1;
      const totalPages = Math.ceil(totalFiltered / itemsPerPage);
      if (currentPage > totalPages && currentPage > 1) {
        setCurrentPage(totalPages);
      }
    }
  };

  // Handle Printing QR Code inside isolated frame
  const handlePrintQRCode = () => {
    const element = document.getElementById('qr-printable-label');
    if (!element) return;

    // Create a hidden iframe
    const iframe = document.createElement('iframe');
    iframe.style.position = 'fixed';
    iframe.style.right = '0';
    iframe.style.bottom = '0';
    iframe.style.width = '0';
    iframe.style.height = '0';
    iframe.style.border = '0';
    document.body.appendChild(iframe);

    const iframeDoc = iframe.contentWindow?.document || iframe.contentDocument;
    if (iframeDoc) {
      iframeDoc.write(`
        <html>
          <head>
            <title>Print QR Label</title>
            <style>
              @import url('https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap');
              body {
                margin: 0;
                padding: 0;
                font-family: 'Inter', system-ui, sans-serif;
                display: flex;
                justify-content: center;
                align-items: center;
                min-height: 100vh;
                background: white;
                color: black;
              }
              .label-card {
                width: 280px;
                border: 2px dashed #111;
                padding: 16px;
                text-align: center;
                box-sizing: border-box;
                background: white;
              }
              .pharmacy-title {
                font-size: 14px;
                font-weight: 700;
                border-bottom: 1px solid #222;
                padding-bottom: 4px;
                margin-bottom: 8px;
                text-transform: uppercase;
                letter-spacing: 0.5px;
              }
              .trade-name {
                font-size: 18px;
                font-weight: 800;
                margin: 4px 0;
                font-family: 'Georgia', serif;
                text-transform: uppercase;
              }
              .generic-name {
                font-size: 11px;
                color: #555;
                font-style: italic;
                margin-bottom: 10px;
              }
              .barcode-container {
                display: flex;
                justify-content: center;
                align-items: center;
                margin: 12px 0;
              }
              .barcode-container svg {
                max-width: 100% !important;
                height: auto !important;
              }
              .med-id {
                font-family: monospace;
                font-size: 11px;
                font-weight: 700;
                background: #eee;
                padding: 2px 6px;
                display: inline-block;
                margin-top: 4px;
              }
              .footer-text {
                font-size: 8px;
                color: #666;
                text-transform: uppercase;
                margin-top: 6px;
                letter-spacing: 0.5px;
              }
              .price-tag {
                font-size: 13px;
                font-weight: 700;
                margin: 4px 0;
              }
              @media print {
                body {
                  min-height: auto;
                }
                .label-card {
                  border: none;
                  width: 100%;
                  padding: 0;
                }
              }
            </style>
          </head>
          <body style="direction: ${isRtl ? 'rtl' : 'ltr'};">
            <div class="label-card">
              ${element.innerHTML}
            </div>
            <script>
              window.onload = function() {
                window.print();
                setTimeout(function() {
                  window.frameElement.remove();
                }, 100);
              }
            </script>
          </body>
        </html>
      `);
      iframeDoc.close();
    }
  };

  // Metrics calculators
  const totalMeds = medicines.length;
  const outOfStockMeds = medicines.filter(m => m.quantity <= 0).length;
  const lowStockMeds = medicines.filter(m => m.quantity > 0 && m.quantity < 20).length;
  const expiredMeds = medicines.filter(m => m.status === 'expired' || new Date(m.expiryDate) < new Date()).length;

  // Filter Catalog
  const filteredMedicines = medicines.filter(med => {
    const matchesSearch = med.tradeName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          med.genericName.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          med.company.toLowerCase().includes(searchQuery.toLowerCase());
    
    const matchesCategory = selectedCategory === 'all' || med.category === selectedCategory;
    
    let matchesStatus = true;
    if (selectedStatus === 'available') matchesStatus = med.quantity > 0 && med.status !== 'expired';
    if (selectedStatus === 'low') matchesStatus = med.quantity > 0 && med.quantity < 20;
    if (selectedStatus === 'expired') matchesStatus = med.status === 'expired' || new Date(med.expiryDate) < new Date();
    if (selectedStatus === 'out_of_stock') matchesStatus = med.quantity <= 0;

    return matchesSearch && matchesCategory && matchesStatus;
  });

  // Pagination bounds
  const totalItems = filteredMedicines.length;
  const totalPages = Math.ceil(totalItems / itemsPerPage);
  const paginatedMedicines = filteredMedicines.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const renderQuantity = (med: Medicine) => {
    if (med.unitsPerMajor && med.unitsPerMajor > 1) {
      const majorName = med.unitMajor || (lang === 'ar' ? 'علبة' : 'box');
      const minorName = med.unitMinor || (lang === 'ar' ? 'شريط' : 'strip');
      const majorQty = Math.floor(med.quantity / med.unitsPerMajor);
      const minorQty = med.quantity % med.unitsPerMajor;

      if (majorQty > 0 && minorQty > 0) {
        return (
          <div className="flex flex-col gap-0.5">
            <span className="text-xs text-neutral-800 dark:text-neutral-200">
              {majorQty} {majorName} {lang === 'ar' ? 'و' : '&'} {minorQty} {minorName}
            </span>
            <span className="text-[10px] text-neutral-400 font-normal">
              ({lang === 'ar' ? 'الإجمالي:' : 'Total:'} {med.quantity} {minorName})
            </span>
          </div>
        );
      } else if (majorQty > 0) {
        return (
          <div className="flex flex-col gap-0.5">
            <span className="text-xs text-neutral-800 dark:text-neutral-200">
              {majorQty} {majorName}
            </span>
            <span className="text-[10px] text-neutral-400 font-normal">
              ({lang === 'ar' ? 'الإجمالي:' : 'Total:'} {med.quantity} {minorName})
            </span>
          </div>
        );
      } else {
        return (
          <div className="flex flex-col gap-0.5">
            <span className="text-xs text-neutral-800 dark:text-neutral-200">
              {minorQty} {minorName}
            </span>
            <span className="text-[10px] text-neutral-400 font-normal">
              ({lang === 'ar' ? 'الإجمالي:' : 'Total:'} {med.quantity} {minorName})
            </span>
          </div>
        );
      }
    }

    return (
      <span>
        {med.quantity} {med.unitMinor || (lang === 'ar' ? 'وحدة' : 'units')}
      </span>
    );
  };

  const renderPrice = (med: Medicine) => {
    const hasMoh = med.priceMoh !== undefined && med.priceMoh > 0;
    if (med.unitsPerMajor && med.unitsPerMajor > 1 && med.priceMajor) {
      const majorName = med.unitMajor || (lang === 'ar' ? 'علبة' : 'box');
      const minorName = med.unitMinor || (lang === 'ar' ? 'شريط' : 'strip');
      return (
        <div className="flex flex-col gap-0.5 font-mono" style={{ alignItems: isRtl ? 'flex-end' : 'flex-start' }}>
          <span className="text-[11px] font-extrabold text-neutral-900 dark:text-white">
            {med.priceMajor.toFixed(2)} {currencySymbol} <span className="text-[9px] font-sans text-neutral-400">/{majorName}</span>
          </span>
          <span className="text-[10px] text-neutral-500 font-bold">
            {med.price.toFixed(2)} {currencySymbol} <span className="text-[9px] font-sans text-neutral-400">/{minorName}</span>
          </span>
          {hasMoh && (
            <span className="text-[9px] text-amber-700 dark:text-amber-400 font-bold flex items-center gap-1 mt-0.5">
              🏛️ {med.priceMoh.toFixed(2)} {currencySymbol}
            </span>
          )}
        </div>
      );
    }
    return (
      <div className="flex flex-col gap-0.5 font-mono" style={{ alignItems: isRtl ? 'flex-end' : 'flex-start' }}>
        <span className="font-extrabold text-neutral-900 dark:text-white">
          {med.price.toFixed(2)} {currencySymbol}
        </span>
        {hasMoh && (
          <span className="text-[9px] text-amber-700 dark:text-amber-400 font-bold flex items-center gap-1">
            🏛️ {med.priceMoh.toFixed(2)} {currencySymbol}
          </span>
        )}
      </div>
    );
  };

  const renderCostPrice = (med: Medicine) => {
    const cost = med.costPrice !== undefined ? med.costPrice : med.price * 0.75;
    if (med.unitsPerMajor && med.unitsPerMajor > 1 && med.costPriceMajor) {
      const majorName = med.unitMajor || (lang === 'ar' ? 'علبة' : 'box');
      const minorName = med.unitMinor || (lang === 'ar' ? 'شريط' : 'strip');
      return (
        <div className="flex flex-col gap-0.5 font-mono text-neutral-600 dark:text-neutral-400" style={{ alignItems: isRtl ? 'flex-end' : 'flex-start' }}>
          <span className="text-[11px] font-bold">
            {med.costPriceMajor.toFixed(2)} {currencySymbol} <span className="text-[9px] font-sans text-neutral-400">/{majorName}</span>
          </span>
          <span className="text-[10px]">
            {cost.toFixed(2)} {currencySymbol} <span className="text-[9px] font-sans text-neutral-400">/{minorName}</span>
          </span>
        </div>
      );
    }
    return (
      <span className="font-bold text-neutral-700 dark:text-neutral-300 font-mono">
        {cost.toFixed(2)} {currencySymbol}
      </span>
    );
  };

  const totalInventoryCostVal = medicines.reduce((acc, m) => {
    const c = m.costPrice !== undefined ? m.costPrice : m.price * 0.75;
    return acc + (c * m.quantity);
  }, 0);

  const totalInventorySellingVal = medicines.reduce((acc, m) => {
    return acc + (m.price * m.quantity);
  }, 0);

  const totalExpectedProfitVal = totalInventorySellingVal - totalInventoryCostVal;

  return (
    <div className="page-enter space-y-6 pb-10" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
      
      {/* Header section */}
      <section className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 bg-[#EBE9E5] dark:bg-[#1C1B1A] p-6 rounded-none border border-[#D4D1CC] dark:border-neutral-850">
        <div className="flex flex-col gap-1 items-start text-right">
          <h2 className="text-lg font-serif italic font-bold text-neutral-900 dark:text-white">{t.inventoryTitle}</h2>
          <p className="text-neutral-500 uppercase tracking-widest font-mono text-[9px] font-bold">{t.newMedsThisWeek}</p>
        </div>
        <div className="flex flex-wrap items-center gap-2">
          <button 
            onClick={() => setIsOcrModalOpen(true)}
            className="flex items-center gap-2 px-4 py-3 bg-amber-500 hover:bg-amber-600 text-black text-[10px] tracking-widest uppercase font-extrabold rounded-none cursor-pointer transition-all border border-amber-600 shadow-sm"
            style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
          >
            <Sparkles className="w-4 h-4 text-black" />
            <span>{t.ocrScanBtn}</span>
          </button>

          <button 
            onClick={handleOpenAddForm}
            className="flex items-center gap-2 px-5 py-3 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black text-[10px] tracking-widest uppercase font-bold rounded-none cursor-pointer transition-all border border-neutral-950 dark:border-neutral-700"
            style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
          >
            <Plus className="w-4 h-4" />
            <span>{t.addMedicine}</span>
          </button>
        </div>
      </section>

      {/* Stats Bento Grid Row */}
      <section className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-neutral-500 font-bold">{t.totalMedicines}</span>
            <p className="text-sm font-extrabold text-neutral-900 dark:text-white mt-0.5 font-mono">{totalMeds}</p>
          </div>
          <div className="p-1.5 bg-neutral-900 dark:bg-neutral-800 text-white rounded-none">
            <Package className="w-3.5 h-3.5" />
          </div>
        </div>

        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-neutral-500 font-bold">{t.totalInventoryCost}</span>
            <p className="text-xs font-extrabold text-neutral-900 dark:text-white mt-0.5 font-mono">{totalInventoryCostVal.toLocaleString('en-US', { maximumFractionDigits: 0 })} {currencySymbol}</p>
          </div>
        </div>

        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-emerald-600 dark:text-emerald-400 font-bold">{t.expectedProfit}</span>
            <p className="text-xs font-extrabold text-emerald-700 dark:text-emerald-400 mt-0.5 font-mono">+{totalExpectedProfitVal.toLocaleString('en-US', { maximumFractionDigits: 0 })} {currencySymbol}</p>
          </div>
        </div>

        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-neutral-500 font-bold">{t.outOfStock}</span>
            <p className="text-sm font-extrabold text-red-600 mt-0.5 font-mono">{outOfStockMeds}</p>
          </div>
          <div className="p-1.5 bg-neutral-900 dark:bg-neutral-800 text-white rounded-none">
            <AlertCircle className="w-3.5 h-3.5" />
          </div>
        </div>

        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-neutral-500 font-bold">{t.lowStockBadge}</span>
            <p className="text-sm font-extrabold text-amber-600 dark:text-amber-400 mt-0.5 font-mono">{lowStockMeds}</p>
          </div>
          <div className="p-1.5 bg-neutral-900 dark:bg-neutral-800 text-white rounded-none">
            <AlertTriangle className="w-3.5 h-3.5" />
          </div>
        </div>

        <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-3.5 rounded-none border border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <div className="text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[9px] font-mono tracking-widest uppercase text-neutral-500 font-bold">{t.expired}</span>
            <p className="text-sm font-extrabold text-red-600 mt-0.5 font-mono">{expiredMeds}</p>
          </div>
          <div className="p-1.5 bg-neutral-900 dark:bg-neutral-800 text-white rounded-none">
            <CalendarRange className="w-3.5 h-3.5" />
          </div>
        </div>
      </section>

      {/* Interactive Filters Grid */}
      <section className="bg-[#EBE9E5] dark:bg-[#1C1B1A] p-5 rounded-none border border-[#D4D1CC] dark:border-neutral-800">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4 items-center">
          
          {/* Search query input */}
          <div className="relative md:col-span-2">
            <Search className="absolute right-3 top-1/2 -translate-y-1/2 w-4 h-4 text-neutral-500" />
            <input 
              value={searchQuery}
              onChange={(e) => { setSearchQuery(e.target.value); setCurrentPage(1); }}
              className="w-full pr-10 pl-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-800 dark:text-neutral-200 transition-all"
              placeholder={t.searchPlaceholder.replace(' (F4)', '')}
              type="text"
            />
          </div>

          {/* Medical Category select */}
          <div>
            <select
              value={selectedCategory}
              onChange={(e) => { setSelectedCategory(e.target.value); setCurrentPage(1); }}
              className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-700 dark:text-neutral-300 cursor-pointer"
            >
              <option value="all">{t.allCategories}</option>
              {categories.map((cat, idx) => (
                <option key={idx} value={cat}>{cat}</option>
              ))}
            </select>
          </div>

          {/* Stock Level status select */}
          <div className="flex gap-2">
            <select
              value={selectedStatus}
              onChange={(e) => { setSelectedStatus(e.target.value); setCurrentPage(1); }}
              className="flex-1 px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-700 dark:text-neutral-300 cursor-pointer"
            >
              <option value="all">{t.allStatuses}</option>
              <option value="available">{t.available}</option>
              <option value="low">{t.lowStockBadge}</option>
              <option value="expired">{t.expired}</option>
              <option value="out_of_stock">{t.outOfStock}</option>
            </select>

            {/* Reset filter button */}
            <button 
              onClick={handleResetFilters}
              className="p-2.5 bg-white hover:bg-neutral-100 dark:bg-neutral-900 dark:hover:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 rounded-none text-neutral-500 hover:text-neutral-900 dark:text-neutral-400 cursor-pointer transition-colors"
              title={t.resetFilters}
            >
              <RotateCcw className="w-4 h-4" />
            </button>
          </div>

        </div>
      </section>

      {/* High-density inventory database table */}
      <section className="bg-white dark:bg-neutral-900 rounded-none border border-[#D4D1CC] dark:border-neutral-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right border-collapse" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
            <thead>
              <tr className="bg-[#DEDCD7] dark:bg-neutral-800/80 text-neutral-800 dark:text-neutral-200 font-bold text-[10px] uppercase tracking-widest font-mono border-b border-[#D4D1CC] dark:border-neutral-800">
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.tradeName}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.genericName}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.companyName}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.category}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.quantityColumn}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-left' : 'text-right'}`}>{t.costPriceColumn}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-left' : 'text-right'}`}>{t.priceColumn}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.expiryColumn}</th>
                <th className={`px-6 py-4 ${isRtl ? 'text-right' : 'text-left'}`}>{t.status}</th>
                <th className="px-6 py-4 text-center">{t.actionsColumn}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#D4D1CC] dark:divide-neutral-850 text-xs font-medium">
              {paginatedMedicines.map((med) => {
                const isOutOfStock = med.quantity <= 0;
                const isLowStock = med.quantity > 0 && med.quantity < 20;
                const isExpired = med.status === 'expired' || new Date(med.expiryDate) < new Date();

                return (
                  <tr key={med.id} className={`hover:bg-[#DEDCD7]/20 dark:hover:bg-neutral-800/30 transition-colors ${
                    isExpired ? 'bg-red-50/10 dark:bg-red-950/10' : ''
                  }`}>
                    {/* Trade Name */}
                    <td className={`px-6 py-4 font-serif italic font-bold text-neutral-900 dark:text-white ${isRtl ? 'text-right' : 'text-left'}`}>
                      <div>{med.tradeName}</div>
                      {med.barcode && (
                        <span className="inline-block mt-1 px-1.5 py-0.5 text-[9px] font-mono font-normal tracking-wide text-neutral-500 bg-[#EBE9E5] dark:bg-neutral-800 border border-[#D4D1CC]/50 dark:border-neutral-750">
                          {med.barcode}
                        </span>
                      )}
                    </td>

                    {/* Generic Name */}
                    <td className={`px-6 py-4 text-neutral-500 dark:text-neutral-450 ${isRtl ? 'text-right' : 'text-left'}`}>
                      {med.genericName}
                    </td>

                    {/* Manufacturer */}
                    <td className={`px-6 py-4 text-neutral-500 dark:text-neutral-400 ${isRtl ? 'text-right' : 'text-left'}`}>
                      {med.company}
                    </td>

                    {/* Category */}
                    <td className={`px-6 py-4 text-neutral-400 dark:text-neutral-500 ${isRtl ? 'text-right' : 'text-left'}`}>
                      {med.category}
                    </td>

                    {/* Stock level */}
                    <td className={`px-6 py-4 font-bold font-mono ${isOutOfStock ? 'text-red-600' : isLowStock ? 'text-amber-600' : 'text-neutral-800 dark:text-neutral-300'} ${isRtl ? 'text-right' : 'text-left'}`}>
                      {renderQuantity(med)}
                    </td>

                    {/* Purchase Cost Price */}
                    <td className={`px-6 py-4 font-bold text-neutral-700 dark:text-neutral-300 font-mono ${isRtl ? 'text-left' : 'text-right'}`}>
                      {renderCostPrice(med)}
                    </td>

                    {/* Retail Selling Price */}
                    <td className={`px-6 py-4 font-extrabold text-neutral-900 dark:text-white font-mono ${isRtl ? 'text-left' : 'text-right'}`}>
                      {renderPrice(med)}
                    </td>

                    {/* Expiry date */}
                    <td className={`px-6 py-4 font-mono ${isExpired ? 'text-red-600 font-bold' : 'text-neutral-500'} ${isRtl ? 'text-right' : 'text-left'}`}>
                      {med.expiryDate}
                    </td>

                    {/* Status Pill */}
                    <td className="px-6 py-4 text-right">
                      {isOutOfStock ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-none text-[9px] font-mono uppercase tracking-widest font-bold border border-red-600 text-red-600 bg-red-50 dark:bg-red-950/20">
                          {t.outOfStock}
                        </span>
                      ) : isExpired ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-none text-[9px] font-mono uppercase tracking-widest font-bold border border-red-600 text-red-600 bg-red-100 dark:bg-red-950/30">
                          {t.expired}
                        </span>
                      ) : isLowStock ? (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-none text-[9px] font-mono uppercase tracking-widest font-bold border border-amber-600 text-amber-600 bg-amber-50 dark:bg-amber-950/20">
                          {t.lowStockBadge}
                        </span>
                      ) : (
                        <span className="inline-flex items-center px-2 py-0.5 rounded-none text-[9px] font-mono uppercase tracking-widest font-bold border border-neutral-900 text-neutral-900 dark:border-white dark:text-white">
                          {t.available}
                        </span>
                      )}
                    </td>

                    {/* Action buttons */}
                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-1.5">
                        <button 
                          onClick={() => setQrCodeMedicine(med)}
                          className="p-1.5 text-teal-650 hover:text-teal-900 dark:text-teal-500 dark:hover:text-teal-350 hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-none cursor-pointer border border-transparent hover:border-[#D4D1CC]"
                          title={t.generateQRCode}
                        >
                          <BarcodeIcon className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => handleOpenEditForm(med)}
                          className="p-1.5 text-neutral-500 hover:text-neutral-900 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 rounded-none cursor-pointer border border-transparent hover:border-[#D4D1CC]"
                          title={t.edit}
                        >
                          <Edit className="w-3.5 h-3.5" />
                        </button>
                        <button 
                          onClick={() => setDeletingId(med.id)}
                          className="p-1.5 text-neutral-500 hover:text-red-600 hover:bg-red-50 dark:hover:bg-red-950/20 rounded-none cursor-pointer border border-transparent hover:border-red-200"
                          title={t.delete}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>

        {/* Dynamic Pagination footer */}
        <div className="px-6 py-4 bg-[#DEDCD7] dark:bg-neutral-800/40 border-t border-[#D4D1CC] dark:border-neutral-800 flex items-center justify-between"
          style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
        >
          <span className="text-xs text-neutral-500 font-mono font-bold">
            {t.showingEntries
              .replace('{start}', ((currentPage - 1) * itemsPerPage + 1).toString())
              .replace('{end}', Math.min(currentPage * itemsPerPage, totalItems).toString())
              .replace('{total}', totalItems.toString())}
          </span>
          <div className="flex gap-2">
            <button 
              onClick={() => setCurrentPage(prev => Math.min(prev + 1, totalPages))}
              disabled={currentPage === totalPages || totalPages === 0}
              className="p-1.5 border border-neutral-900 dark:border-neutral-700 rounded-none hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-300 disabled:opacity-30 cursor-pointer transition-colors"
            >
              <ChevronRight className="w-4 h-4" />
            </button>
            <button 
              onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))}
              disabled={currentPage === 1}
              className="p-1.5 border border-neutral-900 dark:border-neutral-700 rounded-none hover:bg-neutral-100 dark:hover:bg-neutral-800 text-neutral-800 dark:text-neutral-300 disabled:opacity-30 cursor-pointer transition-colors"
            >
              <ChevronLeft className="w-4 h-4" />
            </button>
          </div>
        </div>
      </section>

      {/* CRUD MODAL FORM (ADD & EDIT) */}
      {isFormOpen && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-md w-full border border-neutral-900 dark:border-neutral-850 shadow-none relative flex flex-col gap-5">
            
            {/* Header close trigger */}
            <div className="flex justify-between items-center pb-2 border-b border-[#D4D1CC] dark:border-neutral-800"
              style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
            >
              <h3 className="font-serif italic font-bold text-neutral-900 dark:text-white text-md">
                {editingMedicine ? t.editMedDialogTitle : t.addMedDialogTitle}
              </h3>
              <button onClick={() => setIsFormOpen(false)} className="text-neutral-500 hover:text-neutral-900 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Form body */}
            <form onSubmit={handleFormSubmit} className="space-y-4 text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
              <div>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputTradeName}</label>
                <input 
                  required
                  value={formTradeName}
                  onChange={(e) => setFormTradeName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                  type="text"
                />
              </div>

              <div>
                <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputGenericName}</label>
                <input 
                  required
                  value={formGenericName}
                  onChange={(e) => setFormGenericName(e.target.value)}
                  className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                  type="text"
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputCompany}</label>
                  <input 
                    required
                    value={formCompany}
                    onChange={(e) => setFormCompany(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-serif italic text-neutral-900 dark:text-white"
                    type="text"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.category}</label>
                  <select 
                    value={formCategory}
                    onChange={(e) => setFormCategory(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-800 dark:text-white cursor-pointer"
                  >
                    {categories.map((cat, idx) => (
                      <option key={idx} value={cat}>{cat}</option>
                    ))}
                  </select>
                </div>
              </div>

              {/* Split unit system toggle */}
              <div className="flex items-center justify-between p-3 bg-[#DEDCD7]/40 dark:bg-neutral-800/30 border border-[#D4D1CC]/50 dark:border-neutral-750/50">
                <span className="text-xs font-bold text-neutral-800 dark:text-neutral-200">
                  {t.unitsSplitHint}
                </span>
                <input 
                  type="checkbox"
                  checked={formUseUnits}
                  onChange={(e) => setFormUseUnits(e.target.checked)}
                  className="w-4 h-4 cursor-pointer accent-neutral-950"
                />
              </div>

              {formUseUnits ? (
                <div className="space-y-4 border-r-2 border-neutral-400 dark:border-neutral-700 pr-3">
                  {/* Unit Names definitions */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.unitMajor}</label>
                      <input 
                        required={formUseUnits}
                        value={formUnitMajor}
                        onChange={(e) => setFormUnitMajor(e.target.value)}
                        placeholder="علبة / باكيت"
                        className="w-full px-4 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-900 dark:text-white"
                        type="text"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.unitMinor}</label>
                      <input 
                        required={formUseUnits}
                        value={formUnitMinor}
                        onChange={(e) => setFormUnitMinor(e.target.value)}
                        placeholder="شريط / أمبول / فيال"
                        className="w-full px-4 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold text-neutral-900 dark:text-white"
                        type="text"
                      />
                    </div>
                  </div>

                  {/* Units per major & Prices */}
                  <div className="grid grid-cols-4 gap-2.5">
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.unitsPerMajor}</label>
                      <input 
                        required={formUseUnits}
                        min="1"
                        value={formUnitsPerMajor}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setFormUnitsPerMajor(val);
                          if (val > 0) {
                            setFormCostPrice(Number((formCostPriceMajor / val).toFixed(2)));
                            setFormPrice(Number((formPriceMajor / val).toFixed(2)));
                            setFormPriceMoh(Number((formPriceMajorMoh / val).toFixed(2)));
                          }
                        }}
                        className="w-full px-2.5 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.costPriceMajor} ({currencySymbol})</label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formCostPriceMajor}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setFormCostPriceMajor(val);
                          if (formUnitsPerMajor > 0) {
                            setFormCostPrice(Number((val / formUnitsPerMajor).toFixed(2)));
                          }
                        }}
                        className="w-full px-2.5 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.priceMajor} ({currencySymbol})</label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPriceMajor}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setFormPriceMajor(val);
                          if (formUnitsPerMajor > 0) {
                            setFormPrice(Number((val / formUnitsPerMajor).toFixed(2)));
                          }
                        }}
                        className="w-full px-2.5 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-amber-600 dark:text-amber-400 mb-1.5">🏛️ {t.iraqiMohPricing} ({currencySymbol})</label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPriceMajorMoh}
                        onChange={(e) => {
                          const val = Number(e.target.value);
                          setFormPriceMajorMoh(val);
                          if (formUnitsPerMajor > 0) {
                            setFormPriceMoh(Number((val / formUnitsPerMajor).toFixed(2)));
                          }
                        }}
                        className="w-full px-2.5 py-2 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800 rounded-none outline-none text-xs font-bold font-mono text-amber-950 dark:text-amber-200"
                        type="number"
                      />
                    </div>
                  </div>

                  {/* Minor unit pricing */}
                  <div className="grid grid-cols-3 gap-3">
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">
                        {t.costPriceMinor} ({currencySymbol} / {formUnitMinor})
                      </label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formCostPrice}
                        onChange={(e) => setFormCostPrice(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-750 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">
                        {t.priceMinor} ({currencySymbol} / {formUnitMinor})
                      </label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPrice}
                        onChange={(e) => setFormPrice(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-[#DEDCD7] dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-750 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-amber-600 dark:text-amber-400 mb-1.5">
                        🏛️ {t.iraqiMohPricing} ({currencySymbol} / {formUnitMinor})
                      </label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPriceMoh}
                        onChange={(e) => setFormPriceMoh(Number(e.target.value))}
                        className="w-full px-3 py-2 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800 rounded-none outline-none text-xs font-bold font-mono text-amber-950 dark:text-amber-200"
                        type="number"
                      />
                    </div>
                  </div>

                  {/* Profit summary badge */}
                  <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 text-[10px] font-mono text-emerald-800 dark:text-emerald-300 flex justify-between items-center">
                    <span>{lang === 'ar' ? 'الربح المتوقع في الكرتون/العلبة:' : 'Major Unit Profit:'} <strong className="font-bold">{(formPriceMajor - formCostPriceMajor).toFixed(2)} {currencySymbol}</strong></span>
                    <span>{lang === 'ar' ? 'الربح في الشريط/القطعة:' : 'Minor Unit Profit:'} <strong className="font-bold">{(formPrice - formCostPrice).toFixed(2)} {currencySymbol}</strong></span>
                  </div>

                  {/* Split Quantities */}
                  <div className="grid grid-cols-2 gap-4">
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.qtyMajor} ({formUnitMajor})</label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        value={formQtyMajor}
                        onChange={(e) => setFormQtyMajor(Number(e.target.value))}
                        className="w-full px-4 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.qtyMinor} ({formUnitMinor})</label>
                      <input 
                        required={formUseUnits}
                        min="0"
                        value={formQtyMinor}
                        onChange={(e) => setFormQtyMinor(Number(e.target.value))}
                        className="w-full px-4 py-2 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="grid grid-cols-4 gap-2.5">
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputQuantity}</label>
                      <input 
                        required={!formUseUnits}
                        min="0"
                        value={formQuantity}
                        onChange={(e) => setFormQuantity(Number(e.target.value))}
                        className="w-full px-2.5 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.costPriceMinor} ({currencySymbol})</label>
                      <input 
                        required={!formUseUnits}
                        min="0"
                        step="0.01"
                        value={formCostPrice}
                        onChange={(e) => setFormCostPrice(Number(e.target.value))}
                        className="w-full px-2.5 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputPrice} ({currencySymbol})</label>
                      <input 
                        required={!formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPrice}
                        onChange={(e) => setFormPrice(Number(e.target.value))}
                        className="w-full px-2.5 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                        type="number"
                      />
                    </div>
                    <div>
                      <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-amber-600 dark:text-amber-400 mb-1.5">🏛️ {t.iraqiMohPricing} ({currencySymbol})</label>
                      <input 
                        required={!formUseUnits}
                        min="0"
                        step="0.01"
                        value={formPriceMoh}
                        onChange={(e) => setFormPriceMoh(Number(e.target.value))}
                        className="w-full px-2.5 py-2.5 bg-amber-50/50 dark:bg-amber-950/20 border border-amber-300 dark:border-amber-800 rounded-none outline-none text-xs font-bold font-mono text-amber-950 dark:text-amber-200"
                        type="number"
                      />
                    </div>
                  </div>

                  {/* Profit summary badge */}
                  <div className="p-2.5 bg-emerald-50 dark:bg-emerald-950/20 border border-emerald-200 dark:border-emerald-800 text-[10px] font-mono text-emerald-800 dark:text-emerald-300 flex justify-between items-center">
                    <span>{lang === 'ar' ? 'الربح الصافي للقطعة الواحدة:' : 'Profit Per Unit:'} <strong className="font-bold">{(formPrice - formCostPrice).toFixed(2)} {currencySymbol}</strong></span>
                    <span>{lang === 'ar' ? 'نسبة هامش الربح:' : 'Profit Margin:'} <strong className="font-bold">{formCostPrice > 0 ? (((formPrice - formCostPrice) / formCostPrice) * 100).toFixed(1) : 0}%</strong></span>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.inputExpiryDate}</label>
                  <input 
                    required
                    value={formExpiryDate}
                    onChange={(e) => setFormExpiryDate(e.target.value)}
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white cursor-pointer"
                    type="date"
                  />
                </div>
                <div>
                  <label className="block text-[10px] tracking-widest uppercase font-mono font-bold text-neutral-500 mb-1.5">{t.barcodeLabel}</label>
                  <input 
                    value={formBarcode}
                    onChange={(e) => setFormBarcode(e.target.value)}
                    placeholder="e.g. 101"
                    className="w-full px-4 py-2.5 bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 rounded-none outline-none text-xs font-bold font-mono text-neutral-900 dark:text-white"
                    type="text"
                  />
                </div>
              </div>

              {/* Action triggers */}
              <div className="flex gap-3 pt-3" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
                <button 
                  type="submit"
                  className="flex-grow py-2.5 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black font-bold text-[10px] tracking-widest uppercase rounded-none cursor-pointer transition-all border border-neutral-900 dark:border-neutral-750"
                >
                  {t.save}
                </button>
                <button 
                  type="button"
                  onClick={() => setIsFormOpen(false)}
                  className="px-6 py-2.5 border border-neutral-900 dark:border-neutral-700 text-neutral-900 dark:text-white bg-transparent font-bold text-[10px] tracking-widest uppercase rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  {t.cancel}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* CONFIRM DELETE DIALOG POPUP */}
      {deletingId && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-sm w-full border border-neutral-900 dark:border-neutral-850 shadow-none relative flex flex-col gap-4 text-center">
            <div className="w-10 h-10 rounded-none bg-red-100 dark:bg-red-950/40 text-red-600 flex items-center justify-center mx-auto mb-2">
              <AlertTriangle className="w-5 h-5" />
            </div>
            
            <h3 className="font-serif italic font-bold text-neutral-900 dark:text-white text-sm">{t.confirmDelete}</h3>
            <p className="text-xs text-neutral-500 font-medium leading-relaxed">{t.confirmDeleteDesc}</p>

            <div className="flex gap-2 mt-2">
              <button 
                onClick={handleDeleteConfirm}
                className="flex-grow py-2.5 bg-red-700 hover:bg-red-800 text-white font-bold text-[10px] tracking-widest uppercase rounded-none cursor-pointer transition-all"
              >
                {t.delete}
              </button>
              <button 
                onClick={() => setDeletingId(null)}
                className="flex-grow py-2.5 border border-neutral-900 dark:border-neutral-700 text-neutral-900 dark:text-white font-bold text-[10px] tracking-widest uppercase rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                {t.cancel}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* QR CODE MODAL POPUP */}
      {qrCodeMedicine && (
        <div className="fixed inset-0 bg-neutral-950/70 backdrop-blur-sm z-[150] flex items-center justify-center p-4">
          <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 max-w-sm w-full border border-neutral-900 dark:border-neutral-850 shadow-none relative flex flex-col gap-4 text-center">
            
            {/* Header close trigger */}
            <div className="flex justify-between items-center pb-2 border-b border-[#D4D1CC] dark:border-neutral-800"
              style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
            >
              <h3 className="font-serif italic font-bold text-neutral-900 dark:text-white text-md">
                {t.qrCodeTitle}
              </h3>
              <button onClick={() => setQrCodeMedicine(null)} className="text-neutral-500 hover:text-neutral-900 p-1 cursor-pointer">
                <X className="w-4 h-4" />
              </button>
            </div>

            {/* Simulated printable sticker label wrapper */}
            <div className="p-4 bg-white dark:bg-neutral-950 border-2 border-dashed border-neutral-400 dark:border-neutral-700 rounded-none text-center">
              <div id="qr-printable-label" className="bg-white p-2">
                <div className="pharmacy-title" style={{ fontSize: '13px', fontWeight: '700', borderBottom: '1px solid #111', paddingBottom: '3px', marginBottom: '8px', color: '#111', fontFamily: 'sans-serif' }}>
                  {lang === 'ar' ? 'صيدلية وليد خالد عبد' : 'WK Pharmacy'}
                </div>
                
                <div className="trade-name" style={{ fontSize: '18px', fontWeight: '800', margin: '4px 0', fontFamily: 'Georgia, serif', color: '#111', textTransform: 'uppercase' }}>
                  {qrCodeMedicine.tradeName}
                </div>
                
                <div className="generic-name" style={{ fontSize: '11px', color: '#555', fontStyle: 'italic', marginBottom: '8px' }}>
                  {qrCodeMedicine.genericName}
                </div>

                <div className="price-tag" style={{ fontSize: '13px', fontWeight: '700', margin: '4px 0', color: '#111', fontFamily: 'monospace' }}>
                  {qrCodeMedicine.price.toFixed(2)} {currencySymbol}
                </div>

                <div className="barcode-container" style={{ display: 'flex', justifyContent: 'center', alignItems: 'center', margin: '10px 0', overflow: 'hidden' }}>
                  <Barcode value={qrCodeMedicine.barcode || qrCodeMedicine.id} width={1.6} height={50} displayValue={true} />
                </div>

                <div className="med-id" style={{ fontFamily: 'monospace', fontSize: '11px', fontWeight: '700', background: '#eee', color: '#111', padding: '2px 6px', display: 'inline-block', marginTop: '4px' }}>
                  {qrCodeMedicine.id}
                </div>

                {qrCodeMedicine.barcode && (
                  <div className="barcode-desc" style={{ fontFamily: 'monospace', fontSize: '9px', color: '#444', marginTop: '3px' }}>
                    {isRtl ? 'الباركود: ' : 'Barcode: '} {qrCodeMedicine.barcode}
                  </div>
                )}

                <div className="footer-text" style={{ fontSize: '8px', color: '#666', textTransform: 'uppercase', marginTop: '8px', letterSpacing: '0.5px', fontFamily: 'sans-serif', fontWeight: '700' }}>
                  {lang === 'ar' ? 'امسح الرمز في المبيعات للإضافة السريعة' : 'SCAN CODE AT POS FOR INSTANT ADD'}
                </div>
              </div>
            </div>

            {/* Actions: Print and Close */}
            <div className="flex gap-2">
              <button 
                onClick={handlePrintQRCode}
                className="flex-grow py-2.5 bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black font-bold text-[10px] tracking-widest uppercase rounded-none cursor-pointer transition-all border border-neutral-950 flex items-center justify-center gap-1.5"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                <Printer className="w-4 h-4" />
                <span>{t.printLabel}</span>
              </button>
              <button 
                onClick={() => setQrCodeMedicine(null)}
                className="px-6 py-2.5 border border-neutral-950 dark:border-neutral-700 text-neutral-900 dark:text-white font-bold text-[10px] tracking-widest uppercase rounded-none hover:bg-neutral-200 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
              >
                {t.close}
              </button>
            </div>
          </div>
        </div>
      )}
      {/* OCR Invoice Modal */}
      <OcrInvoiceModal
        settings={settings}
        isOpen={isOcrModalOpen}
        onClose={() => setIsOcrModalOpen(false)}
        onImportItems={(newMeds) => {
          newMeds.forEach((m) => onAddMedicine(m));
        }}
      />
    </div>
  );
}
