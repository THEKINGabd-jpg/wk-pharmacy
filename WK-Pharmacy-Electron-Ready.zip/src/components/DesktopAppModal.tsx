import React, { useState, useEffect } from 'react';
import { Monitor, Download, CheckCircle, X, Shield, ArrowLeft, Chrome, Laptop, Sparkles, ExternalLink } from 'lucide-react';
import { AppSettings } from '../types';

interface DesktopAppModalProps {
  isOpen: boolean;
  onClose: () => void;
  settings: AppSettings;
  lang: 'ar' | 'en';
  deferredPrompt: any;
  onInstallPWA: () => void;
}

export function DesktopAppModal({
  isOpen,
  onClose,
  settings,
  lang,
  deferredPrompt,
  onInstallPWA
}: DesktopAppModalProps) {
  const isRtl = lang === 'ar';
  const [isStandalone, setIsStandalone] = useState(false);
  const [downloadSuccess, setDownloadSuccess] = useState<string | null>(null);
  const [isInIframe, setIsInIframe] = useState(false);
  const [showPromptNotice, setShowPromptNotice] = useState(false);

  useEffect(() => {
    // Check if running in standalone mode
    const checkStandalone = window.matchMedia('(display-mode: standalone)').matches || (window.navigator as any).standalone === true;
    setIsStandalone(checkStandalone);

    // Check if app is inside an iframe (like AI Studio preview)
    try {
      setIsInIframe(window.self !== window.top);
    } catch (e) {
      setIsInIframe(true);
    }
  }, []);

  if (!isOpen) return null;

  const handlePrimaryInstallClick = () => {
    if (isInIframe) {
      // Open in new tab so browser allows PWA installation
      window.open(window.location.href, '_blank');
      setDownloadSuccess(
        lang === 'ar' 
          ? 'تم فتح التطبيق في تبويب جديد! اضغط على زر التثبيت من التبويب الجديد.' 
          : 'App opened in new tab! Click install from the new tab.'
      );
      setTimeout(() => setDownloadSuccess(null), 5000);
      return;
    }

    if (deferredPrompt) {
      onInstallPWA();
    } else {
      setShowPromptNotice(true);
    }
  };

  const downloadUrlShortcut = () => {
    const urlContent = `[InternetShortcut]\r\nURL=${window.location.href}\r\nIconIndex=0\r\n`;
    const blob = new Blob([urlContent], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${settings.pharmacyName || 'صيدلية وليد خالد عبد'}.url`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
    
    setDownloadSuccess(lang === 'ar' ? 'تم تنزيل ملف الاختصار لسطح المكتب!' : 'Desktop shortcut downloaded!');
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  const downloadBatInstaller = () => {
    const appTitle = settings.pharmacyName || 'صيدلية وليد خالد عبد';
    const appUrl = window.location.href;
    const batContent = `@echo off\r\n` +
      `chcp 65001 > nul\r\n` +
      `title تثبيت تطبيق ${appTitle} على سطح المكتب\r\n` +
      `echo =========================================================\r\n` +
      `echo         تثبيت تطبيق ${appTitle} على سطح المكتب\r\n` +
      `echo         Installing WK Pharmacy Desktop Standalone App\r\n` +
      `echo =========================================================\r\n` +
      `echo.\r\n` +
      `set SHORTCUT_PATH="%USERPROFILE%\\Desktop\\${appTitle}.url"\r\n` +
      `echo [InternetShortcut] > %SHORTCUT_PATH%\r\n` +
      `echo URL=${appUrl} >> %SHORTCUT_PATH%\r\n` +
      `echo IconIndex=0 >> %SHORTCUT_PATH%\r\n` +
      `echo.\r\n` +
      `echo [✓] تم إنشاء أيقونة التطبيق بنجاح على سطح المكتب!\r\n` +
      `echo [✓] Shortcut successfully created on your Windows Desktop.\r\n` +
      `echo.\r\n` +
      `pause\r\n`;

    const blob = new Blob([batContent], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `تثبيت_تطبيق_الصيدلية.bat`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);

    setDownloadSuccess(lang === 'ar' ? 'تم تنزيل ملف المثبت المباشر (BAT)!' : 'Batch installer downloaded!');
    setTimeout(() => setDownloadSuccess(null), 3500);
  };

  return (
    <div className="fixed inset-0 bg-neutral-950/80 backdrop-blur-md z-[200] flex items-center justify-center p-4 overflow-y-auto">
      <div 
        className="bg-[#EBE9E5] dark:bg-[#1C1B1A] rounded-none p-6 md:p-8 max-w-xl w-full border border-neutral-900 dark:border-neutral-800 shadow-2xl relative flex flex-col gap-6 text-right my-auto"
        style={{ direction: isRtl ? 'rtl' : 'ltr' }}
      >
        {/* Modal Close Button */}
        <button 
          onClick={onClose}
          className="absolute top-4 left-4 text-neutral-500 hover:text-neutral-900 dark:hover:text-white p-2 border border-transparent hover:border-[#D4D1CC] dark:hover:border-neutral-700 transition-colors cursor-pointer"
        >
          <X className="w-5 h-5" />
        </button>

        {/* Header Section */}
        <div className="flex items-center gap-4 border-b border-[#D4D1CC] dark:border-neutral-800 pb-5">
          <div className="w-16 h-16 bg-white dark:bg-neutral-900 border-2 border-[#D4D1CC] dark:border-neutral-700 shrink-0 p-1 overflow-hidden shadow-sm">
            <img 
              src={settings.logo || '/pharmacy_logo.jpg'} 
              alt={settings.pharmacyName}
              className="w-full h-full object-contain"
              referrerPolicy="no-referrer"
            />
          </div>
          <div className="flex flex-col text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <span className="text-[10px] font-mono font-bold uppercase tracking-widest text-teal-800 dark:text-teal-400 flex items-center gap-1.5">
              <Laptop className="w-3.5 h-3.5" />
              {isRtl ? 'تطبيق سطح المكتب المستقل' : 'Desktop Application'}
            </span>
            <h2 className="text-lg md:text-xl font-serif italic font-extrabold text-neutral-900 dark:text-white mt-1">
              {isRtl ? `تثبيت ${settings.pharmacyName} على سطح المكتب` : `Install ${settings.pharmacyName} Desktop App`}
            </h2>
            <p className="text-xs text-neutral-600 dark:text-neutral-400 mt-1 font-medium">
              {isRtl 
                ? 'تشغيل نظام الصيدلية كبرنامج إلكتروني مستقل بدون متصفح مع أيقونة رسمية على سطح المكتب' 
                : 'Run as a standalone desktop app directly from your OS desktop with official icon'}
            </p>
          </div>
        </div>

        {/* Status Indicator */}
        {isStandalone ? (
          <div className="p-4 bg-emerald-50 dark:bg-emerald-950/40 border border-emerald-300 dark:border-emerald-800 text-emerald-900 dark:text-emerald-200 text-xs flex items-center gap-3">
            <CheckCircle className="w-5 h-5 text-emerald-600 dark:text-emerald-400 shrink-0" />
            <span>
              {isRtl 
                ? 'التطبيق يعمل حالياً كبرنامج مثبت على سطح المكتب بالكامل!' 
                : 'The application is already running as an installed Desktop App!'}
            </span>
          </div>
        ) : null}

        {/* Feedback Alert */}
        {downloadSuccess && (
          <div className="p-3 bg-amber-100 dark:bg-amber-950/60 border border-amber-300 dark:border-amber-800 text-amber-900 dark:text-amber-200 text-xs flex items-center justify-between animate-fade-in">
            <span className="font-bold">{downloadSuccess}</span>
            <CheckCircle className="w-4 h-4 text-amber-700" />
          </div>
        )}

        {/* Main Action 1: One-Click Browser PWA Installer */}
        <div className="bg-white dark:bg-neutral-900 p-5 border border-[#D4D1CC] dark:border-neutral-800 space-y-3">
          <div className="flex items-center justify-between">
            <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 font-mono flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-amber-600 dark:text-amber-400" />
              {isRtl ? '1. التثبيت المباشر بنقرة واحدة (PWA App)' : '1. One-Click Native Installation'}
            </h3>
            <span className="px-2 py-0.5 bg-teal-100 text-teal-800 dark:bg-teal-950 dark:text-teal-300 text-[9px] font-bold uppercase font-mono">
              {isRtl ? 'الموصى به' : 'Recommended'}
            </span>
          </div>

          <p className="text-xs text-neutral-600 dark:text-neutral-400 leading-relaxed">
            {isRtl 
              ? 'يقوم هذا الخيار بإنشاء برنامج مستقل ومفصل بنظام Windows / Mac يحمل شعار الصيدلية ويعمل كبرنامج إلكتروني بدون أشرطة المتصفح.' 
              : 'Creates a dedicated standalone desktop app window with the official pharmacy icon.'}
          </p>

          {isInIframe && (
            <div className="p-3 bg-amber-50 dark:bg-amber-950/30 border border-amber-200 dark:border-amber-800 text-amber-900 dark:text-amber-300 text-[11px] leading-relaxed">
              💡 {isRtl ? 'تنبيه: أنت تعرض التطبيق حالياً داخل المعاينة المضمنة (iFrame). تمنع أمان المتصفحات التثبيت المباشر من داخل المعاينة. اضغط الزر بالأسفل لفتح التطبيق في تبويب مستقل ثم ثبت البرنامج فوراً!' : 'Note: You are inside a preview iframe. Click the button below to open in a main tab and install directly.'}
            </div>
          )}

          <button
            onClick={handlePrimaryInstallClick}
            className="w-full py-3 px-5 text-xs uppercase font-extrabold tracking-widest flex items-center justify-center gap-2 cursor-pointer transition-all border bg-neutral-950 hover:bg-neutral-900 dark:bg-white dark:hover:bg-neutral-100 text-white dark:text-black border-neutral-950 dark:border-white shadow-md active:scale-98"
          >
            {isInIframe ? (
              <>
                <ExternalLink className="w-4 h-4" />
                <span>{isRtl ? 'فتح التطبيق في تبويب جديد للتثبيت المباشر 🚀' : 'Open in New Tab & Install 🚀'}</span>
              </>
            ) : (
              <>
                <Monitor className="w-4 h-4" />
                <span>{isRtl ? 'تثبيت البرنامج الآن على سطح المكتب ⚡' : 'Install Desktop App Now ⚡'}</span>
              </>
            )}
          </button>

          {showPromptNotice && !isInIframe && (
            <div className="p-3 bg-blue-50 dark:bg-blue-950/40 border border-blue-200 dark:border-blue-800 text-blue-900 dark:text-blue-300 text-xs leading-relaxed space-y-1">
              <p className="font-bold">
                {isRtl 
                  ? 'إذا لم يظهر المربع المنبثق للتثبيت تلقائياً:' 
                  : 'If automatic prompt does not open:'}
              </p>
              <p>
                {isRtl 
                  ? 'انقر على أيقونة التثبيت (⊕) الموضحة بجانب شريط الرابط أعلى المتصفح، أو اتبع الخطوات اليدوية في القسم (3) أدناه.' 
                  : 'Click the install icon (⊕) in your browser address bar or use menu in section (3) below.'}
              </p>
            </div>
          )}
        </div>

        {/* Main Action 2: Downloads Shortcuts */}
        <div className="bg-white dark:bg-neutral-900 p-5 border border-[#D4D1CC] dark:border-neutral-800 space-y-3">
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 font-mono flex items-center gap-2">
            <Download className="w-4 h-4 text-teal-600 dark:text-teal-400" />
            {isRtl ? '2. تنزيل أيقونة وملف اختصار سطح المكتب (Windows)' : '2. Download Desktop Shortcut File'}
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-1">
            <button
              onClick={downloadUrlShortcut}
              className="py-2.5 px-4 bg-[#EBE9E5] hover:bg-[#DEDCD7] dark:bg-neutral-800 dark:hover:bg-neutral-750 text-neutral-900 dark:text-white border border-[#D4D1CC] dark:border-neutral-700 text-[11px] font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-neutral-700 dark:text-neutral-300" />
              <span>{isRtl ? 'تنزيل اختصار (.URL)' : 'Download .URL Shortcut'}</span>
            </button>

            <button
              onClick={downloadBatInstaller}
              className="py-2.5 px-4 bg-[#EBE9E5] hover:bg-[#DEDCD7] dark:bg-neutral-800 dark:hover:bg-neutral-750 text-neutral-900 dark:text-white border border-[#D4D1CC] dark:border-neutral-700 text-[11px] font-bold flex items-center justify-center gap-2 cursor-pointer transition-colors"
            >
              <Download className="w-3.5 h-3.5 text-neutral-700 dark:text-neutral-300" />
              <span>{isRtl ? 'تنزيل مثبت أوتوماتيكي (.BAT)' : 'Download Windows .BAT'}</span>
            </button>
          </div>
        </div>

        {/* Step-by-Step Browser Manual Method Guide */}
        <div className="space-y-3 bg-[#DEDCD7]/40 dark:bg-neutral-900/60 p-5 border border-[#D4D1CC]/80 dark:border-neutral-800">
          <h3 className="text-xs font-bold uppercase tracking-wider text-neutral-800 dark:text-neutral-200 font-mono flex items-center gap-2">
            <Chrome className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            {isRtl ? '3. خطوات التثبيت اليدوي من متصفح Google Chrome / Edge:' : '3. Manual Browser Installation Steps:'}
          </h3>

          <ol className="list-decimal list-inside space-y-2 text-xs text-neutral-700 dark:text-neutral-300 font-medium leading-relaxed pr-1"
            style={{ textAlign: isRtl ? 'right' : 'left' }}
          >
            <li>
              {isRtl 
                ? 'افتح قائمة المتصفح عبر النقر على الثلاث نقاط (⋮) في أعلى يمين المتصفح.' 
                : 'Click the three dots menu (⋮) in your browser top right corner.'}
            </li>
            <li>
              {isRtl 
                ? 'اختر "التطبيقات" (Apps) أو "حفظ ومشاركة" (Save and share).' 
                : 'Navigate to "Apps" or "Save and share".'}
            </li>
            <li>
              {isRtl 
                ? 'انقر على "تثبيت صيدلية وليد خالد عبد" (Install WK Pharmacy).' 
                : 'Click "Install صيدلية وليد خالد عبد" or "Install page as app".'}
            </li>
            <li>
              {isRtl 
                ? 'ضع علامة صح على "إنشاء اختصار على سطح المكتب" (Create Desktop Shortcut) وانقر تثبيت.' 
                : 'Check "Create desktop shortcut" and confirm install.'}
            </li>
          </ol>
        </div>

        {/* Footer Actions */}
        <div className="flex justify-end border-t border-[#D4D1CC] dark:border-neutral-800 pt-4">
          <button
            onClick={onClose}
            className="px-6 py-2.5 bg-neutral-950 dark:bg-white text-white dark:text-black font-bold text-xs uppercase tracking-widest hover:opacity-90 cursor-pointer"
          >
            {isRtl ? 'إغلاق النافذة' : 'Close'}
          </button>
        </div>

      </div>
    </div>
  );
}
