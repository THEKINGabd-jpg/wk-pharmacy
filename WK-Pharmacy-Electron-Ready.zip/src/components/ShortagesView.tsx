import React, { useState } from 'react';
import { ShortageItem, Medicine, Supplier, AppSettings } from '../types';
import { translations } from '../translations';
import { 
  ClipboardList, Plus, Send, Copy, RefreshCw, Search, Trash2, Edit2, 
  CheckCircle2, Clock, AlertTriangle, Filter, Check, Share2, MessageSquare,
  Building2, ArrowUpDown, ChevronDown, CheckSquare, Square
} from 'lucide-react';

interface ShortagesViewProps {
  settings: AppSettings;
  shortages: ShortageItem[];
  medicines: Medicine[];
  suppliers: Supplier[];
  onAddShortage: (shortage: Omit<ShortageItem, 'id' | 'createdAt'>) => void;
  onUpdateShortage: (shortage: ShortageItem) => void;
  onDeleteShortage: (id: string) => void;
  onUpdateSettings?: (settings: AppSettings) => void;
}

export function ShortagesView({
  settings,
  shortages,
  medicines,
  suppliers,
  onAddShortage,
  onUpdateShortage,
  onDeleteShortage,
  onUpdateSettings
}: ShortagesViewProps) {
  const lang = settings.language || 'ar';
  const t = translations[lang];
  const isRtl = lang === 'ar';

  // State
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<'all' | 'pending' | 'ordered' | 'received'>('all');
  const [priorityFilter, setPriorityFilter] = useState<'all' | 'high' | 'medium' | 'low'>('all');
  const [supplierFilter, setSupplierFilter] = useState<string>('all');
  const [selectedIds, setSelectedIds] = useState<string[]>([]);
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Modal states
  const [isAddModalOpen, setIsAddModalOpen] = useState(false);
  const [editingItem, setEditingItem] = useState<ShortageItem | null>(null);
  const [isWhatsAppModalOpen, setIsWhatsAppModalOpen] = useState(false);

  // WhatsApp configuration state
  const [targetPhone, setTargetPhone] = useState(settings.whatsappNumber || '');

  // Form State
  const [formData, setFormData] = useState({
    itemName: '',
    category: 'أدوية عامة',
    requestedQty: 10,
    unit: 'علبة',
    supplierName: '',
    priority: 'high' as 'high' | 'medium' | 'low',
    notes: ''
  });

  const triggerToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => setToastMessage(null), 3000);
  };

  // Filtered shortages
  const filteredShortages = shortages.filter((item) => {
    const matchesSearch = 
      item.itemName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (item.supplierName && item.supplierName.toLowerCase().includes(searchTerm.toLowerCase())) ||
      (item.notes && item.notes.toLowerCase().includes(searchTerm.toLowerCase()));
    
    const matchesStatus = statusFilter === 'all' || item.status === statusFilter;
    const matchesPriority = priorityFilter === 'all' || item.priority === priorityFilter;
    const matchesSupplier = supplierFilter === 'all' || item.supplierName === supplierFilter;

    return matchesSearch && matchesStatus && matchesPriority && matchesSupplier;
  });

  // Toggle selection
  const toggleSelectAll = () => {
    if (selectedIds.length === filteredShortages.length) {
      setSelectedIds([]);
    } else {
      setSelectedIds(filteredShortages.map(s => s.id));
    }
  };

  const toggleSelect = (id: string) => {
    if (selectedIds.includes(id)) {
      setSelectedIds(selectedIds.filter(i => i !== id));
    } else {
      setSelectedIds([...selectedIds, id]);
    }
  };

  // Open Add Modal
  const handleOpenAdd = () => {
    setEditingItem(null);
    setFormData({
      itemName: '',
      category: 'أدوية عامة',
      requestedQty: 10,
      unit: 'علبة',
      supplierName: suppliers[0]?.name || 'مذخر الأدوية الرئيسي',
      priority: 'high',
      notes: ''
    });
    setIsAddModalOpen(true);
  };

  // Open Edit Modal
  const handleOpenEdit = (item: ShortageItem) => {
    setEditingItem(item);
    setFormData({
      itemName: item.itemName,
      category: item.category || 'أدوية عامة',
      requestedQty: item.requestedQty || 1,
      unit: item.unit || 'علبة',
      supplierName: item.supplierName || '',
      priority: item.priority || 'medium',
      notes: item.notes || ''
    });
    setIsAddModalOpen(true);
  };

  // Submit Add / Edit
  const handleSubmitForm = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.itemName.trim()) {
      triggerToast(lang === 'ar' ? 'يرجى كتابة اسم الدواء / النقص' : 'Please enter medicine name');
      return;
    }

    if (editingItem) {
      onUpdateShortage({
        ...editingItem,
        itemName: formData.itemName,
        category: formData.category,
        requestedQty: formData.requestedQty,
        unit: formData.unit,
        supplierName: formData.supplierName,
        priority: formData.priority,
        notes: formData.notes
      });
      triggerToast(lang === 'ar' ? 'تم تحديث بيانات النقص بنجاح' : 'Shortage updated successfully');
    } else {
      onAddShortage({
        itemName: formData.itemName,
        category: formData.category,
        requestedQty: formData.requestedQty,
        unit: formData.unit,
        supplierName: formData.supplierName,
        priority: formData.priority,
        status: 'pending',
        notes: formData.notes
      });
      triggerToast(lang === 'ar' ? 'تمت إضافة النقص إلى القائمة' : 'Shortage added successfully');
    }

    setIsAddModalOpen(false);
  };

  // Auto Import Low / Out of stock from Inventory
  const handleAutoImportFromInventory = () => {
    const lowOrOutMeds = medicines.filter(
      m => m.quantity <= 5 || m.status === 'out_of_stock' || m.status === 'low'
    );

    if (lowOrOutMeds.length === 0) {
      triggerToast(lang === 'ar' ? 'لا توجد أدوية منتهية أو قليلة بالمخزون حالياً!' : 'No low stock items found in inventory!');
      return;
    }

    let addedCount = 0;
    lowOrOutMeds.forEach((med) => {
      // Check if already in shortages pending list
      const exists = shortages.some(s => s.itemName.toLowerCase() === med.tradeName.toLowerCase() && s.status !== 'received');
      if (!exists) {
        onAddShortage({
          itemName: med.tradeName + (med.genericName ? ` (${med.genericName})` : ''),
          category: med.category || 'أدوية عامة',
          requestedQty: 10,
          unit: med.unitMajor || 'علبة',
          supplierName: suppliers[0]?.name || 'مذخر الأدوية',
          priority: med.quantity === 0 ? 'high' : 'medium',
          status: 'pending',
          notes: med.quantity === 0 ? 'نفذت الكمية بالكامل من المخزون' : `متبقي ${med.quantity} ${med.unitMinor || 'قطعة'} فقط`
        });
        addedCount++;
      }
    });

    if (addedCount > 0) {
      triggerToast(lang === 'ar' ? `تمت إضافة ${addedCount} صنف من نواقص المخزون تلقائياً!` : `Imported ${addedCount} shortage items from inventory!`);
    } else {
      triggerToast(lang === 'ar' ? 'جميع نواقص المخزون مسجلة مسبقاً في القائمة' : 'All inventory shortages are already listed');
    }
  };

  // Generate WhatsApp text
  const generateWhatsAppMessage = () => {
    const itemsToSend = selectedIds.length > 0
      ? shortages.filter(s => selectedIds.includes(s.id))
      : filteredShortages.filter(s => s.status !== 'received');

    if (itemsToSend.length === 0) {
      return '';
    }

    const today = new Date().toLocaleDateString('ar-EG', { year: 'numeric', month: 'long', day: 'numeric' });

    let message = `📋 *قائمة النقوصات والنواقص الطبية*\n`;
    message += `🏥 *${settings.pharmacyName}*\n`;
    message += `📅 *التاريخ:* ${today}\n`;
    if (settings.phone) message += `📞 *هاتف الصيدلية:* ${settings.phone}\n`;
    message += `───────────────────\n\n`;

    itemsToSend.forEach((item, index) => {
      const priorityText = item.priority === 'high' ? '🔴 عاجل جداً' : item.priority === 'medium' ? '🟠 هام' : '⚪ عادي';
      message += `${index + 1}. *${item.itemName}*\n`;
      message += `   - *الكمية المطلوبة:* ${item.requestedQty || 1} ${item.unit || 'علبة'}\n`;
      if (item.supplierName) message += `   - *المذخر:* ${item.supplierName}\n`;
      message += `   - *الأهمية:* ${priorityText}\n`;
      if (item.notes) message += `   - *ملاحظات:* ${item.notes}\n`;
      message += `\n`;
    });

    message += `───────────────────\n`;
    message += `يرجى إعلامنا بالتوفر والتجهيز، شكراً جزيلاً! 💊✨`;

    return message;
  };

  // Send WhatsApp Action
  const handleSendToWhatsApp = () => {
    const message = generateWhatsAppMessage();
    if (!message) {
      triggerToast(lang === 'ar' ? 'لا توجد عناصر محددة للإرسال' : 'No items selected to send');
      return;
    }

    // Save phone number if changed in settings
    if (targetPhone !== settings.whatsappNumber && onUpdateSettings) {
      onUpdateSettings({ ...settings, whatsappNumber: targetPhone });
    }

    const encodedText = encodeURIComponent(message);
    let url = '';

    if (targetPhone.trim()) {
      // Clean phone number (remove spaces, pluses if needed or format)
      const cleanPhone = targetPhone.replace(/[^0-9]/g, '');
      url = `https://api.whatsapp.com/send?phone=${cleanPhone}&text=${encodedText}`;
    } else {
      // Generic link opens WhatsApp app or Web directly to pick a group or contact!
      url = `https://api.whatsapp.com/send?text=${encodedText}`;
    }

    window.open(url, '_blank');
    triggerToast(lang === 'ar' ? 'جاري فتح الواتساب للإرسال...' : 'Opening WhatsApp...');
    setIsWhatsAppModalOpen(false);
  };

  // Copy Shortages List
  const handleCopyShortagesText = () => {
    const text = generateWhatsAppMessage();
    if (!text) {
      triggerToast(lang === 'ar' ? 'القائمة فارغة!' : 'List is empty!');
      return;
    }

    navigator.clipboard.writeText(text);
    triggerToast(lang === 'ar' ? 'تم نسخ قائمة النقوصات للحافظة بنجاح!' : 'Shortages list copied to clipboard!');
  };

  // Status Badge Helper
  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'received':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider bg-emerald-100 text-emerald-800 dark:bg-emerald-950/60 dark:text-emerald-300 border border-emerald-300 dark:border-emerald-800">
            <CheckCircle2 className="w-3 h-3" />
            {t.shortageStatusReceived || 'تم الاستلام'}
          </span>
        );
      case 'ordered':
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider bg-amber-100 text-amber-800 dark:bg-amber-950/60 dark:text-amber-300 border border-amber-300 dark:border-amber-800">
            <Clock className="w-3 h-3" />
            {t.shortageStatusOrdered || 'تم الطلب'}
          </span>
        );
      default:
        return (
          <span className="inline-flex items-center gap-1 px-2.5 py-1 text-[10px] font-mono font-bold uppercase tracking-wider bg-rose-100 text-rose-800 dark:bg-rose-950/60 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
            <AlertTriangle className="w-3 h-3" />
            {t.shortageStatusPending || 'معلق'}
          </span>
        );
    }
  };

  const getPriorityBadge = (priority: string) => {
    switch (priority) {
      case 'high':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-red-600 text-white rounded-none">
            {t.priorityHigh || 'عاجل جداً'}
          </span>
        );
      case 'medium':
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-amber-500 text-white rounded-none">
            {t.priorityMedium || 'هام'}
          </span>
        );
      default:
        return (
          <span className="px-2 py-0.5 text-[10px] font-mono font-bold uppercase bg-neutral-200 dark:bg-neutral-700 text-neutral-800 dark:text-neutral-200 rounded-none">
            {t.priorityLow || 'عادي'}
          </span>
        );
    }
  };

  const pendingCount = shortages.filter(s => s.status === 'pending').length;
  const orderedCount = shortages.filter(s => s.status === 'ordered').length;
  const highPriorityCount = shortages.filter(s => s.priority === 'high' && s.status !== 'received').length;

  return (
    <div className="space-y-6 pb-16 font-sans">
      
      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 left-1/2 -translate-x-1/2 z-50 bg-neutral-900 text-white dark:bg-white dark:text-black px-6 py-3 font-mono text-xs font-bold shadow-2xl border border-neutral-700 dark:border-neutral-300 flex items-center gap-3">
          <CheckCircle2 className="w-4 h-4 text-emerald-400 dark:text-emerald-600" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Top Header Card */}
      <div className="bg-[#EBE9E5] dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 p-6 flex flex-col md:flex-row justify-between items-start md:items-center gap-6">
        <div>
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-neutral-900 dark:bg-white text-white dark:text-black flex items-center justify-center shrink-0">
              <ClipboardList className="w-5 h-5" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-neutral-900 dark:text-white tracking-tight">
                {t.shortagesTitle || 'سجل النقوصات والنواقص الطبية'}
              </h1>
              <p className="text-xs text-[#5A5A40] dark:text-neutral-400 font-mono tracking-widest uppercase mt-0.5">
                إضافة وإدارة طلبات الأدوية الناقصة وإرسالها مباشرة عبر الواتساب
              </p>
            </div>
          </div>
        </div>

        {/* Header Action Buttons */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
          
          <button
            onClick={handleAutoImportFromInventory}
            className="px-4 py-3 bg-neutral-200 dark:bg-neutral-800 hover:bg-neutral-300 dark:hover:bg-neutral-700 text-neutral-900 dark:text-white text-xs font-mono font-bold uppercase tracking-wider transition-colors flex items-center gap-2 border border-[#D4D1CC] dark:border-neutral-700 cursor-pointer"
          >
            <RefreshCw className="w-4 h-4 text-emerald-600 dark:text-emerald-400" />
            <span>{t.autoImportLowStock || 'استيراد النقوصات تلقائياً'}</span>
          </button>

          <button
            onClick={() => setIsWhatsAppModalOpen(true)}
            className="px-5 py-3 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-mono font-bold uppercase tracking-wider transition-colors flex items-center gap-2 border border-emerald-700 shadow-sm cursor-pointer"
          >
            <MessageSquare className="w-4 h-4" />
            <span>{t.sendWhatsAppBtn || 'إرسال لمجموعة الواتساب'}</span>
          </button>

          <button
            onClick={handleOpenAdd}
            className="px-5 py-3 bg-neutral-900 dark:bg-white text-white dark:text-black hover:bg-neutral-800 dark:hover:bg-neutral-100 text-xs font-mono font-bold uppercase tracking-wider transition-colors flex items-center gap-2 cursor-pointer"
          >
            <Plus className="w-4 h-4" />
            <span>{t.addShortage || 'إضافة نقص جديد'}</span>
          </button>

        </div>
      </div>

      {/* Metrics Strip */}
      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 p-4">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-neutral-500">إجمالي النقوصات</span>
          <div className="text-2xl font-bold font-mono text-neutral-900 dark:text-white mt-1">
            {shortages.length}
          </div>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 p-4">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">عاجل جداً</span>
          <div className="text-2xl font-bold font-mono text-rose-600 dark:text-rose-400 mt-1">
            {highPriorityCount}
          </div>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 p-4">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">معلق (بانتظار الطلب)</span>
          <div className="text-2xl font-bold font-mono text-amber-600 dark:text-amber-400 mt-1">
            {pendingCount}
          </div>
        </div>

        <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 p-4">
          <span className="text-[10px] font-mono font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">تم المطلوبة من المذخر</span>
          <div className="text-2xl font-bold font-mono text-blue-600 dark:text-blue-400 mt-1">
            {orderedCount}
          </div>
        </div>
      </div>

      {/* Search & Filters */}
      <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 p-4 flex flex-col md:flex-row gap-4 justify-between items-center">
        
        {/* Search */}
        <div className="relative flex-1 w-full">
          <Search className="w-4 h-4 absolute top-1/2 -translate-y-1/2 text-neutral-400"
            style={{ left: isRtl ? 'auto' : '12px', right: isRtl ? '12px' : 'auto' }}
          />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder={lang === 'ar' ? 'بحث باسم الدواء، المذخر، أو الملاحظات...' : 'Search medicine, supplier, or notes...'}
            className="w-full bg-neutral-50 dark:bg-neutral-800/60 border border-[#D4D1CC] dark:border-neutral-700 py-2.5 text-xs text-neutral-900 dark:text-white focus:outline-none focus:border-neutral-900 dark:focus:border-white transition-colors"
            style={{
              paddingRight: isRtl ? '36px' : '12px',
              paddingLeft: isRtl ? '12px' : '36px',
            }}
          />
        </div>

        {/* Filters */}
        <div className="flex flex-wrap items-center gap-3 w-full md:w-auto" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
          
          {/* Status Filter */}
          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value as any)}
            className="bg-neutral-50 dark:bg-neutral-800/60 border border-[#D4D1CC] dark:border-neutral-700 px-3 py-2 text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none"
          >
            <option value="all">{lang === 'ar' ? 'جميع الحالات' : 'All Statuses'}</option>
            <option value="pending">{lang === 'ar' ? 'معلق' : 'Pending'}</option>
            <option value="ordered">{lang === 'ar' ? 'تم الطلب' : 'Ordered'}</option>
            <option value="received">{lang === 'ar' ? 'تم الاستلام' : 'Received'}</option>
          </select>

          {/* Priority Filter */}
          <select
            value={priorityFilter}
            onChange={(e) => setPriorityFilter(e.target.value as any)}
            className="bg-neutral-50 dark:bg-neutral-800/60 border border-[#D4D1CC] dark:border-neutral-700 px-3 py-2 text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none"
          >
            <option value="all">{lang === 'ar' ? 'جميع مستويات الأهمية' : 'All Priorities'}</option>
            <option value="high">{lang === 'ar' ? 'عاجل جداً' : 'Urgent High'}</option>
            <option value="medium">{lang === 'ar' ? 'هام' : 'Medium'}</option>
            <option value="low">{lang === 'ar' ? 'عادي' : 'Normal'}</option>
          </select>

          {/* Supplier Filter */}
          <select
            value={supplierFilter}
            onChange={(e) => setSupplierFilter(e.target.value)}
            className="bg-neutral-50 dark:bg-neutral-800/60 border border-[#D4D1CC] dark:border-neutral-700 px-3 py-2 text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 focus:outline-none"
          >
            <option value="all">{lang === 'ar' ? 'جميع المذاخر' : 'All Suppliers'}</option>
            {suppliers.map(sup => (
              <option key={sup.id} value={sup.name}>{sup.name}</option>
            ))}
          </select>

          {/* Copy list action */}
          <button
            onClick={handleCopyShortagesText}
            className="px-3 py-2 border border-[#D4D1CC] dark:border-neutral-700 bg-neutral-100 dark:bg-neutral-800 hover:bg-neutral-200 dark:hover:bg-neutral-700 text-neutral-800 dark:text-white text-xs font-mono font-bold flex items-center gap-1.5 cursor-pointer"
            title="نسخ القائمة النصية للحافظة"
          >
            <Copy className="w-3.5 h-3.5" />
            <span>{t.copyShortages || 'نسخ'}</span>
          </button>

        </div>
      </div>

      {/* Main Table Container */}
      <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 overflow-hidden">
        {filteredShortages.length === 0 ? (
          <div className="p-12 text-center text-neutral-500 dark:text-neutral-400">
            <ClipboardList className="w-12 h-12 mx-auto mb-3 opacity-30" />
            <p className="text-sm font-bold font-sans">{t.shortagesListEmpty || 'لا توجد نقوصات مسجلة حالياً.'}</p>
            <button
              onClick={handleOpenAdd}
              className="mt-4 px-4 py-2 bg-neutral-900 dark:bg-white text-white dark:text-black text-xs font-mono font-bold uppercase tracking-wider inline-flex items-center gap-2 cursor-pointer"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>إضافة نقص الآن</span>
            </button>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-right" style={{ textAlign: isRtl ? 'right' : 'left' }}>
              <thead>
                <tr className="border-b border-[#D4D1CC] dark:border-neutral-800 bg-[#EBE9E5]/50 dark:bg-[#1C1B1A] text-[10px] font-mono uppercase tracking-wider text-neutral-600 dark:text-neutral-400">
                  <th className="py-3 px-4 w-10 text-center">
                    <button
                      onClick={toggleSelectAll}
                      className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white cursor-pointer"
                    >
                      {selectedIds.length === filteredShortages.length ? (
                        <CheckSquare className="w-4 h-4 text-emerald-600" />
                      ) : (
                        <Square className="w-4 h-4" />
                      )}
                    </button>
                  </th>
                  <th className="py-3 px-4 font-bold">{t.tradeName || 'اسم الدواء / النقص'}</th>
                  <th className="py-3 px-4 font-bold">{t.requestedQty || 'الكمية والوحدة'}</th>
                  <th className="py-3 px-4 font-bold">{t.supplierName || 'المذخر / المورد'}</th>
                  <th className="py-3 px-4 font-bold">{t.priority || 'الأهمية'}</th>
                  <th className="py-3 px-4 font-bold">{t.status || 'الحالة'}</th>
                  <th className="py-3 px-4 font-bold">ملاحظات</th>
                  <th className="py-3 px-4 font-bold text-center">الإجراءات</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-[#D4D1CC]/60 dark:divide-neutral-800/60 text-xs">
                {filteredShortages.map((item) => {
                  const isSelected = selectedIds.includes(item.id);
                  return (
                    <tr 
                      key={item.id} 
                      className={`hover:bg-neutral-50 dark:hover:bg-neutral-800/40 transition-colors ${
                        isSelected ? 'bg-emerald-50/50 dark:bg-emerald-950/20' : ''
                      }`}
                    >
                      <td className="py-3.5 px-4 text-center">
                        <button
                          onClick={() => toggleSelect(item.id)}
                          className="text-neutral-500 hover:text-neutral-900 dark:hover:text-white cursor-pointer"
                        >
                          {isSelected ? (
                            <CheckSquare className="w-4 h-4 text-emerald-600" />
                          ) : (
                            <Square className="w-4 h-4" />
                          )}
                        </button>
                      </td>

                      <td className="py-3.5 px-4">
                        <div className="font-bold text-neutral-900 dark:text-white">
                          {item.itemName}
                        </div>
                        {item.category && (
                          <div className="text-[10px] text-neutral-500 font-mono mt-0.5">
                            {item.category}
                          </div>
                        )}
                      </td>

                      <td className="py-3.5 px-4 font-mono font-bold text-neutral-900 dark:text-white">
                        <span className="text-base text-emerald-700 dark:text-emerald-400">{item.requestedQty || 1}</span>{' '}
                        <span className="text-xs text-neutral-500">{item.unit || 'علبة'}</span>
                      </td>

                      <td className="py-3.5 px-4 font-bold text-neutral-800 dark:text-neutral-200">
                        {item.supplierName ? (
                          <div className="flex items-center gap-1.5">
                            <Building2 className="w-3.5 h-3.5 text-neutral-400" />
                            <span>{item.supplierName}</span>
                          </div>
                        ) : (
                          <span className="text-neutral-400 text-[10px] font-mono">غير محدد</span>
                        )}
                      </td>

                      <td className="py-3.5 px-4">
                        {getPriorityBadge(item.priority || 'medium')}
                      </td>

                      <td className="py-3.5 px-4">
                        <select
                          value={item.status || 'pending'}
                          onChange={(e) => {
                            onUpdateShortage({
                              ...item,
                              status: e.target.value as 'pending' | 'ordered' | 'received'
                            });
                            triggerToast(lang === 'ar' ? 'تم تعديل حالة النقص' : 'Status updated');
                          }}
                          className="bg-transparent border border-[#D4D1CC] dark:border-neutral-700 py-1 px-2 text-xs font-mono font-bold cursor-pointer focus:outline-none"
                        >
                          <option value="pending">{lang === 'ar' ? 'معلق' : 'Pending'}</option>
                          <option value="ordered">{lang === 'ar' ? 'تم الطلب' : 'Ordered'}</option>
                          <option value="received">{lang === 'ar' ? 'تم الاستلام' : 'Received'}</option>
                        </select>
                      </td>

                      <td className="py-3.5 px-4 text-neutral-600 dark:text-neutral-400 text-xs max-w-xs truncate">
                        {item.notes || '-'}
                      </td>

                      <td className="py-3.5 px-4 text-center">
                        <div className="flex items-center justify-center gap-2">
                          
                          {/* Send single item to WhatsApp */}
                          <button
                            onClick={() => {
                              const singleMsg = `📋 *نقص دواء مطلوب عاجل*\n🏥 *${settings.pharmacyName}*\n💊 *الدواء:* ${item.itemName}\n📦 *الكمية:* ${item.requestedQty || 1} ${item.unit || 'علبة'}\n🏷️ *المذخر:* ${item.supplierName || 'غير محدد'}\n📝 *ملاحظات:* ${item.notes || 'لا توجد'}`;
                              const url = `https://api.whatsapp.com/send?text=${encodeURIComponent(singleMsg)}`;
                              window.open(url, '_blank');
                            }}
                            className="p-1.5 text-emerald-600 hover:bg-emerald-50 dark:hover:bg-emerald-950/40 border border-emerald-200 dark:border-emerald-800 transition-colors cursor-pointer"
                            title="إرسال هذا الصنف منفرد للواتساب"
                          >
                            <MessageSquare className="w-3.5 h-3.5" />
                          </button>

                          {/* Edit */}
                          <button
                            onClick={() => handleOpenEdit(item)}
                            className="p-1.5 text-neutral-600 hover:text-black dark:text-neutral-400 dark:hover:text-white hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                            title="تعديل"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>

                          {/* Delete */}
                          <button
                            onClick={() => {
                              if (confirm(lang === 'ar' ? 'هل أنت تأكد من حذف هذا النقص؟' : 'Delete this shortage?')) {
                                onDeleteShortage(item.id);
                                triggerToast(lang === 'ar' ? 'تم الحذف' : 'Deleted');
                              }
                            }}
                            className="p-1.5 text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/40 transition-colors cursor-pointer"
                            title="حذف"
                          >
                            <Trash2 className="w-3.5 h-3.5" />
                          </button>

                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Manual Add / Edit Modal */}
      {isAddModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 max-w-lg w-full p-6 shadow-2xl relative font-sans">
            
            <div className="flex items-center justify-between border-b border-[#D4D1CC] dark:border-neutral-800 pb-4 mb-5">
              <h3 className="text-base font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <Plus className="w-5 h-5 text-emerald-600" />
                <span>{editingItem ? t.editShortage || 'تعديل النقص' : t.addShortage || 'إضافة نقص جديد يدوياً'}</span>
              </h3>
              <button
                onClick={() => setIsAddModalOpen(false)}
                className="text-neutral-400 hover:text-black dark:hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <form onSubmit={handleSubmitForm} className="space-y-4">
              
              {/* Item Name */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                  {t.itemNameShortage || 'اسم الدواء / النقص المطلوب'} *
                </label>
                <input
                  type="text"
                  list="medicine-suggestions"
                  required
                  value={formData.itemName}
                  onChange={(e) => setFormData({ ...formData, itemName: e.target.value })}
                  placeholder="مثال: Panadol Extra 500mg أو أوجمنتين"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs text-neutral-900 dark:text-white focus:outline-none focus:border-neutral-900 font-sans"
                />
                <datalist id="medicine-suggestions">
                  {medicines.map((m) => (
                    <option key={m.id} value={`${m.tradeName} (${m.genericName || ''})`} />
                  ))}
                </datalist>
              </div>

              {/* Category & Requested Qty */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                    {t.requestedQty || 'الكمية المطلوبة'} *
                  </label>
                  <input
                    type="number"
                    min="1"
                    required
                    value={formData.requestedQty}
                    onChange={(e) => setFormData({ ...formData, requestedQty: Number(e.target.value) })}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs font-mono font-bold text-neutral-900 dark:text-white focus:outline-none"
                  />
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                    {t.unitType || 'الوحدة'}
                  </label>
                  <select
                    value={formData.unit}
                    onChange={(e) => setFormData({ ...formData, unit: e.target.value })}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs font-mono font-bold text-neutral-900 dark:text-white focus:outline-none"
                  >
                    <option value="علبة">علبة / باكيت</option>
                    <option value="كرتونة">كرتونة / صندوق</option>
                    <option value="شريط">شريط</option>
                    <option value="عبوة">عبوة / فايال</option>
                    <option value="أمبول">أمبول</option>
                    <option value="قطعة">قطعة</option>
                  </select>
                </div>
              </div>

              {/* Supplier & Priority */}
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                    {t.supplierName || 'المذخر / المورد'}
                  </label>
                  <input
                    type="text"
                    list="supplier-suggestions"
                    value={formData.supplierName}
                    onChange={(e) => setFormData({ ...formData, supplierName: e.target.value })}
                    placeholder="اسم المذخر المفضل"
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs text-neutral-900 dark:text-white focus:outline-none"
                  />
                  <datalist id="supplier-suggestions">
                    {suppliers.map((s) => (
                      <option key={s.id} value={s.name} />
                    ))}
                  </datalist>
                </div>

                <div>
                  <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                    {t.priority || 'درجة الأهمية'}
                  </label>
                  <select
                    value={formData.priority}
                    onChange={(e) => setFormData({ ...formData, priority: e.target.value as any })}
                    className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs font-mono font-bold text-neutral-900 dark:text-white focus:outline-none"
                  >
                    <option value="high">🔴 {t.priorityHigh || 'عاجل جداً'}</option>
                    <option value="medium">🟠 {t.priorityMedium || 'متوسط'}</option>
                    <option value="low">⚪ {t.priorityLow || 'عادي'}</option>
                  </select>
                </div>
              </div>

              {/* Category */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                  التصنيف الطبي
                </label>
                <input
                  type="text"
                  value={formData.category}
                  onChange={(e) => setFormData({ ...formData, category: e.target.value })}
                  placeholder="مثال: مسكنات، مضادات حيوية، أدوية ضغط"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs text-neutral-900 dark:text-white focus:outline-none"
                />
              </div>

              {/* Notes */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                  ملاحظات إضافية
                </label>
                <textarea
                  rows={2}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder="ملاحظات حول طلبات المرضى، الشركة المصنعة المطلوبة، الخ..."
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs text-neutral-900 dark:text-white focus:outline-none"
                />
              </div>

              {/* Modal Footer */}
              <div className="pt-3 flex items-center justify-end gap-3 border-t border-[#D4D1CC] dark:border-neutral-800">
                <button
                  type="button"
                  onClick={() => setIsAddModalOpen(false)}
                  className="px-4 py-2 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  إلغاء
                </button>

                <button
                  type="submit"
                  className="px-5 py-2 bg-neutral-900 dark:bg-white text-white dark:text-black text-xs font-mono font-bold uppercase tracking-wider hover:bg-neutral-800 dark:hover:bg-neutral-100 transition-colors cursor-pointer"
                >
                  {editingItem ? 'حفظ التعديلات' : 'إضافة إلى القائمة'}
                </button>
              </div>

            </form>

          </div>
        </div>
      )}

      {/* WhatsApp Send & Configuration Modal */}
      {isWhatsAppModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-white dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-800 max-w-xl w-full p-6 shadow-2xl relative font-sans">
            
            <div className="flex items-center justify-between border-b border-[#D4D1CC] dark:border-neutral-800 pb-4 mb-5">
              <h3 className="text-base font-bold text-neutral-900 dark:text-white flex items-center gap-2">
                <MessageSquare className="w-5 h-5 text-emerald-600" />
                <span>إرسال النقوصات لمجموعة الواتساب مباشرة</span>
              </h3>
              <button
                onClick={() => setIsWhatsAppModalOpen(false)}
                className="text-neutral-400 hover:text-black dark:hover:text-white text-lg font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>

            <div className="space-y-4">
              
              {/* WhatsApp Number/Group setting input */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                  رقم الواتساب أو رقم المذخر المعتمد (اختياري)
                </label>
                <input
                  type="text"
                  value={targetPhone}
                  onChange={(e) => setTargetPhone(e.target.value)}
                  placeholder="مثال: 9647701234567 (أو اتركه فارغاً للاختيار المباشر في واتساب)"
                  className="w-full bg-neutral-50 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 p-2.5 text-xs font-mono font-bold text-neutral-900 dark:text-white focus:outline-none"
                />
                <p className="text-[10px] text-neutral-500 mt-1">
                  * إذا تركت الرقم فارغاً، سيتيح لك الواتساب اختيار أي مجموعة أو جهة اتصال فور فتح البرنامج.
                </p>
              </div>

              {/* Preview Message Box */}
              <div>
                <label className="block text-[10px] font-mono uppercase tracking-widest text-neutral-500 font-bold mb-1">
                  معاينة رسالة الواتساب الجاهزة
                </label>
                <div className="bg-emerald-50/60 dark:bg-emerald-950/30 border border-emerald-200 dark:border-emerald-800/60 p-4 rounded-none max-h-56 overflow-y-auto text-xs font-mono whitespace-pre-wrap text-emerald-950 dark:text-emerald-200 dir-rtl">
                  {generateWhatsAppMessage() || 'لا توجد عناصر مسجلة في القائمة!'}
                </div>
              </div>

              {/* Modal Actions */}
              <div className="pt-4 flex flex-wrap items-center justify-between gap-3 border-t border-[#D4D1CC] dark:border-neutral-800">
                
                <button
                  type="button"
                  onClick={handleCopyShortagesText}
                  className="px-4 py-2.5 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-mono font-bold text-neutral-800 dark:text-neutral-200 hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center gap-1.5 cursor-pointer"
                >
                  <Copy className="w-4 h-4" />
                  <span>نسخ النص فقط</span>
                </button>

                <div className="flex items-center gap-3">
                  <button
                    type="button"
                    onClick={() => setIsWhatsAppModalOpen(false)}
                    className="px-4 py-2.5 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-mono font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 cursor-pointer"
                  >
                    إغلاق
                  </button>

                  <button
                    type="button"
                    onClick={handleSendToWhatsApp}
                    className="px-6 py-2.5 bg-emerald-600 hover:bg-emerald-700 text-white text-xs font-mono font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-md"
                  >
                    <Send className="w-4 h-4" />
                    <span>إرسال الآن عبر WhatsApp</span>
                  </button>
                </div>

              </div>

            </div>

          </div>
        </div>
      )}

    </div>
  );
}
