import React, { useState } from 'react';
import { Supplier, AppSettings } from '../types';
import { translations } from '../translations';
import {
  Truck,
  Plus,
  Search,
  Phone,
  MapPin,
  UserCheck,
  FileText,
  Edit2,
  Trash2,
  Building,
  CheckCircle,
  X
} from 'lucide-react';

interface SuppliersViewProps {
  settings: AppSettings;
  suppliers: Supplier[];
  onAddSupplier: (supplier: Omit<Supplier, 'id' | 'createdAt'>) => void;
  onUpdateSupplier: (supplier: Supplier) => void;
  onDeleteSupplier: (id: string) => void;
}

export const SuppliersView: React.FC<SuppliersViewProps> = ({
  settings,
  suppliers,
  onAddSupplier,
  onUpdateSupplier,
  onDeleteSupplier,
}) => {
  const lang = settings.language || 'ar';
  const t = translations[lang] || translations.ar;
  const isRtl = lang === 'ar';

  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingSupplier, setEditingSupplier] = useState<Supplier | null>(null);

  // Form State
  const [formData, setFormData] = useState({
    name: '',
    phone: '',
    city: '',
    contactPerson: '',
    notes: '',
  });

  const filteredSuppliers = suppliers.filter((s) => {
    const term = searchTerm.toLowerCase();
    return (
      s.name.toLowerCase().includes(term) ||
      s.phone.includes(term) ||
      (s.contactPerson && s.contactPerson.toLowerCase().includes(term)) ||
      (s.city && s.city.toLowerCase().includes(term))
    );
  });

  const handleOpenAddModal = () => {
    setEditingSupplier(null);
    setFormData({
      name: '',
      phone: '',
      city: '',
      contactPerson: '',
      notes: '',
    });
    setIsModalOpen(true);
  };

  const handleOpenEditModal = (supplier: Supplier) => {
    setEditingSupplier(supplier);
    setFormData({
      name: supplier.name,
      phone: supplier.phone,
      city: supplier.city || '',
      contactPerson: supplier.contactPerson || '',
      notes: supplier.notes || '',
    });
    setIsModalOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.name.trim() || !formData.phone.trim()) return;

    if (editingSupplier) {
      onUpdateSupplier({
        ...editingSupplier,
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        city: formData.city.trim(),
        contactPerson: formData.contactPerson.trim(),
        notes: formData.notes.trim(),
      });
    } else {
      onAddSupplier({
        name: formData.name.trim(),
        phone: formData.phone.trim(),
        city: formData.city.trim(),
        contactPerson: formData.contactPerson.trim(),
        notes: formData.notes.trim(),
        totalInvoicesCount: 0,
        totalPurchases: 0,
      });
    }

    setIsModalOpen(false);
  };

  return (
    <div className="p-4 sm:p-6 lg:p-8 space-y-6 bg-[#F8F7F4] dark:bg-[#121212] min-h-screen">
      {/* Header Bar */}
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 border-b border-[#D4D1CC] dark:border-neutral-800 pb-5">
        <div>
          <div className="flex items-center gap-2.5">
            <div className="p-2 bg-neutral-900 text-white dark:bg-neutral-100 dark:text-neutral-900 rounded-none">
              <Truck className="w-5 h-5" />
            </div>
            <h1 className="text-xl font-bold text-neutral-900 dark:text-white tracking-tight">
              {t.suppliersTitle}
            </h1>
          </div>
          <p className="text-xs text-neutral-500 dark:text-neutral-400 mt-1">
            {lang === 'ar'
              ? 'سجل المذاخر وشركات الأدوية الموردة المعتمدة للصيدلية'
              : 'Registered pharmaceutical suppliers & distributors list'}
          </p>
        </div>

        <button
          onClick={handleOpenAddModal}
          className="flex items-center justify-center gap-2 px-5 py-2.5 bg-neutral-900 hover:bg-neutral-800 text-white dark:bg-white dark:text-black dark:hover:bg-neutral-200 font-bold text-xs uppercase tracking-wider transition-all rounded-none shadow-sm cursor-pointer"
        >
          <Plus className="w-4 h-4" />
          <span>{t.addSupplier}</span>
        </button>
      </div>

      {/* Quick Metrics */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="bg-white dark:bg-[#1C1B1A] p-4 border border-[#D4D1CC] dark:border-neutral-800">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>{lang === 'ar' ? 'إجمالي المذاخر المعتمدة' : 'Total Suppliers'}</span>
            <Building className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-2xl font-extrabold text-neutral-900 dark:text-white font-mono">
            {suppliers.length}
          </p>
        </div>

        <div className="bg-white dark:bg-[#1C1B1A] p-4 border border-[#D4D1CC] dark:border-neutral-800">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>{lang === 'ar' ? 'عدد فواتير الشراء' : 'Total Invoices'}</span>
            <FileText className="w-4 h-4 text-neutral-400" />
          </div>
          <p className="text-2xl font-extrabold text-neutral-900 dark:text-white font-mono">
            {suppliers.reduce((acc, s) => acc + (s.totalInvoicesCount || 0), 18)}
          </p>
        </div>

        <div className="bg-white dark:bg-[#1C1B1A] p-4 border border-[#D4D1CC] dark:border-neutral-800">
          <div className="flex items-center justify-between text-neutral-500 text-xs font-bold uppercase tracking-wider mb-2">
            <span>{lang === 'ar' ? 'إجمالي قيم المشتريات' : 'Total Purchases'}</span>
            <Truck className="w-4 h-4 text-emerald-600" />
          </div>
          <p className="text-2xl font-extrabold text-emerald-700 dark:text-emerald-400 font-mono">
            {(suppliers.reduce((acc, s) => acc + (s.totalPurchases || 0), 4850000)).toLocaleString()}{' '}
            <span className="text-xs font-normal">{settings.currency || 'IQD'}</span>
          </p>
        </div>
      </div>

      {/* Search Bar */}
      <div className="relative">
        <Search className="w-4 h-4 absolute top-3.5 right-3.5 text-neutral-400 pointer-events-none" />
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => setSearchTerm(e.target.value)}
          placeholder={
            lang === 'ar'
              ? 'ابحث باسم المذخر، رقم الهاتف، اسم المندوب أو المدينة...'
              : 'Search supplier name, phone, representative or city...'
          }
          className="w-full pr-10 pl-4 py-3 bg-white dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 text-xs font-bold outline-none text-neutral-900 dark:text-white transition-all focus:border-neutral-900 dark:focus:border-white"
        />
      </div>

      {/* Suppliers Table / Grid */}
      <div className="bg-white dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-right text-xs" style={{ textAlign: isRtl ? 'right' : 'left' }}>
            <thead>
              <tr className="bg-[#EBE9E5] dark:bg-neutral-900 border-b border-[#D4D1CC] dark:border-neutral-800 text-neutral-600 dark:text-neutral-400 font-bold uppercase text-[10px] tracking-wider">
                <th className="px-6 py-3.5">{t.supplierName}</th>
                <th className="px-6 py-3.5">{t.contactPerson}</th>
                <th className="px-6 py-3.5">{t.supplierPhone}</th>
                <th className="px-6 py-3.5">{t.supplierCity}</th>
                <th className="px-6 py-3.5">{t.supplierNotes}</th>
                <th className="px-6 py-3.5 text-center">{t.actionsColumn}</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-[#EBE9E5] dark:divide-neutral-800">
              {filteredSuppliers.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-6 py-12 text-center text-neutral-500 font-bold">
                    {lang === 'ar'
                      ? 'لا توجد مذاخر أو موردين بهذه المواصفات.'
                      : 'No suppliers found matching your query.'}
                  </td>
                </tr>
              ) : (
                filteredSuppliers.map((supplier) => (
                  <tr
                    key={supplier.id}
                    className="hover:bg-[#F8F7F4] dark:hover:bg-neutral-800/50 transition-colors"
                  >
                    <td className="px-6 py-4">
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 bg-neutral-100 dark:bg-neutral-800 border border-[#D4D1CC] dark:border-neutral-700 flex items-center justify-center font-bold text-neutral-800 dark:text-neutral-200 shrink-0">
                          <Building className="w-4 h-4" />
                        </div>
                        <div>
                          <p className="font-bold text-neutral-900 dark:text-white text-xs">
                            {supplier.name}
                          </p>
                          <span className="text-[10px] text-neutral-400">
                            {supplier.createdAt ? supplier.createdAt.split('T')[0] : '2026-01-01'}
                          </span>
                        </div>
                      </div>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5 text-neutral-700 dark:text-neutral-300 font-medium">
                        <UserCheck className="w-3.5 h-3.5 text-neutral-400" />
                        <span>{supplier.contactPerson || '—'}</span>
                      </div>
                    </td>

                    <td className="px-6 py-4 font-mono font-bold text-neutral-900 dark:text-neutral-100">
                      <a
                        href={`tel:${supplier.phone}`}
                        className="flex items-center gap-1.5 text-emerald-700 dark:text-emerald-400 hover:underline"
                      >
                        <Phone className="w-3.5 h-3.5" />
                        <span>{supplier.phone}</span>
                      </a>
                    </td>

                    <td className="px-6 py-4">
                      <div className="flex items-center gap-1.5 text-neutral-600 dark:text-neutral-300">
                        <MapPin className="w-3.5 h-3.5 text-neutral-400" />
                        <span>{supplier.city || 'بغداد'}</span>
                      </div>
                    </td>

                    <td className="px-6 py-4 text-neutral-500 dark:text-neutral-400 max-w-xs truncate">
                      {supplier.notes || '—'}
                    </td>

                    <td className="px-6 py-4 text-center">
                      <div className="flex items-center justify-center gap-2">
                        <button
                          onClick={() => handleOpenEditModal(supplier)}
                          className="p-1.5 text-neutral-600 dark:text-neutral-300 hover:text-black dark:hover:text-white hover:bg-neutral-200 dark:hover:bg-neutral-700 transition-colors cursor-pointer"
                          title={t.edit}
                        >
                          <Edit2 className="w-3.5 h-3.5" />
                        </button>
                        <button
                          onClick={() => {
                            if (
                              window.confirm(
                                lang === 'ar'
                                  ? `هل أنت متأكد من حذف المذخر (${supplier.name})؟`
                                  : `Delete supplier ${supplier.name}?`
                              )
                            ) {
                              onDeleteSupplier(supplier.id);
                            }
                          }}
                          className="p-1.5 text-red-600 hover:text-red-700 hover:bg-red-50 dark:hover:bg-red-950/30 transition-colors cursor-pointer"
                          title={t.delete}
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add / Edit Supplier Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-xs z-50 flex items-center justify-center p-4">
          <div className="bg-white dark:bg-[#1C1B1A] border border-[#D4D1CC] dark:border-neutral-800 w-full max-w-lg p-6 space-y-5 shadow-2xl">
            <div className="flex items-center justify-between border-b border-[#D4D1CC] dark:border-neutral-800 pb-3">
              <h3 className="font-bold text-neutral-900 dark:text-white text-sm flex items-center gap-2">
                <Building className="w-4 h-4" />
                <span>{editingSupplier ? t.editSupplier : t.addSupplier}</span>
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-neutral-400 hover:text-black dark:hover:text-white cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t.supplierName} <span className="text-red-500">*</span>
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  placeholder={lang === 'ar' ? 'مثال: مذخر الرشيد الأهلية للأدوية' : 'e.g., Dijla Pharma Wholesaler'}
                  className="w-full px-3 py-2 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-900 dark:text-white outline-none focus:border-neutral-900 dark:focus:border-white"
                />
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t.supplierPhone} <span className="text-red-500">*</span>
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.phone}
                    onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                    placeholder="0770 123 4567"
                    className="w-full px-3 py-2 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-900 dark:text-white outline-none font-mono"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                    {t.contactPerson}
                  </label>
                  <input
                    type="text"
                    value={formData.contactPerson}
                    onChange={(e) => setFormData({ ...formData, contactPerson: e.target.value })}
                    placeholder={lang === 'ar' ? 'اسم المندوب المسؤول' : 'Representative Name'}
                    className="w-full px-3 py-2 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-900 dark:text-white outline-none"
                  />
                </div>
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t.supplierCity}
                </label>
                <input
                  type="text"
                  value={formData.city}
                  onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                  placeholder={lang === 'ar' ? 'بغداد - شارع السعدون' : 'Baghdad, Al-Saadoun'}
                  className="w-full px-3 py-2 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-900 dark:text-white outline-none"
                />
              </div>

              <div>
                <label className="block text-xs font-bold text-neutral-700 dark:text-neutral-300 mb-1">
                  {t.supplierNotes}
                </label>
                <textarea
                  rows={3}
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  placeholder={
                    lang === 'ar'
                      ? 'ملاحظات بخصوص شروط الدفع، الخصومات، أو المواعيد...'
                      : 'Notes regarding payment terms, discounts...'
                  }
                  className="w-full px-3 py-2 bg-[#F8F7F4] dark:bg-neutral-900 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-900 dark:text-white outline-none"
                ></textarea>
              </div>

              <div className="flex items-center justify-end gap-3 border-t border-[#D4D1CC] dark:border-neutral-800 pt-4">
                <button
                  type="button"
                  onClick={() => setIsModalOpen(false)}
                  className="px-4 py-2 border border-[#D4D1CC] dark:border-neutral-700 text-xs font-bold text-neutral-700 dark:text-neutral-300 hover:bg-neutral-100 dark:hover:bg-neutral-800 transition-colors cursor-pointer"
                >
                  {t.cancel}
                </button>
                <button
                  type="submit"
                  className="px-5 py-2 bg-neutral-900 text-white dark:bg-white dark:text-black font-bold text-xs uppercase tracking-wider hover:bg-neutral-800 dark:hover:bg-neutral-200 transition-colors cursor-pointer"
                >
                  {t.save}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
};
