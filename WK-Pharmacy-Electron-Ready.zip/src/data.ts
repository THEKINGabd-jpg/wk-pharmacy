import { Medicine, Customer, Transaction, AppSettings, PharmacyUser, Supplier, ShortageItem } from './types';

export const INITIAL_MEDICINES: Medicine[] = [
  {
    id: 'med-1',
    tradeName: 'بانادول إكسترا',
    genericName: 'Paracetamol / Caffeine',
    company: 'Haleon',
    quantity: 145,
    costPrice: 32.00,
    price: 45.00,
    priceMoh: 38.00,
    expiryDate: '2025-08-12',
    category: 'مسكنات',
    status: 'available',
    barcode: '101',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuBVXpkoXWZB-jW4iGm_ueShj6T19N_XkePiO3Ed3cpH7tah1obQsex8vbR44L4dsm2EMZBqzpuxqTF9Fiz5j40FEHObGBYf_ZwE1-mry4jiznx4NuJVUr0EJCgJeNb1zPFKT2KAI_QLJ9L1qXn4jgqhbaeSLtjk5GmHBU_IYT0FTI8L96n60Q66-sSoWXaBOzi3t0ug_Ks-qyNL_vtnrPYnf99i2YD8ticWQMv_LWj5uZ_GSp10VC-XZBzK5CVPZDgTnV6vW2t4WA',
    unitMajor: 'علبة',
    unitMinor: 'شريط',
    unitsPerMajor: 2,
    costPriceMajor: 64.00,
    priceMajor: 90.00,
    priceMajorMoh: 76.00
  },
  {
    id: 'med-2',
    tradeName: 'أوجمنتين 1جم',
    genericName: 'Amoxicillin + Clavulanic Acid',
    company: 'GlaxoSmithKline',
    quantity: 120,
    costPrice: 65.00,
    price: 89.50,
    priceMoh: 75.00,
    expiryDate: '2025-12-30',
    category: 'مضادات حيوية',
    status: 'available',
    barcode: '102',
    unitMajor: 'علبة',
    unitMinor: 'شريط',
    unitsPerMajor: 2,
    costPriceMajor: 130.00,
    priceMajor: 179.00,
    priceMajorMoh: 150.00
  },
  {
    id: 'med-3',
    tradeName: 'فيتامين سي 1000 مجم',
    genericName: 'Ascorbic Acid',
    company: 'Sandoz',
    quantity: 85,
    costPrice: 85.00,
    price: 120.00,
    priceMoh: 100.00,
    expiryDate: '2026-03-15',
    category: 'فيتامينات',
    status: 'available',
    barcode: '103',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuKI58tQTm2JEssu2JHlCmRfEyfU_DG-a0PKcE9xvChyClrFYSQHbuEK0_I6CFaIomz-6cxTjnHJ0VtXftrFaGQKgyUyF9utci8Ldrf5dQrGrxIcDO2AxMBs5BJeBEMXulj2GTD4YuvPTwi3iDYfGRPPK8gSLbTCBZTu59O99JP2lDde271k0cVUX8E21QrabjR3-QbSr8iELMAOcljGTVv3h-gp3bq6-yFal0DbWLsMW8hRR5g1I3BIcU1XgINZaNfnB9T2cy79Q',
    unitMajor: 'علبة',
    unitMinor: 'عبوة',
    unitsPerMajor: 1,
    costPriceMajor: 85.00,
    priceMajor: 120.00,
    priceMajorMoh: 100.00
  },
  {
    id: 'med-4',
    tradeName: 'بروفين 400',
    genericName: 'Ibuprofen 400mg',
    company: 'Abbott',
    quantity: 12,
    costPrice: 12.00,
    price: 18.50,
    priceMoh: 15.00,
    expiryDate: '2024-11-30',
    category: 'مسكنات',
    status: 'low',
    barcode: '104',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuB-VWozqWgorP_nhqMoCfpF57Mc0B3gvfipfOrWa48uWiW4PIStJcSc-ToAVJtehdVSQeZVI5DfRGeKa3ci1LaalWWbioeoT3Aso1XIwhrfq2AenSMbozkAhwreolcZIov2t88smom8lsdybSnwTTmtBGGDYeuZJ0hiUNbaZ3zkQ36MUiHl7qzbIQ-7udcT8TIkc2D3Xny4Mh6ob4AmPS9OX4dE_I5iFPaa0Oh1zGfKrKuSYLKToR4Z-yHmCBOdC7V0Ty8LWEw0uA',
    unitMajor: 'علبة',
    unitMinor: 'شريط',
    unitsPerMajor: 3,
    costPriceMajor: 36.00,
    priceMajor: 55.50,
    priceMajorMoh: 45.00
  },
  {
    id: 'med-5',
    tradeName: 'أوتريفين بخاخ',
    genericName: 'Xylometazoline',
    company: 'Novartis',
    quantity: 18,
    costPrice: 17.50,
    price: 25.00,
    expiryDate: '2025-05-20',
    category: 'أدوية براد',
    status: 'available',
    barcode: '105',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuAwhZjfAbBMRN3P_2rfgqu0-5bOV6fGvVbfAXtvFaoiDW38IGXXYxmH8zh9Dcx1tXpQgl51d2-0OpZH5FF2pUfv1RhIsahfDpkjdTrvV-PsCR8x9j4b81n2r0tvL2EJTjBPhOdNgzt5CvsNybiiUnpG5JhQvIKYDvV3xdaBaFnL8fUrXC1olz5PjTPG-4-0GDSgSjuTOf7WiXQkU6B1PZqBLLfBGTANF1thMrcR0i9yWKgEgbIJP9xqZoMWaRwT2sOTUmV-2gtYvQ'
  },
  {
    id: 'med-6',
    tradeName: 'شراب كوفيدين',
    genericName: 'Codeine / Guaifenesin',
    company: 'Pharco',
    quantity: 45,
    costPrice: 40.00,
    price: 55.00,
    expiryDate: '2025-06-18',
    category: 'أدوية براد',
    status: 'available',
    barcode: '106',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuD8eXu7qvyvtVkZIGsObRSdpGCV0xnlug2vyrLQ0Om0x_BlDeeYuHQb_spXbw22YXdLbXGERr4NQzG0xTx2q4R8-SUPHmAcndldX4YUgBysBlzJosiKYAqZ3c4yx9bCFa7WyX-PKrrUgdlhkRat5znv1gbDJ929JwTjE6I7fpwnZ_RT_Q7xeGTY0DGzLSLMM9PtPTA6SomF_J2VLhwXO_r6xUZOgsvjV1I3RrIx0W8VOWSIbApctROnzVc_aAIQtRmwIYu7HOBlLA'
  },
  {
    id: 'med-7',
    tradeName: 'كمامات طبية (50 حبة)',
    genericName: 'Surgical Mask 3-Ply',
    company: 'Medical Care',
    quantity: 210,
    costPrice: 10.00,
    price: 15.00,
    expiryDate: '2027-01-01',
    category: 'مستلزمات طبية',
    status: 'available',
    barcode: '107',
    image: 'https://lh3.googleusercontent.com/aida-public/AB6AXuC9KV83Tn6SkiKD0TGZNgloOYuEMZWLVMU74_gBVWbKIWR6ZDKNjRERlAq6JJLB87mV3GgCRvpnfElkviXs37MgcYcyRCYpa_hiZd2wl5TyTCjLNr-3vwQfBH7_yR7QBH-27dUiNvaix1pCavDgegSN5Cc6HrVpmVxgosnK24R2u9XcrnFAL6FDfSXtajYN1pFI_5YKCbSCl87kuFHLOAntq_Uy3q2ehEd0PZsGSiD_VhUA8hlaoCZwrUr6ysY-hz0EMXklBPNxFA'
  },
  {
    id: 'med-8',
    tradeName: 'كونكور 5 بلس',
    genericName: 'Bisoprolol + HCTZ',
    company: 'Merck Group',
    quantity: 250,
    costPrice: 85.00,
    price: 112.50,
    expiryDate: '2026-02-15',
    category: 'أدوية الضغط',
    status: 'available',
    barcode: '108'
  },
  {
    id: 'med-9',
    tradeName: 'كلافيلاين',
    genericName: 'Amoxicillin Trio',
    company: 'Sandoz',
    quantity: 0,
    costPrice: 48.00,
    price: 65.00,
    expiryDate: '2023-12-01',
    category: 'مضادات حيوية',
    status: 'expired',
    barcode: '109'
  },
  {
    id: 'med-10',
    tradeName: 'أماريل 2جم',
    genericName: 'Glimepiride',
    company: 'Sanofi',
    quantity: 82,
    costPrice: 40.00,
    price: 54.00,
    expiryDate: '2025-05-20',
    category: 'أدوية السكري',
    status: 'available',
    barcode: '110'
  },
  {
    id: 'med-11',
    tradeName: 'كونجستال شراب',
    genericName: 'Paracetamol / Chlorpheniramine',
    company: 'Sigma',
    quantity: 45,
    costPrice: 14.00,
    price: 19.50,
    expiryDate: '2024-02-28',
    category: 'أدوية براد',
    status: 'expired',
    barcode: '111'
  },
  {
    id: 'med-12',
    tradeName: 'فولتارين جل',
    genericName: 'Diclofenac Sodium',
    company: 'Novartis',
    quantity: 67,
    costPrice: 32.00,
    price: 45.00,
    expiryDate: '2026-03-30',
    category: 'مسكنات',
    status: 'available',
    barcode: '112'
  }
];

export const INITIAL_CUSTOMERS: Customer[] = [
  { id: 'cust-1', name: 'محمد أحمد حسن', type: 'عميل مميز', code: '5492', isVip: true, discountRate: 5 },
  { id: 'cust-2', name: 'سارة خالد', type: 'عميل مميز', code: '3104', isVip: true, discountRate: 5 },
  { id: 'cust-3', name: 'عبدالرحمن يس', type: 'عميل مميز', code: '7210', isVip: true, discountRate: 5 },
  { id: 'cust-4', name: 'عميل نقدي', type: 'نقدي', code: '0000', isVip: false, discountRate: 0 }
];

export const INITIAL_USERS: PharmacyUser[] = [
  {
    id: 'user-1',
    name: 'وليد خالد',
    email: 'walid@wkpharmacy.com',
    role: 'admin',
    status: 'active',
    lastSeen: 'الآن',
    avatar: 'https://lh3.googleusercontent.com/aida-public/AB6AXuDN2i3Jc93gM-mxQ5FsUGzdH6ki2uDIvR7w3eNOfyZXPuKCGMqeapi-SMFafwyuqAJGeOHw_jXpdkfqMOKGRDQ7CNY84h3Zzrm5oSAc5Ge0Sjbt8woFqseHm-yVJmK_KsejV8YDqZM9iA7yOwcU6aUmlXOEut5RW9CGrwKAZUP_jP5V_AURJpo3OHMOzDdv7GHI5DD_6FEAjl44OIlxHCuH6tbBCNNUG2mB8Iyak-HAPavrvI8aKLe3y43nw6BJ3-YKlpLcxhMYPA'
  },
  {
    id: 'user-2',
    name: 'أحمد سمير',
    email: 'ahmed@wkpharmacy.com',
    role: 'pharmacist',
    status: 'active',
    lastSeen: 'منذ ساعتين'
  }
];

export const INITIAL_SETTINGS: AppSettings = {
  pharmacyName: 'صيدلية وليد خالد عبد',
  address: 'بغداد - شارع الصحة، المجمع الطبي الرقمي',
  phone: '+964 770 123 4567',
  email: 'contact@wkpharmacy.com',
  logo: '/pharmacy_logo.jpg',
  isDarkMode: false,
  language: 'ar',
  currency: 'IQD',
  taxRate: 0,
  users: INITIAL_USERS,
  theme: 'vintage'
};

export const INITIAL_TRANSACTIONS: Transaction[] = [
  {
    id: 'tx-1',
    invoiceNumber: 'INV-8902',
    customerName: 'محمد أحمد حسن',
    customerCode: '5492',
    date: '2026-07-17 10:30',
    itemsCount: 4,
    total: 156.00,
    status: 'completed',
    paymentMethod: 'cash',
    items: [
      { medicineId: 'med-1', tradeName: 'بانادول إكسترا', price: 45.00, quantity: 2 },
      { medicineId: 'med-4', tradeName: 'بروفين 400', price: 18.50, quantity: 2 },
      { medicineId: 'med-7', tradeName: 'كمامات طبية (50 حبة)', price: 15.00, quantity: 1 }
    ]
  },
  {
    id: 'tx-2',
    invoiceNumber: 'INV-8901',
    customerName: 'سارة خالد',
    customerCode: '3104',
    date: '2026-07-17 09:45',
    itemsCount: 2,
    total: 42.50,
    status: 'completed',
    paymentMethod: 'card',
    items: [
      { medicineId: 'med-4', tradeName: 'بروفين 400', price: 18.50, quantity: 1 },
      { medicineId: 'med-5', tradeName: 'أوتريفين بخاخ', price: 25.00, quantity: 1 }
    ]
  },
  {
    id: 'tx-3',
    invoiceNumber: 'INV-8900',
    customerName: 'عبدالرحمن يس',
    customerCode: '7210',
    date: '2026-07-16 14:12',
    itemsCount: 1,
    total: 210.00,
    status: 'pending',
    paymentMethod: 'deferred',
    items: [
      { medicineId: 'med-3', tradeName: 'فيتامين سي 1000 مجم', price: 120.00, quantity: 1 }
    ]
  },
  {
    id: 'tx-4',
    invoiceNumber: 'INV-8899',
    customerName: 'عميل نقدي',
    customerCode: '0000',
    date: '2026-07-16 08:30',
    itemsCount: 3,
    total: 85.00,
    status: 'cancelled',
    paymentMethod: 'cash',
    items: [
      { medicineId: 'med-1', tradeName: 'بانادول إكسترا', price: 45.00, quantity: 1 },
      { medicineId: 'med-12', tradeName: 'فولتارين جل', price: 45.00, quantity: 1 }
    ]
  }
];

export const INITIAL_SUPPLIERS: Supplier[] = [
  {
    id: 'sup-1',
    name: 'مذخر دجلة الأهلية للأدوية',
    contactPerson: 'علي المحمداوي',
    phone: '0770 123 4567',
    city: 'بغداد - السعدون',
    notes: 'موزع أدوية GSK و Novartis. الشحن أسبوعي.',
    totalInvoicesCount: 12,
    totalPurchases: 3200000,
    createdAt: '2026-01-10T10:00:00Z',
  },
  {
    id: 'sup-2',
    name: 'مذخر بغداد الدولي المستورد',
    contactPerson: 'د. حسنين فاروق',
    phone: '0780 987 6543',
    city: 'بغداد - الحارثية',
    notes: 'وكيل المكملات والفيتامينات والمستلزمات الطبية.',
    totalInvoicesCount: 8,
    totalPurchases: 1850000,
    createdAt: '2026-02-15T10:00:00Z',
  },
  {
    id: 'sup-3',
    name: 'شركة الفرات الوطنية لتوزيع الأدوية',
    contactPerson: 'عمار سلمان',
    phone: '0771 555 8899',
    city: 'النجف الأشرف - شارع المدينة',
    notes: 'تجهيز المحاليل الطبية وحقن البراد مع الالتزام بالتبريد.',
    totalInvoicesCount: 5,
    totalPurchases: 1400000,
    createdAt: '2026-03-01T10:00:00Z',
  }
];

export const INITIAL_SHORTAGES: ShortageItem[] = [
  {
    id: 'shortage-1',
    itemName: 'أوجمنتين 1 جم حبوب (Augmentin 1g)',
    category: 'مضادات حيوية',
    requestedQty: 10,
    unit: 'علبة',
    supplierName: 'مذخر دجلة الأهلية',
    priority: 'high',
    status: 'pending',
    notes: 'عاجل جداً - طلب صيدلاني مكرر من عدة مرضى',
    createdAt: '2026-07-22T09:30:00Z',
  },
  {
    id: 'shortage-2',
    itemName: 'امبرازول 20 ملغم كبسول (Omeprazole)',
    category: 'أدوية معدة',
    requestedQty: 5,
    unit: 'كرتونة',
    supplierName: 'مذخر الرشيد الأهلية',
    priority: 'medium',
    status: 'pending',
    notes: 'المخزون سينتهي خلال يومين',
    createdAt: '2026-07-22T14:15:00Z',
  },
  {
    id: 'shortage-3',
    itemName: 'محلول سالين 0.9% 500مل (Normal Saline)',
    category: 'مستلزمات طبية',
    requestedQty: 20,
    unit: 'عبوة',
    supplierName: 'شركة الفرات الوطنية',
    priority: 'high',
    status: 'ordered',
    notes: 'تم التواصل مع المندوب وفي انتظار التوصيل',
    createdAt: '2026-07-23T08:00:00Z',
  }
];

// Helper functions for localStorage persistence
const STORE_KEYS = {
  MEDICINES: 'wk_pharmacy_medicines',
  CUSTOMERS: 'wk_pharmacy_customers',
  SETTINGS: 'wk_pharmacy_settings',
  TRANSACTIONS: 'wk_pharmacy_transactions',
  SUPPLIERS: 'wk_pharmacy_suppliers',
  SHORTAGES: 'wk_pharmacy_shortages'
};

export function getStoredMedicines(): Medicine[] {
  const data = localStorage.getItem(STORE_KEYS.MEDICINES);
  if (!data) {
    localStorage.setItem(STORE_KEYS.MEDICINES, JSON.stringify(INITIAL_MEDICINES));
    return INITIAL_MEDICINES;
  }
  try {
    return JSON.parse(data);
  } catch {
    localStorage.setItem(STORE_KEYS.MEDICINES, JSON.stringify(INITIAL_MEDICINES));
    return INITIAL_MEDICINES;
  }
}

export function saveStoredMedicines(medicines: Medicine[]): void {
  localStorage.setItem(STORE_KEYS.MEDICINES, JSON.stringify(medicines));
}

export function getStoredCustomers(): Customer[] {
  const data = localStorage.getItem(STORE_KEYS.CUSTOMERS);
  if (!data) {
    localStorage.setItem(STORE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
    return INITIAL_CUSTOMERS;
  }
  try {
    return JSON.parse(data);
  } catch {
    localStorage.setItem(STORE_KEYS.CUSTOMERS, JSON.stringify(INITIAL_CUSTOMERS));
    return INITIAL_CUSTOMERS;
  }
}

export function saveStoredCustomers(customers: Customer[]): void {
  localStorage.setItem(STORE_KEYS.CUSTOMERS, JSON.stringify(customers));
}

export function getStoredSettings(): AppSettings {
  const data = localStorage.getItem(STORE_KEYS.SETTINGS);
  if (!data) {
    localStorage.setItem(STORE_KEYS.SETTINGS, JSON.stringify(INITIAL_SETTINGS));
    return INITIAL_SETTINGS;
  }
  try {
    const parsed = JSON.parse(data);
    if (!parsed.logo || parsed.logo.includes('lh3.googleusercontent.com/aida-public')) {
      parsed.logo = '/pharmacy_logo.jpg';
      saveStoredSettings(parsed);
    }
    return parsed;
  } catch {
    localStorage.setItem(STORE_KEYS.SETTINGS, JSON.stringify(INITIAL_SETTINGS));
    return INITIAL_SETTINGS;
  }
}

export function saveStoredSettings(settings: AppSettings): void {
  localStorage.setItem(STORE_KEYS.SETTINGS, JSON.stringify(settings));
}

export function getStoredTransactions(): Transaction[] {
  const data = localStorage.getItem(STORE_KEYS.TRANSACTIONS);
  if (!data) {
    localStorage.setItem(STORE_KEYS.TRANSACTIONS, JSON.stringify(INITIAL_TRANSACTIONS));
    return INITIAL_TRANSACTIONS;
  }
  try {
    return JSON.parse(data);
  } catch {
    localStorage.setItem(STORE_KEYS.TRANSACTIONS, JSON.stringify(INITIAL_TRANSACTIONS));
    return INITIAL_TRANSACTIONS;
  }
}

export function saveStoredTransactions(transactions: Transaction[]): void {
  localStorage.setItem(STORE_KEYS.TRANSACTIONS, JSON.stringify(transactions));
}

export function getStoredSuppliers(): Supplier[] {
  const data = localStorage.getItem(STORE_KEYS.SUPPLIERS);
  if (!data) {
    localStorage.setItem(STORE_KEYS.SUPPLIERS, JSON.stringify(INITIAL_SUPPLIERS));
    return INITIAL_SUPPLIERS;
  }
  try {
    return JSON.parse(data);
  } catch {
    localStorage.setItem(STORE_KEYS.SUPPLIERS, JSON.stringify(INITIAL_SUPPLIERS));
    return INITIAL_SUPPLIERS;
  }
}

export function saveStoredSuppliers(suppliers: Supplier[]): void {
  localStorage.setItem(STORE_KEYS.SUPPLIERS, JSON.stringify(suppliers));
}

export function getStoredShortages(): ShortageItem[] {
  const data = localStorage.getItem(STORE_KEYS.SHORTAGES);
  if (!data) {
    localStorage.setItem(STORE_KEYS.SHORTAGES, JSON.stringify(INITIAL_SHORTAGES));
    return INITIAL_SHORTAGES;
  }
  try {
    return JSON.parse(data);
  } catch {
    localStorage.setItem(STORE_KEYS.SHORTAGES, JSON.stringify(INITIAL_SHORTAGES));
    return INITIAL_SHORTAGES;
  }
}

export function saveStoredShortages(shortages: ShortageItem[]): void {
  localStorage.setItem(STORE_KEYS.SHORTAGES, JSON.stringify(shortages));
}
