import { 
  collection, 
  doc, 
  setDoc, 
  deleteDoc, 
  getDocs, 
  onSnapshot, 
  writeBatch 
} from 'firebase/firestore';
import { db, OperationType, handleFirestoreError } from './firebase';
import { Medicine, Customer, Transaction, AppSettings } from './types';

// Medicines Sync
export async function saveMedicineToCloud(medicine: Medicine) {
  const path = `medicines/${medicine.id}`;
  try {
    await setDoc(doc(db, 'medicines', medicine.id), medicine);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteMedicineFromCloud(medicineId: string) {
  const path = `medicines/${medicineId}`;
  try {
    await deleteDoc(doc(db, 'medicines', medicineId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeMedicinesFromCloud(onUpdate: (medicines: Medicine[]) => void, onError: (err: any) => void) {
  const path = 'medicines';
  return onSnapshot(collection(db, 'medicines'), (snapshot) => {
    const medicines: Medicine[] = [];
    snapshot.forEach((doc) => {
      medicines.push(doc.data() as Medicine);
    });
    onUpdate(medicines);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    onError(error);
  });
}

// Customers Sync
export async function saveCustomerToCloud(customer: Customer) {
  const path = `customers/${customer.id}`;
  try {
    await setDoc(doc(db, 'customers', customer.id), customer);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export async function deleteCustomerFromCloud(customerId: string) {
  const path = `customers/${customerId}`;
  try {
    await deleteDoc(doc(db, 'customers', customerId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, path);
  }
}

export function subscribeCustomersFromCloud(onUpdate: (customers: Customer[]) => void, onError: (err: any) => void) {
  const path = 'customers';
  return onSnapshot(collection(db, 'customers'), (snapshot) => {
    const customers: Customer[] = [];
    snapshot.forEach((doc) => {
      customers.push(doc.data() as Customer);
    });
    onUpdate(customers);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    onError(error);
  });
}

// Transactions Sync
export async function saveTransactionToCloud(transaction: Transaction) {
  const path = `transactions/${transaction.id}`;
  try {
    await setDoc(doc(db, 'transactions', transaction.id), transaction);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeTransactionsFromCloud(onUpdate: (transactions: Transaction[]) => void, onError: (err: any) => void) {
  const path = 'transactions';
  return onSnapshot(collection(db, 'transactions'), (snapshot) => {
    const transactions: Transaction[] = [];
    snapshot.forEach((doc) => {
      transactions.push(doc.data() as Transaction);
    });
    // Sort transactions by date descending
    transactions.sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
    onUpdate(transactions);
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    onError(error);
  });
}

// Settings Sync
export async function saveSettingsToCloud(settings: AppSettings) {
  const path = 'settings/global';
  try {
    await setDoc(doc(db, 'settings', 'global'), settings);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, path);
  }
}

export function subscribeSettingsFromCloud(onUpdate: (settings: AppSettings) => void, onError: (err: any) => void) {
  const path = 'settings/global';
  return onSnapshot(doc(db, 'settings', 'global'), (snapshot) => {
    if (snapshot.exists()) {
      onUpdate(snapshot.data() as AppSettings);
    }
  }, (error) => {
    handleFirestoreError(error, OperationType.GET, path);
    onError(error);
  });
}

// Batch Upload existing local data to Cloud
export async function uploadLocalDataToCloud(
  medicines: Medicine[],
  customers: Customer[],
  transactions: Transaction[],
  settings: AppSettings
) {
  try {
    const batch = writeBatch(db);

    medicines.forEach(m => {
      batch.set(doc(db, 'medicines', m.id), m);
    });

    customers.forEach(c => {
      batch.set(doc(db, 'customers', c.id), c);
    });

    transactions.forEach(t => {
      batch.set(doc(db, 'transactions', t.id), t);
    });

    if (settings) {
      batch.set(doc(db, 'settings', 'global'), settings);
    }

    await batch.commit();
    return true;
  } catch (error) {
    console.error("Batch upload failed:", error);
    handleFirestoreError(error, OperationType.WRITE, 'batch_upload');
    return false;
  }
}
