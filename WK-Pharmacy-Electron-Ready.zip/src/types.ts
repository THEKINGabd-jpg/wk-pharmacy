export type PricingMode = 'pharmacy' | 'moh';

export interface Medicine {
  id: string;
  tradeName: string;
  genericName: string;
  company: string;
  quantity: number; // total units in terms of smallest unit (minor)
  costPrice?: number; // purchase/cost price per minor unit
  price: number; // pharmacy selling price of the sold item (minor unit price)
  priceMoh?: number; // Iraqi Ministry of Health official price (minor unit)
  expiryDate: string;
  category: string;
  status: 'available' | 'low' | 'expired' | 'out_of_stock';
  image?: string;
  barcode?: string;
  unitMajor?: string; // e.g., 'علبة' or 'باكيت'
  unitMinor?: string; // e.g., 'شريط' or 'أمبول' or 'حبة'
  unitsPerMajor?: number; // how many minor units in one major unit (e.g., 10)
  costPriceMajor?: number; // purchase/cost price of 1 major unit
  priceMajor?: number; // pharmacy selling price of 1 major unit
  priceMajorMoh?: number; // Iraqi Ministry of Health official price of 1 major unit
}

export interface TransactionItem {
  medicineId: string;
  tradeName: string;
  price: number;
  quantity: number;
  soldAs?: 'major' | 'minor';
  unitName?: string;
}

export interface Transaction {
  id: string;
  invoiceNumber: string;
  customerName: string;
  customerCode?: string;
  date: string;
  itemsCount: number;
  subtotal?: number;
  discountAmount?: number;
  total: number;
  status: 'completed' | 'pending' | 'cancelled';
  items: TransactionItem[];
  paymentMethod: 'cash' | 'card' | 'deferred';
  pricingMode?: PricingMode;
}

export interface Customer {
  id: string;
  name: string;
  type: string;
  code: string;
  discountRate?: number;
  isVip?: boolean;
}

export interface Supplier {
  id: string;
  name: string;
  phone: string;
  address?: string;
  city?: string;
  contactPerson?: string;
  notes?: string;
  totalInvoicesCount?: number;
  totalPurchases?: number;
  createdAt: string;
}

export interface OcrInvoiceItem {
  tradeName: string;
  genericName?: string;
  company?: string;
  category?: string;
  qtyMajor?: number;
  unitsPerMajor?: number;
  qtyMinor?: number;
  costPriceMajor?: number;
  costPriceMinor?: number;
  priceMajor?: number;
  priceMinor?: number;
  priceMajorMoh?: number;
  priceMinorMoh?: number;
  expiryDate?: string;
  barcode?: string;
}

export interface PharmacyUser {
  id: string;
  name: string;
  email: string;
  role: 'admin' | 'pharmacist' | 'cashier';
  status: 'active' | 'inactive';
  lastSeen: string;
  avatar?: string;
}

export interface ShortageItem {
  id: string;
  itemName: string;
  category?: string;
  requestedQty?: number;
  unit?: string;
  notes?: string;
  supplierName?: string;
  priority?: 'high' | 'medium' | 'low';
  status?: 'pending' | 'ordered' | 'received';
  createdAt: string;
}

export interface AppSettings {
  pharmacyName: string;
  address: string;
  phone: string;
  email: string;
  logo: string;
  isDarkMode: boolean;
  language: 'ar' | 'en';
  currency: 'IQD' | 'SAR' | 'USD' | 'EGP';
  taxRate: number; // e.g. 15 for 15%
  users: PharmacyUser[];
  theme?: 'vintage' | 'modern' | 'indigo' | 'emerald';
  whatsappNumber?: string;
}
