import { useState, useEffect } from 'react';
import { Medicine, Transaction, AppSettings, Customer, Supplier, ShortageItem } from './types';
import { 
  getStoredMedicines, saveStoredMedicines,
  getStoredTransactions, saveStoredTransactions,
  getStoredCustomers, saveStoredCustomers,
  getStoredSettings, saveStoredSettings,
  getStoredSuppliers, saveStoredSuppliers,
  getStoredShortages, saveStoredShortages
} from './data';
import Sidebar from './components/Sidebar';
import DashboardView from './components/DashboardView';
import POSView from './components/POSView';
import InventoryView from './components/InventoryView';
import SettingsView from './components/SettingsView';
import ReportsView from './components/ReportsView';
import { SuppliersView } from './components/SuppliersView';
import { ShortagesView } from './components/ShortagesView';
import { translations } from './translations';
import { LayoutDashboard, Receipt, Package, Truck, BarChart3, Settings, Menu, Moon, Sun, Languages, ClipboardList, Laptop } from 'lucide-react';
import { DesktopAppModal } from './components/DesktopAppModal';

// Firebase integrations
import { 
  setupAuthListener, 
  loginWithGoogle, 
  logoutUser 
} from './firebase';
import { 
  saveMedicineToCloud, 
  deleteMedicineFromCloud, 
  subscribeMedicinesFromCloud,
  saveCustomerToCloud,
  subscribeCustomersFromCloud,
  saveTransactionToCloud, 
  subscribeTransactionsFromCloud,
  saveSettingsToCloud, 
  subscribeSettingsFromCloud,
  uploadLocalDataToCloud
} from './syncService';
import { User as FirebaseUser } from 'firebase/auth';

export default function App() {
  // Core persistent states
  const [medicines, setMedicines] = useState<Medicine[]>([]);
  const [transactions, setTransactions] = useState<Transaction[]>([]);
  const [customers, setCustomers] = useState<Customer[]>([]);
  const [suppliers, setSuppliers] = useState<Supplier[]>([]);
  const [shortages, setShortages] = useState<ShortageItem[]>([]);
  const [settings, setSettings] = useState<AppSettings | null>(null);

  // Cloud & Installer states
  const [currentUser, setCurrentUser] = useState<FirebaseUser | null>(null);
  const [isSyncing, setIsSyncing] = useState<boolean>(false);
  const [deferredPrompt, setDeferredPrompt] = useState<any>(null);
  const [isDesktopModalOpen, setIsDesktopModalOpen] = useState(false);

  // Tab router state
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  
  // Mobile drawer trigger
  const [isMobileDrawerOpen, setIsMobileDrawerOpen] = useState(false);

  // PWA installer listener
  useEffect(() => {
    const handleBeforeInstallPrompt = (e: any) => {
      e.preventDefault();
      setDeferredPrompt(e);
    };
    window.addEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    return () => {
      window.removeEventListener('beforeinstallprompt', handleBeforeInstallPrompt);
    };
  }, []);

  const handleInstallPWA = () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    deferredPrompt.userChoice.then((choiceResult: any) => {
      if (choiceResult.outcome === 'accepted') {
        console.log('User accepted the install prompt');
      } else {
        console.log('User dismissed the install prompt');
      }
      setDeferredPrompt(null);
    });
  };

  // Auth State Listener
  useEffect(() => {
    const unsubscribeAuth = setupAuthListener((user) => {
      setCurrentUser(user);
    });
    return () => unsubscribeAuth();
  }, []);

  // Real-time Cloud Subscriptions
  useEffect(() => {
    if (!currentUser) return;

    setIsSyncing(true);
    const unsubMedicines = subscribeMedicinesFromCloud(
      (cloudMeds) => {
        if (cloudMeds.length > 0) {
          setMedicines(cloudMeds);
          saveStoredMedicines(cloudMeds);
        }
      },
      (err) => console.error("Cloud medicines sync error:", err)
    );

    const unsubCustomers = subscribeCustomersFromCloud(
      (cloudCusts) => {
        if (cloudCusts.length > 0) {
          setCustomers(cloudCusts);
          saveStoredCustomers(cloudCusts);
        }
      },
      (err) => console.error("Cloud customers sync error:", err)
    );

    const unsubTransactions = subscribeTransactionsFromCloud(
      (cloudTxs) => {
        if (cloudTxs.length > 0) {
          setTransactions(cloudTxs);
          saveStoredTransactions(cloudTxs);
         }
      },
      (err) => console.error("Cloud transactions sync error:", err)
    );

    const unsubSettings = subscribeSettingsFromCloud(
      (cloudSettings) => {
        if (cloudSettings) {
          setSettings(cloudSettings);
          saveStoredSettings(cloudSettings);
        }
        setIsSyncing(false);
      },
      (err) => {
        console.error("Cloud settings sync error:", err);
        setIsSyncing(false);
      }
    );

    return () => {
      unsubMedicines();
      unsubCustomers();
      unsubTransactions();
      unsubSettings();
    };
  }, [currentUser]);

  // Push local data helper
  const handlePushLocalToCloud = async () => {
    if (!currentUser) return;
    setIsSyncing(true);
    const success = await uploadLocalDataToCloud(medicines, customers, transactions, settings!);
    setIsSyncing(false);
    if (success) {
      alert(settings?.language === 'ar' ? 'تم رفع ومزامنة جميع البيانات المحلية بنجاح!' : 'All local data uploaded & synced successfully!');
    } else {
      alert(settings?.language === 'ar' ? 'فشلت المزامنة. يرجى التأكد من صلاحيات الاتصال.' : 'Sync failed. Please check connection permissions.');
    }
  };

  const handleLoginWithGoogle = async () => {
    try {
      await loginWithGoogle();
    } catch (err) {
      console.error("Login failed:", err);
    }
  };

  const handleLogout = async () => {
    try {
      await logoutUser();
      setCurrentUser(null);
    } catch (err) {
      console.error("Logout failed:", err);
    }
  };

  // 1. Initial State Fetching
  useEffect(() => {
    setMedicines(getStoredMedicines());
    setTransactions(getStoredTransactions());
    setCustomers(getStoredCustomers());
    setSuppliers(getStoredSuppliers());
    setShortages(getStoredShortages());
    setSettings(getStoredSettings());
  }, []);

  // 2. Dark Mode and Dir Side Effects
  useEffect(() => {
    if (!settings) return;

    // Toggle Dark class on root HTML element
    if (settings.isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }

    // Set document reading direction
    document.documentElement.dir = settings.language === 'ar' ? 'rtl' : 'ltr';
    document.documentElement.lang = settings.language;

    // Apply the design theme
    document.documentElement.setAttribute('data-theme', settings.theme || 'vintage');
  }, [settings]);

  if (!settings) {
    return (
      <div className="flex items-center justify-center h-screen bg-slate-50 dark:bg-slate-950">
        <div className="flex flex-col items-center gap-3">
          <div className="w-12 h-12 rounded-full border-4 border-teal-600 border-t-transparent animate-spin"></div>
          <span className="text-xs text-slate-400 font-semibold font-sans">WK Pharmacy Loading...</span>
        </div>
      </div>
    );
  }

  const lang = settings.language;
  const isRtl = lang === 'ar';
  const t = translations[lang];

  // Global modifiers
  const handleUpdateMedicines = (updated: Medicine[]) => {
    setMedicines(updated);
    saveStoredMedicines(updated);
  };

  const handleUpdateTransactions = (updated: Transaction[]) => {
    setTransactions(updated);
    saveStoredTransactions(updated);
  };

  const handleUpdateSettings = (updated: AppSettings) => {
    setSettings(updated);
    saveStoredSettings(updated);
    if (currentUser) {
      saveSettingsToCloud(updated);
    }
  };

  // Add individual transactions (POS checkouts)
  const handleAddTransaction = (newTx: Transaction) => {
    const updated = [newTx, ...transactions];
    handleUpdateTransactions(updated);
    if (currentUser) {
      saveTransactionToCloud(newTx);
    }
  };

  // Add Customer handler
  const handleAddCustomer = (newCust: Customer) => {
    const updated = [...customers, newCust];
    setCustomers(updated);
    saveStoredCustomers(updated);
    if (currentUser) {
      saveCustomerToCloud(newCust);
    }
  };

  // Update Inventory directly from POS
  const handleUpdateInventory = (medId: string, qtyDelta: number) => {
    const updated = medicines.map(m => {
      if (m.id === medId) {
        const qty = Math.max(0, m.quantity + qtyDelta);
        let status = m.status;
        if (qty <= 0) {
          status = 'out_of_stock';
        } else if (qty < 20) {
          status = 'low';
        } else if (new Date(m.expiryDate) < new Date()) {
          status = 'expired';
        } else {
          status = 'available';
        }
        const updatedMed = { ...m, quantity: qty, status };
        if (currentUser) {
          saveMedicineToCloud(updatedMed);
        }
        return updatedMed;
      }
      return m;
    });
    handleUpdateMedicines(updated);
  };

  // CRUD Inventory additions
  const handleAddMedicine = (newMed: Medicine) => {
    const updated = [newMed, ...medicines];
    handleUpdateMedicines(updated);
    if (currentUser) {
      saveMedicineToCloud(newMed);
    }
  };

  const handleUpdateMedicine = (updatedMed: Medicine) => {
    const updated = medicines.map(m => m.id === updatedMed.id ? updatedMed : m);
    handleUpdateMedicines(updated);
    if (currentUser) {
      saveMedicineToCloud(updatedMed);
    }
  };

  const handleDeleteMedicine = (medId: string) => {
    const updated = medicines.filter(m => m.id !== medId);
    handleUpdateMedicines(updated);
    if (currentUser) {
      deleteMedicineFromCloud(medId);
    }
  };

  // Supplier CRUD Handlers
  const handleAddSupplier = (supplierData: Omit<Supplier, 'id' | 'createdAt'>) => {
    const newSupplier: Supplier = {
      ...supplierData,
      id: `sup-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    const updated = [newSupplier, ...suppliers];
    setSuppliers(updated);
    saveStoredSuppliers(updated);
  };

  const handleUpdateSupplier = (updatedSupplier: Supplier) => {
    const updated = suppliers.map((s) => (s.id === updatedSupplier.id ? updatedSupplier : s));
    setSuppliers(updated);
    saveStoredSuppliers(updated);
  };

  const handleDeleteSupplier = (id: string) => {
    const updated = suppliers.filter((s) => s.id !== id);
    setSuppliers(updated);
    saveStoredSuppliers(updated);
  };

  // Shortage CRUD Handlers
  const handleAddShortage = (shortageData: Omit<ShortageItem, 'id' | 'createdAt'>) => {
    const newShortage: ShortageItem = {
      ...shortageData,
      id: `shortage-${Date.now()}`,
      createdAt: new Date().toISOString(),
    };
    const updated = [newShortage, ...shortages];
    setShortages(updated);
    saveStoredShortages(updated);
  };

  const handleUpdateShortage = (updatedShortage: ShortageItem) => {
    const updated = shortages.map((s) => (s.id === updatedShortage.id ? updatedShortage : s));
    setShortages(updated);
    saveStoredShortages(updated);
  };

  const handleDeleteShortage = (id: string) => {
    const updated = shortages.filter((s) => s.id !== id);
    setShortages(updated);
    saveStoredShortages(updated);
  };

  // Direct toggle helpers for top bar fast accessibility
  const handleToggleLanguage = () => {
    const nextLang = settings.language === 'ar' ? 'en' : 'ar';
    handleUpdateSettings({
      ...settings,
      language: nextLang
    });
  };

  const handleToggleDarkMode = () => {
    handleUpdateSettings({
      ...settings,
      isDarkMode: !settings.isDarkMode
    });
  };

  // Render correct view block
  const renderActiveView = () => {
    switch (activeTab) {
      case 'dashboard':
        return (
          <DashboardView 
            medicines={medicines}
            transactions={transactions}
            settings={settings}
            lang={lang}
            onSwitchToPOS={() => setActiveTab('cashier')}
          />
        );
      case 'cashier':
        return (
          <POSView 
            medicines={medicines}
            customers={customers}
            settings={settings}
            lang={lang}
            onAddTransaction={handleAddTransaction}
            onUpdateInventory={handleUpdateInventory}
            onAddShortage={handleAddShortage}
            onAddCustomer={handleAddCustomer}
          />
        );
      case 'inventory':
        return (
          <InventoryView 
            medicines={medicines}
            settings={settings}
            lang={lang}
            onAddMedicine={handleAddMedicine}
            onUpdateMedicine={handleUpdateMedicine}
            onDeleteMedicine={handleDeleteMedicine}
          />
        );
      case 'shortages':
        return (
          <ShortagesView
            settings={settings}
            shortages={shortages}
            medicines={medicines}
            suppliers={suppliers}
            onAddShortage={handleAddShortage}
            onUpdateShortage={handleUpdateShortage}
            onDeleteShortage={handleDeleteShortage}
            onUpdateSettings={handleUpdateSettings}
          />
        );
      case 'suppliers':
        return (
          <SuppliersView
            settings={settings}
            suppliers={suppliers}
            onAddSupplier={handleAddSupplier}
            onUpdateSupplier={handleUpdateSupplier}
            onDeleteSupplier={handleDeleteSupplier}
          />
        );
      case 'reports':
        return (
          <ReportsView 
            medicines={medicines}
            transactions={transactions}
            settings={settings}
            lang={lang}
          />
        );
      case 'settings':
        return (
          <SettingsView 
            settings={settings}
            lang={lang}
            onUpdateSettings={handleUpdateSettings}
            currentUser={currentUser}
            onLoginWithGoogle={handleLoginWithGoogle}
            onLogout={handleLogout}
            onPushLocalToCloud={handlePushLocalToCloud}
            isSyncing={isSyncing}
            deferredPrompt={deferredPrompt}
            onInstallPWA={handleInstallPWA}
          />
        );
      default:
        return <div>View not found</div>;
    }
  };

  const mobileMenuItems = [
    { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
    { id: 'cashier', label: t.cashier, icon: Receipt },
    { id: 'inventory', label: t.inventory, icon: Package },
    { id: 'shortages', label: t.shortages || 'النقوصات', icon: ClipboardList },
    { id: 'suppliers', label: t.suppliers || 'الموردين', icon: Truck },
    { id: 'settings', label: t.settings, icon: Settings },
  ];

  return (
    <div className="min-h-screen bg-[#F4F2EE] dark:bg-[#121110] text-neutral-900 dark:text-[#EBE9E5] flex flex-col font-sans transition-colors duration-300 relative overflow-hidden">
      
      {/* Background Watermark Logo */}
      <div className="fixed inset-0 pointer-events-none z-0 flex items-center justify-center overflow-hidden opacity-[0.035] dark:opacity-[0.045] select-none">
        <img 
          src={settings.logo || '/pharmacy_logo.jpg'} 
          alt="Pharmacy Background Watermark" 
          className="w-[450px] h-[450px] sm:w-[600px] sm:h-[600px] lg:w-[750px] lg:h-[750px] object-contain filter grayscale-[15%]"
          referrerPolicy="no-referrer"
        />
      </div>

      {/* Desktop Sidebar Layout */}
      <Sidebar 
        activeTab={activeTab} 
        setActiveTab={setActiveTab} 
        settings={settings}
        lang={lang}
        onOpenDesktopModal={() => setIsDesktopModalOpen(true)}
      />

      {/* Main Content frame Wrapper */}
      <div className="flex-1 flex flex-col"
        style={{
          marginRight: isRtl ? '0px' : '0px',
          marginLeft: isRtl ? '0px' : '0px',
          paddingRight: isRtl ? '0px' : '0px',
          paddingLeft: isRtl ? '0px' : '0px',
        }}
      >
        {/* Responsive Desktop Padding offset */}
        <div className={`flex-1 flex flex-col lg:pl-0 lg:pr-0 ${isRtl ? 'lg:pr-[280px]' : 'lg:pl-[280px]'}`}>
          
          {/* TOP BAR / Header shell */}
          <header className="sticky top-0 z-40 bg-[#EBE9E5]/90 dark:bg-[#1C1B1A]/95 backdrop-blur-md border-b border-[#D4D1CC] dark:border-neutral-800 px-6 py-4 flex justify-between items-center"
            style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
          >
            {/* Left/Right Slogan */}
            <div className="flex items-center gap-3" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              <button 
                onClick={() => setIsMobileDrawerOpen(true)}
                className="lg:hidden p-2 hover:bg-[#DEDCD7] dark:hover:bg-neutral-800 rounded-none text-neutral-600 cursor-pointer border border-[#D4D1CC] dark:border-neutral-800"
              >
                <Menu className="w-4 h-4" />
              </button>
              
              {/* Responsive Logo Title on Desktop Sidebar collapse */}
              <div className="flex flex-col text-right items-start lg:hidden"
                style={{ textAlign: isRtl ? 'right' : 'left', alignItems: isRtl ? 'flex-start' : 'flex-end' }}
              >
                <h1 className="text-sm font-bold text-neutral-900 dark:text-white tracking-tight leading-none">{settings.pharmacyName}</h1>
                <span className="text-[9px] text-[#5A5A40] dark:text-neutral-400 font-bold tracking-[0.15em] mt-1.5 uppercase leading-none">{t.clinicalSlogan}</span>
              </div>
            </div>

            {/* Header controls togglers */}
            <div className="flex items-center gap-2" style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}>
              {/* Desktop App Installer button */}
              <button
                onClick={() => setIsDesktopModalOpen(true)}
                className="hidden sm:flex items-center gap-1.5 px-3 py-2 bg-amber-500 hover:bg-amber-600 text-black rounded-none text-[9px] tracking-widest font-extrabold uppercase transition-all cursor-pointer border border-amber-600 shadow-xs"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
                title={lang === 'ar' ? 'تثبيت تطبيق الصيدلية على سطح المكتب' : 'Install Desktop App'}
              >
                <Laptop className="w-3.5 h-3.5 text-black" />
                <span>{lang === 'ar' ? 'تطبيق سطح المكتب' : 'Desktop App'}</span>
              </button>

              {/* Language dynamic badge switcher */}
              <button 
                onClick={handleToggleLanguage}
                className="flex items-center gap-1.5 px-3 py-2 bg-[#DEDCD7] hover:bg-[#D4D1CC] dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-[#EBE9E5] rounded-none text-[9px] tracking-widest font-bold uppercase transition-all cursor-pointer border border-[#D4D1CC] dark:border-neutral-700"
                style={{ flexDirection: isRtl ? 'row' : 'row-reverse' }}
              >
                <Languages className="w-3.5 h-3.5 text-neutral-900 dark:text-white" />
                <span>{lang === 'ar' ? 'English' : 'العربية'}</span>
              </button>

              {/* Night mode toggle widget */}
              <button 
                onClick={handleToggleDarkMode}
                className="p-2 bg-[#DEDCD7] hover:bg-[#D4D1CC] dark:bg-neutral-800 dark:hover:bg-neutral-700 text-neutral-800 dark:text-[#EBE9E5] rounded-none transition-all cursor-pointer border border-[#D4D1CC] dark:border-neutral-700"
              >
                {settings.isDarkMode ? <Sun className="w-3.5 h-3.5 text-amber-500" /> : <Moon className="w-3.5 h-3.5 text-neutral-900 dark:text-white" />}
              </button>
              
              {/* Profile Image shortcut */}
              <div className="w-9 h-9 rounded-none bg-[#DEDCD7] border border-[#D4D1CC] dark:border-neutral-800 overflow-hidden shrink-0 flex items-center justify-center">
                <img 
                  className="w-full h-full object-cover" 
                  alt="Doctor avatar" 
                  src="https://lh3.googleusercontent.com/aida-public/AB6AXuDN2i3Jc93gM-mxQ5FsUGzdH6ki2uDIvR7w3eNOfyZXPuKCGMqeapi-SMFafwyuqAJGeOHw_jXpdkfqMOKGRDQ7CNY84h3Zzrm5oSAc5Ge0Sjbt8woFqseHm-yVJmK_KsejV8YDqZM9iA7yOwcU6aUmlXOEut5RW9CGrwKAZUP_jP5V_AURJpo3OHMOzDdv7GHI5DD_6FEAjl44OIlxHCuH6tbBCNNUG2mB8Iyak-HAPavrvI8aKLe3y43nw6BJ3-YKlpLcxhMYPA"
                  referrerPolicy="no-referrer"
                />
              </div>
            </div>
          </header>

          {/* Core Content Stage */}
          <main className="flex-grow p-6 md:p-8 overflow-y-auto no-scrollbar max-w-7xl mx-auto w-full">
            {renderActiveView()}
          </main>
        </div>
      </div>

      {/* MOBILE BOTTOM NAVIGATION BAR */}
      <div className="lg:hidden fixed bottom-0 left-0 right-0 z-40 bg-[#EBE9E5]/95 dark:bg-[#1C1B1A]/95 backdrop-blur-md border-t border-[#D4D1CC] dark:border-neutral-800 px-4 py-2 flex justify-around items-center">
        {mobileMenuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => {
                setActiveTab(item.id);
                setIsMobileDrawerOpen(false);
              }}
              className={`flex flex-col items-center gap-1.5 py-1.5 px-3 rounded-none cursor-pointer uppercase tracking-widest text-[9px] ${
                isActive ? 'text-neutral-900 dark:text-white font-bold border-b-2 border-neutral-900 dark:border-white' : 'text-neutral-500 dark:text-neutral-400'
              }`}
            >
              <Icon className="w-4 h-4" />
              <span className="font-sans leading-none mt-1">{item.label}</span>
            </button>
          );
        })}
      </div>

      {/* MOBILE DRAWER SIDEBAR (SLIDE OVER) */}
      {isMobileDrawerOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex" style={{ direction: isRtl ? 'rtl' : 'ltr' }}>
          {/* Overlay backdrop */}
          <div 
            onClick={() => setIsMobileDrawerOpen(false)}
            className="fixed inset-0 bg-neutral-900/40 backdrop-blur-xs transition-opacity duration-300"
          ></div>
          
          {/* Drawer content frame */}
          <div className="relative flex flex-col w-[260px] bg-[#EBE9E5] dark:bg-[#1C1B1A] h-full p-6 gap-2 z-50 border-l border-[#D4D1CC] dark:border-neutral-800"
            style={{
              marginRight: isRtl ? 0 : 'auto',
              marginLeft: isRtl ? 'auto' : 0,
            }}
          >
            <div className="flex items-center gap-3 py-5 border-b border-[#D4D1CC] dark:border-neutral-800">
              <div className="w-8 h-8 bg-neutral-900 dark:bg-white flex items-center justify-center text-white dark:text-black shrink-0 font-bold font-sans">WK</div>
              <h1 className="text-sm font-bold text-neutral-900 dark:text-white tracking-tight">{settings.pharmacyName}</h1>
            </div>

            <nav className="flex flex-col gap-1 py-4 flex-grow">
              {[
                { id: 'dashboard', label: t.dashboard, icon: LayoutDashboard },
                { id: 'cashier', label: t.cashier, icon: Receipt },
                { id: 'inventory', label: t.inventory, icon: Package },
                { id: 'reports', label: t.reports, icon: BarChart3 },
                { id: 'settings', label: t.settings, icon: Settings },
              ].map((item) => {
                const Icon = item.icon;
                const isActive = activeTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => {
                      setActiveTab(item.id);
                      setIsMobileDrawerOpen(false);
                    }}
                    className={`w-full flex items-center gap-3 px-4 py-3.5 transition-all text-right cursor-pointer uppercase tracking-widest text-[9px] ${
                      isActive 
                        ? 'bg-neutral-900 dark:bg-white text-white dark:text-black font-bold' 
                        : 'text-neutral-600 dark:text-neutral-400 hover:bg-[#DEDCD7] dark:hover:bg-neutral-800/60'
                    }`}
                    style={{
                      flexDirection: isRtl ? 'row' : 'row-reverse',
                      justifyContent: isRtl ? 'flex-start' : 'flex-end',
                    }}
                  >
                    <Icon className="w-4 h-4 shrink-0" />
                    <span className="font-sans font-bold">{item.label}</span>
                  </button>
                );
              })}
            </nav>
          </div>
        </div>
      )}

      {/* Desktop App Installation Modal */}
      <DesktopAppModal
        isOpen={isDesktopModalOpen}
        onClose={() => setIsDesktopModalOpen(false)}
        settings={settings}
        lang={lang}
        deferredPrompt={deferredPrompt}
        onInstallPWA={handleInstallPWA}
      />

    </div>
  );
}
